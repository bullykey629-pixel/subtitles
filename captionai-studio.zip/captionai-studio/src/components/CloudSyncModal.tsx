import React, { useState } from "react";
import {
  Cloud,
  CloudOff,
  RefreshCw,
  FolderKanban,
  Plus,
  Copy,
  Trash2,
  Download,
  Upload,
  CheckCircle2,
  X,
  Laptop,
  Smartphone,
  Globe,
  RotateCcw,
} from "lucide-react";
import { Project } from "../types";
import { safeJsonStringify } from "../utils/safeJson";

interface CloudSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProject: Project;
  allProjects: Project[];
  onSelectProject: (projectId: string) => void;
  onCreateNewProject: () => void;
  onDuplicateProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
  onToggleCloudSync: (enabled: boolean) => void;
  onForceSync: () => Promise<void>;
  isSyncing: boolean;
  onImportProjectJSON: (jsonString: string) => void;
  onResetToDefault?: () => void;
}

export const CloudSyncModal: React.FC<CloudSyncModalProps> = ({
  isOpen,
  onClose,
  currentProject,
  allProjects,
  onSelectProject,
  onCreateNewProject,
  onDuplicateProject,
  onDeleteProject,
  onToggleCloudSync,
  onForceSync,
  isSyncing,
  onImportProjectJSON,
  onResetToDefault,
}) => {
  const [activeTab, setActiveTab] = useState<"projects" | "cloud">("projects");
  const [syncSuccessMsg, setSyncSuccessMsg] = useState(false);

  if (!isOpen) return null;

  const handleManualSync = async () => {
    await onForceSync();
    setSyncSuccessMsg(true);
    setTimeout(() => setSyncSuccessMsg(false), 3000);
  };

  const handleExportBackup = () => {
    const title = currentProject?.title || "project";
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(safeJsonStringify(currentProject, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${title.toLowerCase().replace(/\s+/g, "_")}_project_backup.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        onImportProjectJSON(text);
        alert("Project imported successfully!");
      } catch (err: any) {
        alert("Invalid project file: " + err.message);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-400/20 text-emerald-300 flex items-center justify-center border border-emerald-400/30">
              <Cloud className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-zinc-100">Cloud Sync & Workspace</h2>
              <p className="text-[11px] text-zinc-400">Cross-device cloud synchronization & project manager</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-zinc-800 bg-zinc-950/60 text-xs px-2">
          <button
            onClick={() => setActiveTab("projects")}
            className={`py-2.5 px-4 font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === "projects" ? "border-emerald-400 text-emerald-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <FolderKanban className="w-3.5 h-3.5" />
            <span>Projects ({allProjects.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("cloud")}
            className={`py-2.5 px-4 font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === "cloud" ? "border-emerald-400 text-emerald-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Cloud Sync Status</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
          {/* Projects Tab */}
          {activeTab === "projects" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-zinc-300 text-[11px] uppercase tracking-wider">All Workspace Projects</span>
                <button
                  onClick={onCreateNewProject}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Project</span>
                </button>
              </div>

              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {allProjects.map((p) => {
                  const isCurrent = p.id === currentProject.id;
                  const updatedDate = new Date(p.updatedAt).toLocaleDateString([], {
                    month: "short",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  });

                  return (
                    <div
                      key={p.id}
                      onClick={() => onSelectProject(p.id)}
                      className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between transition-all ${
                        isCurrent
                          ? "bg-emerald-500/10 border-emerald-400/80 ring-1 ring-emerald-400/30"
                          : "bg-zinc-950/60 hover:bg-zinc-800/60 border-zinc-800 text-zinc-300"
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-xs text-zinc-100">{p.title}</span>
                          {isCurrent && (
                            <span className="text-[9px] bg-emerald-400/20 text-emerald-300 px-1.5 py-0.5 rounded-full font-mono">
                              ACTIVE
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-zinc-400 font-mono">
                          {p.subtitles.length} captions · {p.videoAspectRatio} · Updated {updatedDate}
                        </p>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDuplicateProject(p.id);
                          }}
                          className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200"
                          title="Duplicate Project"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>

                        {allProjects.length > 1 && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Delete project "${p.title}"?`)) {
                                onDeleteProject(p.id);
                              }
                            }}
                            className="p-1.5 rounded-lg hover:bg-rose-500/20 text-zinc-400 hover:text-rose-400"
                            title="Delete Project"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Import / Export JSON Project Bundle */}
              <div className="pt-3 border-t border-zinc-800 flex items-center justify-between gap-2">
                <button
                  onClick={handleExportBackup}
                  className="flex-1 py-2 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium border border-zinc-700 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Backup Project</span>
                </button>

                <label className="flex-1 py-2 px-3 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium border border-zinc-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer text-center">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Import Project</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Reset to Default State Button */}
              {onResetToDefault && (
                <div className="pt-1">
                  <button
                    onClick={() => {
                      if (window.confirm("Kya aap app ko pehle jaisa (original default demo state) par reset karna chahte hain? Sabhi captions aur styling default ho jayenge.")) {
                        onResetToDefault();
                        onClose();
                      }
                    }}
                    className="w-full py-2.5 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-semibold border border-amber-500/30 flex items-center justify-center gap-2 transition-all shadow-sm"
                  >
                    <RotateCcw className="w-4 h-4 text-amber-400" />
                    <span>Reset App to Default (Pehle Jaisa Restore Karein)</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Cloud Sync Status Tab */}
          {activeTab === "cloud" && (
            <div className="space-y-4">
              <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-zinc-200 block text-xs">Automatic Cloud Synchronization</span>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    Keep your video projects, custom subtitles, and styles synchronized across web, desktop, and mobile devices.
                  </p>
                </div>

                <button
                  onClick={() => onToggleCloudSync(!currentProject.isCloudSynced)}
                  className={`w-12 h-6 rounded-full p-0.5 transition-colors duration-200 ease-in-out ${
                    currentProject.isCloudSynced ? "bg-emerald-500" : "bg-zinc-700"
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform duration-200 ease-in-out ${
                      currentProject.isCloudSynced ? "translate-x-6" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>

              {/* Cloud Devices Connected Visualization */}
              <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800 space-y-3">
                <span className="font-bold text-zinc-300 block text-[11px] uppercase tracking-wider">Device Synchronization</span>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 flex flex-col items-center gap-1.5">
                    <Laptop className="w-5 h-5 text-emerald-400" />
                    <span className="text-zinc-200 font-semibold text-[11px]">Web Browser</span>
                    <span className="text-[9px] text-emerald-400 font-mono">ONLINE / ACTIVE</span>
                  </div>
                  <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 flex flex-col items-center gap-1.5">
                    <Smartphone className="w-5 h-5 text-zinc-400" />
                    <span className="text-zinc-300 font-semibold text-[11px]">Mobile App</span>
                    <span className="text-[9px] text-zinc-500 font-mono">READY TO SYNC</span>
                  </div>
                  <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 flex flex-col items-center gap-1.5">
                    <Globe className="w-5 h-5 text-sky-400" />
                    <span className="text-zinc-300 font-semibold text-[11px]">Cloud Server</span>
                    <span className="text-[9px] text-sky-400 font-mono">CONNECTED</span>
                  </div>
                </div>
              </div>

              {/* Manual Force Sync Button */}
              <button
                onClick={handleManualSync}
                disabled={isSyncing}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all"
              >
                {isSyncing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Synchronizing with Cloud...</span>
                  </>
                ) : syncSuccessMsg ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-zinc-950" />
                    <span>Synchronized Successfully!</span>
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    <span>Force Sync Now</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
