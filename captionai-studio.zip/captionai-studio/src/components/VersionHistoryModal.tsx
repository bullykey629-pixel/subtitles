import React, { useState } from "react";
import {
  History,
  X,
  BookmarkPlus,
  RotateCcw,
  Clock,
  FileCheck,
  Layers,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { ProjectVersion, SubtitleItem, SubtitleStyle } from "../types";

interface VersionHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  versions: ProjectVersion[];
  currentSubtitles: SubtitleItem[];
  currentStyle: SubtitleStyle;
  onCreateSnapshot: (name: string, description: string) => void;
  onRestoreVersion: (version: ProjectVersion) => void;
}

export const VersionHistoryModal: React.FC<VersionHistoryModalProps> = ({
  isOpen,
  onClose,
  versions,
  currentSubtitles,
  currentStyle,
  onCreateSnapshot,
  onRestoreVersion,
}) => {
  const [snapshotName, setSnapshotName] = useState("");
  const [snapshotDesc, setSnapshotDesc] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState<ProjectVersion | null>(null);

  if (!isOpen) return null;

  const handleSaveSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!snapshotName.trim()) return;
    onCreateSnapshot(snapshotName.trim(), snapshotDesc.trim() || "Manual checkpoint snapshot");
    setSnapshotName("");
    setSnapshotDesc("");
    setIsCreating(false);
  };

  const activeCompareVersion = selectedVersion || versions[0];

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center border border-amber-400/30">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-zinc-100">Project Version Control</h2>
              <p className="text-[11px] text-zinc-400">Track milestones, compare diffs, and restore previous project states</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Grid: Left Timeline list / Right Version Diff Inspector */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-zinc-800 text-xs">
          {/* Left Column: Version Milestones List */}
          <div className="p-4 overflow-y-auto flex flex-col space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-zinc-300 text-[11px] uppercase tracking-wider">Milestones & History</span>
              {!isCreating && (
                <button
                  onClick={() => setIsCreating(true)}
                  className="px-2.5 py-1 rounded-md bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-[11px] flex items-center gap-1 transition-all"
                >
                  <BookmarkPlus className="w-3 h-3" />
                  <span>Save Checkpoint</span>
                </button>
              )}
            </div>

            {/* Create Snapshot Input Form */}
            {isCreating && (
              <form onSubmit={handleSaveSnapshot} className="p-3 bg-zinc-950 rounded-xl border border-zinc-750 space-y-2">
                <span className="font-bold text-zinc-200 block text-[11px]">New Milestone Checkpoint</span>
                <input
                  type="text"
                  placeholder="e.g. Spanish Translated v2, Final Trim"
                  value={snapshotName}
                  onChange={(e) => setSnapshotName(e.target.value)}
                  autoFocus
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 text-zinc-200 text-xs focus:outline-none focus:border-amber-400"
                />
                <input
                  type="text"
                  placeholder="Optional notes or changelog..."
                  value={snapshotDesc}
                  onChange={(e) => setSnapshotDesc(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-lg p-2 text-zinc-200 text-xs focus:outline-none focus:border-amber-400"
                />
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsCreating(false)}
                    className="px-2 py-1 rounded text-zinc-400 hover:text-zinc-200"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 rounded bg-amber-500 text-zinc-950 font-bold hover:bg-amber-400"
                  >
                    Save
                  </button>
                </div>
              </form>
            )}

            {/* Version items */}
            <div className="space-y-2 flex-1">
              {versions.length === 0 ? (
                <div className="text-center py-8 text-zinc-500 text-xs">No version checkpoints recorded yet.</div>
              ) : (
                versions.map((ver, idx) => {
                  const isSelected = activeCompareVersion?.id === ver.id;
                  const dateStr = new Date(ver.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });

                  return (
                    <div
                      key={ver.id}
                      onClick={() => setSelectedVersion(ver)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? "bg-amber-500/10 border-amber-400 text-zinc-100 shadow-md ring-1 ring-amber-400/30"
                          : "bg-zinc-950/60 hover:bg-zinc-800/60 border-zinc-800 text-zinc-300"
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-xs text-zinc-100">{ver.name}</span>
                        <span className="text-[10px] text-zinc-500 font-mono">{dateStr}</span>
                      </div>

                      <p className="text-[11px] text-zinc-400 line-clamp-1 mb-2">
                        {ver.description || "Project state snapshot"}
                      </p>

                      <div className="flex items-center justify-between pt-2 border-t border-zinc-800/80 text-[10px]">
                        <span className="text-zinc-400 font-mono">
                          {ver.snapshot.subtitles.length} cues · {ver.snapshot.currentLanguage.toUpperCase()}
                        </span>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`Restore project to "${ver.name}"?`)) {
                              onRestoreVersion(ver);
                              onClose();
                            }
                          }}
                          className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-amber-400 hover:text-zinc-950 text-zinc-300 font-semibold flex items-center gap-1 transition-colors"
                          title="Restore this version"
                        >
                          <RotateCcw className="w-2.5 h-2.5" />
                          <span>Revert to this</span>
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Column: Version Diff / Inspector */}
          <div className="p-4 overflow-y-auto flex flex-col space-y-3 bg-zinc-950/40">
            <span className="font-semibold text-zinc-300 text-[11px] uppercase tracking-wider">Snapshot Inspector</span>

            {activeCompareVersion ? (
              <div className="space-y-3">
                <div className="p-3 bg-zinc-900 rounded-xl border border-zinc-800 space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-zinc-100">{activeCompareVersion.name}</span>
                    <span className="text-[10px] bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full font-mono">
                      {new Date(activeCompareVersion.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400">{activeCompareVersion.description}</p>
                </div>

                {/* Diff summary stats */}
                <div className="grid grid-cols-2 gap-2 text-center">
                  <div className="p-2.5 bg-zinc-900 rounded-lg border border-zinc-800">
                    <span className="text-[10px] text-zinc-500 block">Version Cues</span>
                    <span className="text-base font-bold text-amber-400 font-mono">
                      {activeCompareVersion.snapshot.subtitles.length}
                    </span>
                  </div>
                  <div className="p-2.5 bg-zinc-900 rounded-lg border border-zinc-800">
                    <span className="text-[10px] text-zinc-500 block">Current Cues</span>
                    <span className="text-base font-bold text-zinc-200 font-mono">
                      {currentSubtitles.length}
                    </span>
                  </div>
                </div>

                {/* Subtitle Snippets Preview */}
                <div>
                  <span className="text-[11px] font-semibold text-zinc-400 block mb-1.5">Captured Subtitle Cues Preview:</span>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto p-1">
                    {activeCompareVersion.snapshot.subtitles.slice(0, 5).map((sub, i) => (
                      <div key={i} className="p-2 bg-zinc-900 rounded-lg border border-zinc-800/80 text-[11px] text-zinc-300">
                        <div className="text-[9px] text-zinc-500 font-mono mb-0.5">
                          [{sub.startTime.toFixed(1)}s - {sub.endTime.toFixed(1)}s] {sub.speaker}
                        </div>
                        <div>{sub.text}</div>
                      </div>
                    ))}
                    {activeCompareVersion.snapshot.subtitles.length > 5 && (
                      <p className="text-[10px] text-zinc-500 text-center py-1">
                        + {activeCompareVersion.snapshot.subtitles.length - 5} more subtitles in this snapshot
                      </p>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (confirm(`Restore project to "${activeCompareVersion.name}"?`)) {
                      onRestoreVersion(activeCompareVersion);
                      onClose();
                    }
                  }}
                  className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore Snapshot Now</span>
                </button>
              </div>
            ) : (
              <div className="text-center py-12 text-zinc-500">Select a version milestone to inspect details</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
