/**
 * Extracts and downsamples audio from video or audio file to 16kHz mono WAV base64 strings.
 * Supports full duration and multi-chunk segmentation for long videos (e.g. 5m, 15m, 30m+).
 */

export interface AudioChunk {
  chunkIndex: number;
  totalChunks: number;
  startTime: number;
  endTime: number;
  duration: number;
  base64: string;
  mimeType: string;
}

export async function extractAudioFromVideoElement(video: HTMLVideoElement): Promise<string> {
  try {
    const src = video.currentSrc || video.src;
    if (!src) return "";

    const response = await fetch(src);
    const blob = await response.blob();
    const result = await extractAudioFromMedia(blob);
    return result.base64;
  } catch (err) {
    console.warn("Direct fetch audio extract failed, continuing:", err);
    return "";
  }
}

export async function extractAudioChunksFromMedia(
  file: File | Blob,
  chunkDurationSeconds: number = 60,
  maxTotalMinutes: number = 60
): Promise<{ chunks: AudioChunk[]; totalDuration: number }> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) {
      throw new Error("Web Audio API is not supported in this browser.");
    }

    const audioCtx = new AudioContextClass();
    let audioBuffer: AudioBuffer;

    try {
      audioBuffer = await audioCtx.decodeAudioData(arrayBuffer.slice(0));
    } catch (decodeErr) {
      console.warn("Direct decode failed in chunk extractor:", decodeErr);
      await audioCtx.close();
      return { chunks: [], totalDuration: 0 };
    }

    const totalDuration = audioBuffer.duration;
    const targetSampleRate = 16000;
    const cappedDuration = Math.min(totalDuration, maxTotalMinutes * 60);

    const chunkCount = Math.max(1, Math.ceil(cappedDuration / chunkDurationSeconds));
    const chunks: AudioChunk[] = [];

    for (let i = 0; i < chunkCount; i++) {
      const chunkStart = i * chunkDurationSeconds;
      const chunkEnd = Math.min(cappedDuration, (i + 1) * chunkDurationSeconds);
      const chunkDur = chunkEnd - chunkStart;
      if (chunkDur <= 0.1) continue;

      const numSamples = Math.floor(chunkDur * targetSampleRate);
      const offlineCtx = new OfflineAudioContext(1, numSamples, targetSampleRate);

      const source = offlineCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(offlineCtx.destination);
      // Start audio at the negative offset to capture exact chunk slice
      source.start(0, chunkStart, chunkDur);

      const renderedBuffer = await offlineCtx.startRendering();
      const wavBlob = audioBufferToWavBlob(renderedBuffer);
      const base64WithHeader = await blobToBase64(wavBlob);
      const cleanBase64 = base64WithHeader.split(",")[1] || base64WithHeader;

      chunks.push({
        chunkIndex: i,
        totalChunks: chunkCount,
        startTime: chunkStart,
        endTime: chunkEnd,
        duration: chunkDur,
        base64: cleanBase64,
        mimeType: "audio/wav",
      });
    }

    await audioCtx.close();
    return { chunks, totalDuration };
  } catch (err) {
    console.error("Multi-chunk audio extraction error:", err);
    return { chunks: [], totalDuration: 0 };
  }
}

export async function extractAudioChunksFromVideoElement(
  video: HTMLVideoElement,
  chunkDurationSeconds: number = 60
): Promise<{ chunks: AudioChunk[]; totalDuration: number }> {
  try {
    const src = video.currentSrc || video.src;
    if (!src) return { chunks: [], totalDuration: video.duration || 0 };

    const response = await fetch(src);
    const blob = await response.blob();
    return await extractAudioChunksFromMedia(blob, chunkDurationSeconds);
  } catch (err) {
    console.warn("Video element chunk extraction error:", err);
    return { chunks: [], totalDuration: video.duration || 0 };
  }
}

export async function extractAudioFromMedia(
  file: File | Blob,
  maxAudioSeconds: number = 1800 // support up to 30 minutes
): Promise<{ base64: string; mimeType: string; duration: number }> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) {
      throw new Error("Web Audio API is not supported in this browser.");
    }

    const audioCtx = new AudioContextClass();
    let audioBuffer: AudioBuffer;

    try {
      audioBuffer = await audioCtx.decodeAudioData(arrayBuffer.slice(0));
    } catch (decodeErr) {
      console.warn("Direct decode failed, attempting fallback:", decodeErr);
      return { base64: "", mimeType: "audio/wav", duration: 30 };
    }

    const duration = audioBuffer.duration;
    const targetSampleRate = 16000;
    const processSeconds = Math.min(duration, maxAudioSeconds);
    const offlineCtx = new OfflineAudioContext(
      1, // mono
      Math.floor(targetSampleRate * processSeconds),
      targetSampleRate
    );

    const source = offlineCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(offlineCtx.destination);
    source.start(0, 0, processSeconds);

    const renderedBuffer = await offlineCtx.startRendering();
    await audioCtx.close();

    const wavBlob = audioBufferToWavBlob(renderedBuffer);
    const base64 = await blobToBase64(wavBlob);

    return {
      base64: base64.split(",")[1] || base64,
      mimeType: "audio/wav",
      duration,
    };
  } catch (err: any) {
    console.error("Audio extraction error:", err);
    return { base64: "", mimeType: "audio/wav", duration: 30 };
  }
}

function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numOfChan = 1;
  const length = buffer.length * numOfChan * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));
  const channels = [buffer.getChannelData(0)];
  let sampleRate = buffer.sampleRate;
  let pos = 0;

  function setUint16(data: number) {
    out.setUint16(pos, data, true);
    pos += 2;
  }
  function setUint32(data: number) {
    out.setUint32(pos, data, true);
    pos += 4;
  }

  // RIFF identifier
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"

  // fmt sub-chunk
  setUint32(0x20746d66); // "fmt " chunk
  setUint32(16); // length = 16
  setUint16(1); // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(sampleRate);
  setUint32(sampleRate * 2 * numOfChan); // byte rate
  setUint16(numOfChan * 2); // block align
  setUint16(16); // 16-bit depth

  // data sub-chunk
  setUint32(0x61746164); // "data" chunk
  setUint32(length - pos - 4); // chunk length

  // write interleaved samples
  for (let i = 0; i < buffer.length; i++) {
    for (let channel = 0; channel < numOfChan; channel++) {
      let sample = Math.max(-1, Math.min(1, channels[channel][i]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      out.setInt16(pos, sample, true);
      pos += 2;
    }
  }

  return new Blob([out.buffer], { type: "audio/wav" });
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

