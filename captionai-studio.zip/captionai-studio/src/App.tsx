import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  Film,
  FileText,
  Palette,
  Clock,
  Sparkles,
  Download,
  Play,
  Pause,
  Plus,
  Wand2,
} from "lucide-react";
import { Header } from "./components/Header";
import { VideoCanvas } from "./components/VideoCanvas";
import { TimelineEditor } from "./components/TimelineEditor";
import { CaptionList } from "./components/CaptionList";
import { StyleEditor } from "./components/StyleEditor";
import { AIToolsModal } from "./components/AIToolsModal";
import { VersionHistoryModal } from "./components/VersionHistoryModal";
import { CloudSyncModal } from "./components/CloudSyncModal";
import { ExportModal } from "./components/ExportModal";
import { UploadOrSampleModal } from "./components/UploadOrSampleModal";
import { Project, SubtitleItem, SubtitleStyle, StylePreset, ProjectVersion, SampleVideo } from "./types";
import { SAMPLE_VIDEOS } from "./data/sampleVideos";
import { DEFAULT_STYLE, STYLE_PRESETS } from "./data/stylePresets";
import {
  extractAudioFromVideoElement,
  extractAudioFromMedia,
  extractAudioChunksFromMedia,
  extractAudioChunksFromVideoElement,
  AudioChunk,
} from "./utils/audioExtractor";
import { parseSubtitleFile } from "./utils/captionConverters";
import { safeJsonStringify, cleanSerializableObject } from "./utils/safeJson";

const STORAGE_KEY_PROJECTS = "caption_ai_projects_v2";
const STORAGE_KEY_ACTIVE_ID = "caption_ai_active_project_id_v2";

export function App() {
  // Initial default project
  const initialSample = SAMPLE_VIDEOS[0];
  const createDefaultProject = (sample: SampleVideo = initialSample): Project => {
    const s = sample || initialSample || SAMPLE_VIDEOS[0];
    const captions = s?.defaultCaptions ? [...s.defaultCaptions] : [];
    return {
      id: "proj_" + Math.random().toString(36).substring(2, 9),
      title: s?.title || "Demo Video Project",
      videoUrl: s?.videoUrl || "",
      videoDuration: s?.duration || 30,
      videoAspectRatio: s?.aspectRatio || "16:9",
      subtitles: captions,
      style: { ...DEFAULT_STYLE },
      bilingualMode: false,
      targetLanguage: "en",
      versions: [
        {
          id: "ver_init_" + Date.now(),
          name: "Initial Sample Import",
          timestamp: Date.now(),
          description: "Imported from demo template",
          subtitleCount: captions.length,
          snapshot: {
            subtitles: [...captions],
            style: { ...DEFAULT_STYLE },
            currentLanguage: "en",
          },
        },
      ],
      isCloudSynced: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
  };

  // Projects State with sanitization
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PROJECTS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((p: any) => ({
            id: p.id || "proj_" + Math.random().toString(36).substring(2, 9),
            title: p.title || "Untitled Project",
            videoUrl: p.videoUrl || initialSample.videoUrl,
            videoDuration: p.videoDuration || 30,
            videoAspectRatio: p.videoAspectRatio || "16:9",
            subtitles: Array.isArray(p.subtitles) ? p.subtitles : [],
            style: { ...DEFAULT_STYLE, ...(p.style || {}) },
            bilingualMode: Boolean(p.bilingualMode),
            targetLanguage: p.targetLanguage || "en",
            versions: Array.isArray(p.versions) && p.versions.length > 0
              ? p.versions
              : [
                  {
                    id: "ver_init_" + Date.now(),
                    name: "Initial Version",
                    timestamp: Date.now(),
                    description: "Initial state",
                    subtitleCount: Array.isArray(p.subtitles) ? p.subtitles.length : 0,
                    snapshot: {
                      subtitles: Array.isArray(p.subtitles) ? [...p.subtitles] : [],
                      style: { ...DEFAULT_STYLE, ...(p.style || {}) },
                      currentLanguage: p.targetLanguage || "en",
                    },
                  },
                ],
            isCloudSynced: p.isCloudSynced ?? true,
            createdAt: p.createdAt || Date.now(),
            updatedAt: p.updatedAt || Date.now(),
          }));
        }
      }
    } catch {}
    return [createDefaultProject()];
  });

  const [activeProjectId, setActiveProjectId] = useState<string>(() => {
    try {
      const savedId = localStorage.getItem(STORAGE_KEY_ACTIVE_ID);
      if (savedId) return savedId;
    } catch {}
    return projects[0]?.id || "";
  });

  // Active Project Reference
  const currentProject = projects.find((p) => p.id === activeProjectId) || projects[0] || createDefaultProject();

  // Playback State
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(currentProject.videoDuration || 30);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [selectedSubtitleId, setSelectedSubtitleId] = useState<string | null>(null);

  // Layout Panels Visibility
  const [showCaptionsPanel, setShowCaptionsPanel] = useState(true);
  const [showStylePanel, setShowStylePanel] = useState(true);

  // Mobile & Tablet Active Tab: 'canvas' | 'captions' | 'style' | 'timeline'
  const [mobileTab, setMobileTab] = useState<"canvas" | "captions" | "style" | "timeline">("canvas");
  const [isDesktop, setIsDesktop] = useState(() =>
    typeof window !== "undefined" ? window.innerWidth >= 1024 : true
  );

  // Synchronize responsive layout on window resize
  useEffect(() => {
    const handleResize = () => {
      setIsDesktop(window.innerWidth >= 1024);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Modals Visibility
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [isVersionModalOpen, setIsVersionModalOpen] = useState(false);
  const [isCloudModalOpen, setIsCloudModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // Cloud Sync Status
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<number>(Date.now());

  // Video element ref
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [currentMediaFile, setCurrentMediaFile] = useState<File | Blob | null>(null);

  // Save projects to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PROJECTS, safeJsonStringify(projects));
      localStorage.setItem(STORAGE_KEY_ACTIVE_ID, currentProject.id);
    } catch {}
  }, [projects, currentProject.id]);

  // Update active project helper
  const updateCurrentProject = useCallback(
    (updates: Partial<Project>, recordHistory: boolean = false, historyNote?: string) => {
      const sanitizedUpdates = cleanSerializableObject(updates);
      setProjects((prevProjects) =>
        prevProjects.map((p) => {
          if (p.id !== currentProject.id) return p;

          let updatedVersions = p.versions;
          if (recordHistory) {
            const newVersion: ProjectVersion = {
              id: "ver_" + Date.now(),
              name: historyNote || `Edit snapshot (${new Date().toLocaleTimeString()})`,
              timestamp: Date.now(),
              description: historyNote || "Automatic milestone snapshot",
              snapshot: {
                subtitles: sanitizedUpdates.subtitles ? [...sanitizedUpdates.subtitles] : [...p.subtitles],
                style: sanitizedUpdates.style ? { ...sanitizedUpdates.style } : { ...p.style },
                currentLanguage: sanitizedUpdates.targetLanguage || p.targetLanguage,
              },
            };
            updatedVersions = [newVersion, ...p.versions].slice(0, 30); // keep last 30 snapshots
          }

          return {
            ...p,
            ...sanitizedUpdates,
            versions: updatedVersions,
            updatedAt: Date.now(),
          };
        })
      );
      setLastSavedTime(Date.now());
    },
    [currentProject.id]
  );

  // Keyboard Shortcuts (Space for Play/Pause, S for Split, Esc to close modals)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if typing inside input / textarea
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable) {
        return;
      }

      if (e.code === "Space") {
        e.preventDefault();
        handlePlayPause();
      } else if (e.key === "s" || e.key === "S") {
        const activeSub = currentProject.subtitles.find(
          (s) => currentTime >= s.startTime && currentTime <= s.endTime
        );
        if (activeSub && currentTime > activeSub.startTime + 0.2 && currentTime < activeSub.endTime - 0.2) {
          handleSplitSubtitle(activeSub.id, currentTime);
        }
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        handleSeek(Math.max(0, currentTime - (e.shiftKey ? 2 : 0.5)));
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        handleSeek(Math.min(duration, currentTime + (e.shiftKey ? 2 : 0.5)));
      } else if (e.key === "Escape") {
        setIsAIModalOpen(false);
        setIsVersionModalOpen(false);
        setIsCloudModalOpen(false);
        setIsExportModalOpen(false);
        setIsUploadModalOpen(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentTime, duration, isPlaying, currentProject.subtitles]);

  // Video playback handlers
  const handlePlayPause = () => {
    setIsPlaying((prev) => !prev);
  };

  const handleSeek = (time: number) => {
    const validTime = Math.max(0, Math.min(duration || 300, time));
    if (videoRef.current) {
      videoRef.current.currentTime = validTime;
    }
    setCurrentTime(validTime);
  };

  const handleTimeUpdate = (time: number) => {
    setCurrentTime(time);
  };

  const handleDurationChange = (dur: number) => {
    setDuration(dur);
    updateCurrentProject({ videoDuration: dur });
  };

  const handlePlaybackRateChange = (rate: number) => {
    if (!videoRef.current) return;
    videoRef.current.playbackRate = rate;
    setPlaybackRate(rate);
  };

  const handleVolumeChange = (vol: number) => {
    if (!videoRef.current) return;
    videoRef.current.volume = vol;
    setVolume(vol);
    setIsMuted(vol === 0);
  };

  const handleToggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.volume = volume || 0.8;
      setIsMuted(false);
    } else {
      videoRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  // Subtitle Manipulation Handlers
  const handleUpdateSubtitle = (id: string, updates: Partial<SubtitleItem>) => {
    const updated = currentProject.subtitles.map((sub) => (sub.id === id ? { ...sub, ...updates } : sub));
    updateCurrentProject({ subtitles: updated });
  };

  const handleDeleteSubtitle = (id: string) => {
    const updated = currentProject.subtitles.filter((sub) => sub.id !== id);
    updateCurrentProject({ subtitles: updated }, true, "Deleted subtitle cue");
    if (selectedSubtitleId === id) setSelectedSubtitleId(null);
  };

  const handleDuplicateSubtitle = (id: string) => {
    const target = currentProject.subtitles.find((s) => s.id === id);
    if (!target) return;
    const newSub: SubtitleItem = {
      ...target,
      id: "sub_" + Math.random().toString(36).substring(2, 9),
      startTime: target.endTime,
      endTime: target.endTime + (target.endTime - target.startTime),
    };
    const updated = [...currentProject.subtitles, newSub].sort((a, b) => a.startTime - b.startTime);
    updateCurrentProject({ subtitles: updated }, true, "Duplicated subtitle cue");
  };

  const handleAddSubtitle = (time: number) => {
    const newSub: SubtitleItem = {
      id: "sub_" + Math.random().toString(36).substring(2, 9),
      startTime: Math.round(time * 10) / 10,
      endTime: Math.round((time + 2.5) * 10) / 10,
      text: "New subtitle line",
      speaker: "Speaker 1",
      words: [
        { word: "New", startTime: time, endTime: time + 0.8 },
        { word: "subtitle", startTime: time + 0.8, endTime: time + 1.6 },
        { word: "line", startTime: time + 1.6, endTime: time + 2.5 },
      ],
    };
    const updated = [...currentProject.subtitles, newSub].sort((a, b) => a.startTime - b.startTime);
    updateCurrentProject({ subtitles: updated }, true, "Added new subtitle cue");
    setSelectedSubtitleId(newSub.id);
  };

  const handleSplitSubtitle = (id: string, splitTime: number) => {
    const target = currentProject.subtitles.find((s) => s.id === id);
    if (!target || splitTime <= target.startTime || splitTime >= target.endTime) return;

    const words = target.text.split(" ");
    const midWordIdx = Math.max(1, Math.floor(words.length / 2));
    const firstText = words.slice(0, midWordIdx).join(" ");
    const secondText = words.slice(midWordIdx).join(" ");

    const sub1: SubtitleItem = {
      ...target,
      endTime: splitTime,
      text: firstText || target.text,
      words: target.words ? target.words.filter((w) => w.endTime <= splitTime) : undefined,
    };

    const sub2: SubtitleItem = {
      id: "sub_" + Math.random().toString(36).substring(2, 9),
      startTime: splitTime,
      endTime: target.endTime,
      text: secondText || target.text,
      speaker: target.speaker,
      words: target.words ? target.words.filter((w) => w.startTime >= splitTime) : undefined,
    };

    const updated = currentProject.subtitles.flatMap((s) => (s.id === id ? [sub1, sub2] : [s]));
    updateCurrentProject({ subtitles: updated }, true, "Split subtitle cue");
  };

  const handleMergeSubtitle = (id: string) => {
    const sorted = [...currentProject.subtitles].sort((a, b) => a.startTime - b.startTime);
    const index = sorted.findIndex((s) => s.id === id);
    if (index === -1 || index === sorted.length - 1) return;

    const current = sorted[index];
    const next = sorted[index + 1];

    const merged: SubtitleItem = {
      id: current.id,
      startTime: current.startTime,
      endTime: next.endTime,
      text: `${current.text} ${next.text}`,
      speaker: current.speaker || next.speaker,
      words: [...(current.words || []), ...(next.words || [])],
    };

    const updated = sorted.filter((_, idx) => idx !== index + 1).map((s) => (s.id === current.id ? merged : s));
    updateCurrentProject({ subtitles: updated }, true, "Merged subtitles");
  };

  const handleSnapGaps = () => {
    const sorted = [...currentProject.subtitles].sort((a, b) => a.startTime - b.startTime);
    for (let i = 0; i < sorted.length - 1; i++) {
      const gap = sorted[i + 1].startTime - sorted[i].endTime;
      if (gap > 0 && gap < 0.4) {
        sorted[i].endTime = sorted[i + 1].startTime;
      }
    }
    updateCurrentProject({ subtitles: sorted }, true, "Auto-snapped subtitle gaps");
  };

  const handleShiftAllTimestamps = (seconds: number) => {
    const updated = currentProject.subtitles.map((s) => ({
      ...s,
      startTime: Math.max(0, Math.round((s.startTime + seconds) * 100) / 100),
      endTime: Math.max(0.3, Math.round((s.endTime + seconds) * 100) / 100),
      words: s.words?.map((w) => ({
        ...w,
        startTime: Math.max(0, Math.round((w.startTime + seconds) * 100) / 100),
        endTime: Math.max(0.1, Math.round((w.endTime + seconds) * 100) / 100),
      })),
    }));
    updateCurrentProject({ subtitles: updated }, true, `Shifted timestamps by ${seconds > 0 ? "+" : ""}${seconds}s`);
  };

  const handleRechunkSubtitles = (wordsPerLine: number) => {
    if (wordsPerLine <= 0) return;
    const newSubtitles: SubtitleItem[] = [];

    currentProject.subtitles.forEach((sub) => {
      const allWords =
        sub.words && sub.words.length > 0
          ? sub.words
          : sub.text
              .split(/\s+/)
              .filter(Boolean)
              .map((w, idx, arr) => {
                const d = (sub.endTime - sub.startTime) / Math.max(1, arr.length);
                return {
                  word: w,
                  startTime: sub.startTime + idx * d,
                  endTime: sub.startTime + (idx + 1) * d,
                };
              });

      if (allWords.length <= wordsPerLine) {
        newSubtitles.push(sub);
        return;
      }

      for (let i = 0; i < allWords.length; i += wordsPerLine) {
        const chunk = allWords.slice(i, i + wordsPerLine);
        const chunkText = chunk.map((w) => w.word).join(" ");
        const chunkStart = chunk[0].startTime;
        const chunkEnd = chunk[chunk.length - 1].endTime;

        newSubtitles.push({
          id: "sub_" + Math.random().toString(36).substring(2, 9),
          startTime: Math.round(chunkStart * 100) / 100,
          endTime: Math.round(chunkEnd * 100) / 100,
          text: chunkText,
          speaker: sub.speaker,
          words: chunk,
        });
      }
    });

    const sorted = newSubtitles.sort((a, b) => a.startTime - b.startTime);
    updateCurrentProject({ subtitles: sorted }, true, `Re-chunked all subtitles to ${wordsPerLine} words per line`);
  };

  const handlePlaySnippet = (startTime: number, endTime: number) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = startTime;
    videoRef.current.play();
    setIsPlaying(true);

    const checkTime = () => {
      if (videoRef.current && videoRef.current.currentTime >= endTime) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else if (isPlaying) {
        requestAnimationFrame(checkTime);
      }
    };
    requestAnimationFrame(checkTime);
  };

  // Style Handlers
  const handleUpdateStyle = (updates: Partial<SubtitleStyle>) => {
    updateCurrentProject({ style: { ...currentProject.style, ...updates } });
  };

  const handleApplyPreset = (preset: StylePreset) => {
    updateCurrentProject(
      { style: { ...currentProject.style, ...preset.style } },
      true,
      `Applied ${preset.name} Style Preset`
    );
  };

  // AI Generation Handlers (Backend Integration with Long Video Support)
  const handleGenerateCaptions = async (params: {
    language: string;
    contextPrompt: string;
    onProgress?: (status: { message: string; percent: number }) => void;
  }) => {
    const totalVidDuration = duration || currentProject.videoDuration || 30;
    const isLongVideo = totalVidDuration > 60;
    const chunkDurationSeconds = 60; // 60s per chunk provides optimal accuracy and prevents token cutoffs

    params.onProgress?.({
      message: isLongVideo
        ? `Preparing multi-segment audio analysis for ${Math.floor(totalVidDuration / 60)}m ${Math.floor(totalVidDuration % 60)}s video...`
        : "Extracting audio for AI transcription...",
      percent: 10,
    });

    let chunks: AudioChunk[] = [];

    // 1. Try extracting chunked audio from currentMediaFile
    if (currentMediaFile) {
      try {
        const res = await extractAudioChunksFromMedia(currentMediaFile, chunkDurationSeconds);
        chunks = res.chunks;
      } catch (err) {
        console.warn("Direct multi-chunk extraction failed, falling back to video element:", err);
      }
    }

    // 2. If no chunks yet, try extracting from videoRef element
    if (chunks.length === 0 && videoRef.current) {
      try {
        const res = await extractAudioChunksFromVideoElement(videoRef.current, chunkDurationSeconds);
        chunks = res.chunks;
      } catch (err) {
        console.warn("Video element multi-chunk extraction failed:", err);
      }
    }

    // 3. Fallback: single audio extraction if chunking was empty
    if (chunks.length === 0) {
      let singleAudioBase64 = "";
      if (currentMediaFile) {
        const res = await extractAudioFromMedia(currentMediaFile);
        singleAudioBase64 = res.base64;
      } else if (videoRef.current) {
        singleAudioBase64 = await extractAudioFromVideoElement(videoRef.current);
      }

      chunks = [
        {
          chunkIndex: 0,
          totalChunks: 1,
          startTime: 0,
          endTime: totalVidDuration,
          duration: totalVidDuration,
          base64: singleAudioBase64,
          mimeType: "audio/wav",
        },
      ];
    }

    const totalChunks = chunks.length;
    const accumulatedSubtitles: SubtitleItem[] = [];

    // 4. Process each chunk sequentially to guarantee 100% full duration coverage without timeouts
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const startMin = Math.floor(chunk.startTime / 60);
      const startSec = Math.floor(chunk.startTime % 60).toString().padStart(2, "0");
      const endMin = Math.floor(chunk.endTime / 60);
      const endSec = Math.floor(chunk.endTime % 60).toString().padStart(2, "0");

      const chunkProgressPercent = Math.round(15 + ((i + 0.3) / totalChunks) * 75);

      params.onProgress?.({
        message: totalChunks > 1
          ? `Transcribing segment ${i + 1} of ${totalChunks} (${startMin}:${startSec} - ${endMin}:${endSec})...`
          : "Analyzing speech and generating word-level karaoke sync...",
        percent: chunkProgressPercent,
      });

      const response = await fetch("/api/generate-captions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: safeJsonStringify({
          audioData: chunk.base64,
          audioBase64: chunk.base64,
          mimeType: chunk.mimeType || "audio/wav",
          language: params.language,
          contextPrompt: params.contextPrompt,
          videoDuration: totalVidDuration,
          chunkDuration: chunk.duration,
          timeOffset: chunk.startTime,
          chunkIndex: chunk.chunkIndex,
          totalChunks: chunk.totalChunks,
          wordsPerCue: currentProject.style.wordsPerScreenLimit || 3,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Failed to transcribe audio segment ${i + 1}.`);
      }

      const data = await response.json();
      if (data.subtitles && Array.isArray(data.subtitles)) {
        accumulatedSubtitles.push(...data.subtitles);
      }
    }

    params.onProgress?.({
      message: "Finalizing full timeline alignment and word animations...",
      percent: 95,
    });

    // 5. Clean up, sort chronologically, and remove any duplicates
    const sortedSubtitles = accumulatedSubtitles
      .filter((s) => s.text && s.text.trim().length > 0)
      .sort((a, b) => a.startTime - b.startTime)
      .map((sub, idx) => ({
        ...sub,
        id: sub.id || `sub_full_${Date.now()}_${idx}`,
      }));

    if (sortedSubtitles.length > 0) {
      updateCurrentProject(
        { subtitles: sortedSubtitles, targetLanguage: params.language },
        true,
        `AI Auto-Transcribed Full Video (${sortedSubtitles.length} cues, ${params.language})`
      );
    }
  };

  const handleTranslateCaptions = async (targetLang: string, makeBilingual: boolean) => {
    const response = await fetch("/api/translate-captions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: safeJsonStringify({
        subtitles: currentProject.subtitles,
        targetLanguage: targetLang,
      }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || "Failed to translate captions.");
    }

    const data = await response.json();
    if (data.translatedSubtitles && Array.isArray(data.translatedSubtitles)) {
      if (makeBilingual) {
        // Merge translations as secondary bilingual text
        const bilingualList = currentProject.subtitles.map((orig, i) => {
          const trans = data.translatedSubtitles[i];
          return {
            ...orig,
            secondaryText: trans ? trans.text : "",
          };
        });
        updateCurrentProject(
          { subtitles: bilingualList, bilingualMode: true, targetLanguage: targetLang },
          true,
          `Translated to ${targetLang} (Bilingual Mode)`
        );
      } else {
        updateCurrentProject(
          { subtitles: data.translatedSubtitles, targetLanguage: targetLang },
          true,
          `Translated Subtitles to ${targetLang}`
        );
      }
    }
  };

  const handleEnhanceCaptions = async (action: "punchy" | "grammar" | "tone", tone?: string) => {
    const response = await fetch("/api/enhance-captions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: safeJsonStringify({
        subtitles: currentProject.subtitles,
        action,
        tone,
      }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error || "Failed to enhance captions.");
    }

    const data = await response.json();
    if (data.subtitles && Array.isArray(data.subtitles)) {
      updateCurrentProject(
        { subtitles: data.subtitles },
        true,
        `AI Enhanced: ${action === "punchy" ? "Viral Pacing" : action === "grammar" ? "Grammar Fix" : "Tone Polish"}`
      );
    }
  };

  // Version Control Handlers
  const handleCreateSnapshot = (name: string, description: string) => {
    const newVersion: ProjectVersion = {
      id: "ver_" + Date.now(),
      name,
      timestamp: Date.now(),
      description,
      snapshot: {
        subtitles: [...currentProject.subtitles],
        style: { ...currentProject.style },
        currentLanguage: currentProject.targetLanguage,
      },
    };
    updateCurrentProject({ versions: [newVersion, ...currentProject.versions] });
  };

  const handleRestoreVersion = (version: ProjectVersion) => {
    updateCurrentProject(
      {
        subtitles: [...version.snapshot.subtitles],
        style: { ...version.snapshot.style },
        targetLanguage: version.snapshot.currentLanguage,
      },
      true,
      `Restored snapshot: ${version.name}`
    );
  };

  // Cloud Sync & Workspace Management
  const handleForceSync = async () => {
    setIsSyncing(true);
    try {
      await fetch("/api/cloud-projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: safeJsonStringify({ project: currentProject }),
      });
      setLastSavedTime(Date.now());
    } catch (err) {
      console.warn("Cloud sync offline fallback:", err);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleCreateNewProject = () => {
    const newProj = createDefaultProject(SAMPLE_VIDEOS[1]);
    newProj.title = `Untitled Project ${projects.length + 1}`;
    setProjects((prev) => [newProj, ...prev]);
    setActiveProjectId(newProj.id);
  };

  const handleDuplicateProject = (projectId: string) => {
    const target = projects.find((p) => p.id === projectId);
    if (!target) return;
    const duplicated: Project = {
      ...target,
      id: "proj_" + Math.random().toString(36).substring(2, 9),
      title: `${target.title} (Copy)`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setProjects((prev) => [duplicated, ...prev]);
  };

  const handleDeleteProject = (projectId: string) => {
    if (projects.length <= 1) return;
    const remaining = projects.filter((p) => p.id !== projectId);
    setProjects(remaining);
    if (activeProjectId === projectId) {
      setActiveProjectId(remaining[0].id);
    }
  };

  const handleResetToDefault = () => {
    try {
      localStorage.removeItem(STORAGE_KEY_PROJECTS);
      localStorage.removeItem(STORAGE_KEY_ACTIVE_ID);
    } catch {}
    setCurrentMediaFile(null);
    const freshProject = createDefaultProject(SAMPLE_VIDEOS[0]);
    setProjects([freshProject]);
    setActiveProjectId(freshProject.id);
    setCurrentTime(0);
    setDuration(freshProject.videoDuration || 30);
    setIsPlaying(false);
    setSelectedSubtitleId(null);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.pause();
    }
  };

  const handleImportProjectJSON = (jsonString: string) => {
    const parsed = JSON.parse(jsonString);
    if (parsed.subtitles && parsed.title) {
      const importedProj: Project = {
        ...parsed,
        id: "proj_imp_" + Math.random().toString(36).substring(2, 9),
      };
      setProjects((prev) => [importedProj, ...prev]);
      setActiveProjectId(importedProj.id);
    }
  };

  // Media Source Handlers (Upload / Sample / Record)
  const handleSelectSample = (sample: SampleVideo) => {
    setCurrentMediaFile(null);
    updateCurrentProject(
      {
        title: sample.title,
        videoUrl: sample.videoUrl,
        videoDuration: sample.duration,
        videoAspectRatio: sample.aspectRatio || "16:9",
        subtitles: [...sample.defaultCaptions],
      },
      true,
      `Loaded Sample: ${sample.title}`
    );
    setCurrentTime(0);
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
    }
  };

  const handleUploadMediaFile = async (file: File, subtitleFile?: File, autoTranscribe?: boolean) => {
    setCurrentMediaFile(file);
    const videoUrl = URL.createObjectURL(file);
    let subs = currentProject.subtitles;

    if (subtitleFile) {
      const subContent = await subtitleFile.text();
      subs = parseSubtitleFile(subContent);
    } else {
      subs = [];
    }

    // Pre-calculate video dimensions and duration
    const tempVideo = document.createElement("video");
    tempVideo.preload = "metadata";
    tempVideo.src = videoUrl;
    tempVideo.onloadedmetadata = () => {
      let detectedAspect: "16:9" | "9:16" | "1:1" | "4:5" = "16:9";
      if (tempVideo.videoWidth && tempVideo.videoHeight) {
        const ratio = tempVideo.videoWidth / tempVideo.videoHeight;
        if (ratio < 0.65) {
          detectedAspect = "9:16";
        } else if (ratio >= 0.65 && ratio < 0.9) {
          detectedAspect = "4:5";
        } else if (ratio >= 0.9 && ratio < 1.2) {
          detectedAspect = "1:1";
        } else {
          detectedAspect = "16:9";
        }
      }
      const dur = tempVideo.duration && isFinite(tempVideo.duration) ? tempVideo.duration : 30;
      updateCurrentProject({
        videoDuration: dur,
        videoAspectRatio: detectedAspect,
      });
      setDuration(dur);
    };

    updateCurrentProject(
      {
        title: file.name.replace(/\.[^/.]+$/, ""),
        videoUrl,
        subtitles: subs,
      },
      true,
      `Uploaded Media File: ${file.name}`
    );
    setCurrentTime(0);

    if (autoTranscribe && !subtitleFile) {
      setTimeout(() => {
        setIsAIModalOpen(true);
      }, 400);
    }
  };

  const handleRecordCaptured = (blob: Blob, autoTranscribe?: boolean) => {
    setCurrentMediaFile(blob);
    const videoUrl = URL.createObjectURL(blob);

    const tempVideo = document.createElement("video");
    tempVideo.preload = "metadata";
    tempVideo.src = videoUrl;
    tempVideo.onloadedmetadata = () => {
      let detectedAspect: "16:9" | "9:16" | "1:1" | "4:5" = "16:9";
      if (tempVideo.videoWidth && tempVideo.videoHeight) {
        const ratio = tempVideo.videoWidth / tempVideo.videoHeight;
        if (ratio < 0.65) detectedAspect = "9:16";
        else if (ratio >= 0.65 && ratio < 0.9) detectedAspect = "4:5";
        else if (ratio >= 0.9 && ratio < 1.2) detectedAspect = "1:1";
      }
      const dur = tempVideo.duration && isFinite(tempVideo.duration) ? tempVideo.duration : 30;
      updateCurrentProject({
        videoDuration: dur,
        videoAspectRatio: detectedAspect,
      });
      setDuration(dur);
    };

    updateCurrentProject(
      {
        title: `Camera Recording ${new Date().toLocaleTimeString()}`,
        videoUrl,
        subtitles: [],
      },
      true,
      "Captured Live Camera Recording"
    );
    setCurrentTime(0);

    if (autoTranscribe) {
      setTimeout(() => {
        setIsAIModalOpen(true);
      }, 400);
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-zinc-950 text-zinc-100 overflow-hidden font-sans antialiased">
      {/* Top Main Navigation & Action Bar */}
      <Header
        project={currentProject}
        projectTitle={currentProject.title}
        onUpdateTitle={(title) => updateCurrentProject({ title })}
        onUpdateProjectTitle={(title) => updateCurrentProject({ title })}
        onUpdateAspectRatio={(ratio) => updateCurrentProject({ videoAspectRatio: ratio })}
        canUndo={currentProject.versions.length > 1}
        canRedo={false}
        onUndo={() => {
          if (currentProject.versions.length > 1) {
            handleRestoreVersion(currentProject.versions[1]);
          }
        }}
        onRedo={() => {}}
        onOpenUploadModal={() => setIsUploadModalOpen(true)}
        onOpenVersions={() => setIsVersionModalOpen(true)}
        onOpenCloudSync={() => setIsCloudModalOpen(true)}
        onOpenAITools={() => setIsAIModalOpen(true)}
        onOpenExport={() => setIsExportModalOpen(true)}
        onResetToDefault={handleResetToDefault}
        onQuickTranslate={(langCode) => handleTranslateCaptions(langCode, false)}
        isSyncing={isSyncing}
        isCloudSynced={currentProject.isCloudSynced}
        lastSavedTime={lastSavedTime}
        showCaptionsPanel={showCaptionsPanel}
        onToggleCaptionsPanel={() => setShowCaptionsPanel(!showCaptionsPanel)}
        showStylePanel={showStylePanel}
        onToggleStylePanel={() => setShowStylePanel(!showStylePanel)}
      />

      {/* Main Workspace Area */}
      <div className="flex-1 flex overflow-hidden relative pb-14 lg:pb-0">
        {/* Desktop Layout (lg and above): 3-Column Split Studio */}
        {isDesktop ? (
          <div className="flex flex-1 overflow-hidden relative">
            {/* Left Side: Caption Cue List & Transcript Search */}
            {showCaptionsPanel && (
              <CaptionList
                subtitles={currentProject.subtitles}
                currentTime={currentTime}
                selectedSubtitleId={selectedSubtitleId}
                onSelectSubtitle={(id) => {
                  setSelectedSubtitleId(id);
                  const sub = currentProject.subtitles.find((s) => s.id === id);
                  if (sub) handleSeek(sub.startTime);
                }}
                onUpdateSubtitle={handleUpdateSubtitle}
                onDeleteSubtitle={handleDeleteSubtitle}
                onDuplicateSubtitle={handleDuplicateSubtitle}
                onAddSubtitle={handleAddSubtitle}
                onPlaySnippet={handlePlaySnippet}
                onSplitSubtitle={handleSplitSubtitle}
                onMergeSubtitle={handleMergeSubtitle}
                onShiftAllTimestamps={handleShiftAllTimestamps}
                onRechunkSubtitles={handleRechunkSubtitles}
                onOpenAITools={() => setIsAIModalOpen(true)}
              />
            )}

            {/* Center: Stage with Interactive Video Canvas & On-Screen Overlay */}
            <div className="flex-1 flex flex-col bg-zinc-950/90 overflow-hidden relative">
              <VideoCanvas
                videoUrl={currentProject.videoUrl}
                aspectRatio={currentProject.videoAspectRatio}
                onChangeAspectRatio={(aspectRatio) => updateCurrentProject({ videoAspectRatio: aspectRatio })}
                subtitles={currentProject.subtitles}
                style={currentProject.style}
                onUpdateStyle={handleUpdateStyle}
                currentTime={currentTime}
                isPlaying={isPlaying}
                onPlayPause={handlePlayPause}
                onSeek={handleSeek}
                onTimeUpdate={handleTimeUpdate}
                onDurationChange={handleDurationChange}
                playbackRate={playbackRate}
                onChangePlaybackRate={handlePlaybackRateChange}
                volume={volume}
                onChangeVolume={handleVolumeChange}
                isMuted={isMuted}
                onToggleMute={handleToggleMute}
                videoRef={videoRef}
                bilingualMode={currentProject.bilingualMode}
                onOpenUploadModal={() => setIsUploadModalOpen(true)}
                onOpenExport={() => setIsExportModalOpen(true)}
                onOpenAITools={() => setIsAIModalOpen(true)}
              />

              {/* Bottom Waveform & Frame-Accurate Timeline Editor */}
              <TimelineEditor
                duration={duration}
                currentTime={currentTime}
                isPlaying={isPlaying}
                onPlayPause={handlePlayPause}
                onSeek={handleSeek}
                subtitles={currentProject.subtitles}
                onUpdateSubtitle={handleUpdateSubtitle}
                onAddSubtitle={handleAddSubtitle}
                onSplitSubtitle={handleSplitSubtitle}
                onMergeSubtitle={handleMergeSubtitle}
                onSnapGaps={handleSnapGaps}
                selectedSubtitleId={selectedSubtitleId}
                onSelectSubtitle={(id) => setSelectedSubtitleId(id)}
              />
            </div>

            {/* Right Side: Style Customization Studio */}
            {showStylePanel && (
              <StyleEditor
                style={currentProject.style}
                onUpdateStyle={handleUpdateStyle}
                onApplyPreset={handleApplyPreset}
                bilingualMode={currentProject.bilingualMode}
                onToggleBilingualMode={() => updateCurrentProject({ bilingualMode: !currentProject.bilingualMode })}
                onRechunkSubtitles={handleRechunkSubtitles}
              />
            )}
          </div>
        ) : (
          /* Mobile & Tablet Responsive Views */
          <div className="flex flex-1 flex-col overflow-hidden relative w-full h-full">
            {mobileTab === "canvas" && (
              <div className="flex-1 flex flex-col bg-zinc-950/90 overflow-hidden relative">
                <VideoCanvas
                  videoUrl={currentProject.videoUrl}
                  aspectRatio={currentProject.videoAspectRatio}
                  onChangeAspectRatio={(aspectRatio) => updateCurrentProject({ videoAspectRatio: aspectRatio })}
                  subtitles={currentProject.subtitles}
                  style={currentProject.style}
                  onUpdateStyle={handleUpdateStyle}
                  currentTime={currentTime}
                  isPlaying={isPlaying}
                  onPlayPause={handlePlayPause}
                  onSeek={handleSeek}
                  onTimeUpdate={handleTimeUpdate}
                  onDurationChange={handleDurationChange}
                  playbackRate={playbackRate}
                  onChangePlaybackRate={handlePlaybackRateChange}
                  volume={volume}
                  onChangeVolume={handleVolumeChange}
                  isMuted={isMuted}
                  onToggleMute={handleToggleMute}
                  videoRef={videoRef}
                  bilingualMode={currentProject.bilingualMode}
                  onOpenUploadModal={() => setIsUploadModalOpen(true)}
                  onOpenExport={() => setIsExportModalOpen(true)}
                  onOpenAITools={() => setIsAIModalOpen(true)}
                />
                <div className="h-36 sm:h-44 border-t border-zinc-800 shrink-0">
                  <TimelineEditor
                    duration={duration}
                    currentTime={currentTime}
                    isPlaying={isPlaying}
                    onPlayPause={handlePlayPause}
                    onSeek={handleSeek}
                    subtitles={currentProject.subtitles}
                    onUpdateSubtitle={handleUpdateSubtitle}
                    onAddSubtitle={handleAddSubtitle}
                    onSplitSubtitle={handleSplitSubtitle}
                    onMergeSubtitle={handleMergeSubtitle}
                    onSnapGaps={handleSnapGaps}
                    selectedSubtitleId={selectedSubtitleId}
                    onSelectSubtitle={(id) => setSelectedSubtitleId(id)}
                  />
                </div>
              </div>
            )}

            {mobileTab === "captions" && (
              <div className="flex-1 flex flex-col overflow-hidden bg-zinc-900">
                <CaptionList
                  subtitles={currentProject.subtitles}
                  currentTime={currentTime}
                  selectedSubtitleId={selectedSubtitleId}
                  onSelectSubtitle={(id) => {
                    setSelectedSubtitleId(id);
                    const sub = currentProject.subtitles.find((s) => s.id === id);
                    if (sub) handleSeek(sub.startTime);
                  }}
                  onUpdateSubtitle={handleUpdateSubtitle}
                  onDeleteSubtitle={handleDeleteSubtitle}
                  onDuplicateSubtitle={handleDuplicateSubtitle}
                  onAddSubtitle={handleAddSubtitle}
                  onPlaySnippet={handlePlaySnippet}
                  onSplitSubtitle={handleSplitSubtitle}
                  onMergeSubtitle={handleMergeSubtitle}
                  onShiftAllTimestamps={handleShiftAllTimestamps}
                  onRechunkSubtitles={handleRechunkSubtitles}
                  onOpenAITools={() => setIsAIModalOpen(true)}
                />
              </div>
            )}

            {mobileTab === "style" && (
              <div className="flex-1 flex flex-col overflow-hidden bg-zinc-900">
                <StyleEditor
                  style={currentProject.style}
                  onUpdateStyle={handleUpdateStyle}
                  onApplyPreset={handleApplyPreset}
                  bilingualMode={currentProject.bilingualMode}
                  onToggleBilingualMode={() => updateCurrentProject({ bilingualMode: !currentProject.bilingualMode })}
                  onRechunkSubtitles={handleRechunkSubtitles}
                />
              </div>
            )}

            {mobileTab === "timeline" && (
              <div className="flex-1 flex flex-col bg-zinc-950 overflow-hidden">
                <div className="p-3 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span className="font-bold text-xs text-zinc-200">Expanded Waveform Timeline</span>
                  </div>
                  <button
                    onClick={() => setMobileTab("canvas")}
                    className="px-2.5 py-1 bg-amber-400 text-zinc-950 font-bold rounded text-xs"
                  >
                    View Canvas
                  </button>
                </div>
                <div className="flex-1 overflow-hidden">
                  <TimelineEditor
                    duration={duration}
                    currentTime={currentTime}
                    isPlaying={isPlaying}
                    onPlayPause={handlePlayPause}
                    onSeek={handleSeek}
                    subtitles={currentProject.subtitles}
                    onUpdateSubtitle={handleUpdateSubtitle}
                    onAddSubtitle={handleAddSubtitle}
                    onSplitSubtitle={handleSplitSubtitle}
                    onMergeSubtitle={handleMergeSubtitle}
                    onSnapGaps={handleSnapGaps}
                    selectedSubtitleId={selectedSubtitleId}
                    onSelectSubtitle={(id) => setSelectedSubtitleId(id)}
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile & Tablet Bottom Navigation Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 h-15 bg-zinc-900/98 backdrop-blur-xl border-t border-zinc-800/90 z-40 flex items-center justify-around px-2 pb-safe select-none shadow-2xl">
        <button
          onClick={() => setMobileTab("canvas")}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 transition-all ${
            mobileTab === "canvas"
              ? "text-amber-400 font-bold scale-105"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <div className={`p-1 rounded-lg ${mobileTab === "canvas" ? "bg-amber-400/15" : ""}`}>
            <Film className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 font-medium">Video</span>
        </button>

        <button
          onClick={() => setMobileTab("captions")}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 relative transition-all ${
            mobileTab === "captions"
              ? "text-amber-400 font-bold scale-105"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <div className={`p-1 rounded-lg relative ${mobileTab === "captions" ? "bg-amber-400/15" : ""}`}>
            <FileText className="w-4 h-4" />
            {currentProject.subtitles.length > 0 && (
              <span className="absolute -top-1 -right-2 bg-amber-400 text-zinc-950 text-[9px] font-black px-1 rounded-full shadow-sm">
                {currentProject.subtitles.length}
              </span>
            )}
          </div>
          <span className="text-[10px] mt-0.5 font-medium">Captions</span>
        </button>

        <button
          onClick={() => setMobileTab("style")}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 transition-all ${
            mobileTab === "style"
              ? "text-amber-400 font-bold scale-105"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <div className={`p-1 rounded-lg ${mobileTab === "style" ? "bg-amber-400/15" : ""}`}>
            <Palette className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 font-medium">Styles</span>
        </button>

        <button
          onClick={() => setMobileTab("timeline")}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 transition-all ${
            mobileTab === "timeline"
              ? "text-amber-400 font-bold scale-105"
              : "text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <div className={`p-1 rounded-lg ${mobileTab === "timeline" ? "bg-amber-400/15" : ""}`}>
            <Clock className="w-4 h-4" />
          </div>
          <span className="text-[10px] mt-0.5 font-medium">Timeline</span>
        </button>
      </nav>

      {/* Modals */}
      <AIToolsModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        onGenerateCaptions={handleGenerateCaptions}
        onTranslateCaptions={handleTranslateCaptions}
        onEnhanceCaptions={handleEnhanceCaptions}
        currentSubtitles={currentProject.subtitles}
        currentLanguage={currentProject.targetLanguage}
        videoDuration={duration || currentProject.videoDuration || 0}
      />

      <VersionHistoryModal
        isOpen={isVersionModalOpen}
        onClose={() => setIsVersionModalOpen(false)}
        versions={currentProject.versions}
        currentSubtitles={currentProject.subtitles}
        currentStyle={currentProject.style}
        onCreateSnapshot={handleCreateSnapshot}
        onRestoreVersion={handleRestoreVersion}
      />

      <CloudSyncModal
        isOpen={isCloudModalOpen}
        onClose={() => setIsCloudModalOpen(false)}
        currentProject={currentProject}
        allProjects={projects}
        onSelectProject={(id) => setActiveProjectId(id)}
        onCreateNewProject={handleCreateNewProject}
        onDuplicateProject={handleDuplicateProject}
        onDeleteProject={handleDeleteProject}
        onToggleCloudSync={(enabled) => updateCurrentProject({ isCloudSynced: enabled })}
        onForceSync={handleForceSync}
        isSyncing={isSyncing}
        onImportProjectJSON={handleImportProjectJSON}
        onResetToDefault={handleResetToDefault}
      />

      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        project={currentProject}
        subtitles={currentProject.subtitles}
        style={currentProject.style}
        videoElement={videoRef.current}
        mediaFile={currentMediaFile}
      />

      <UploadOrSampleModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onSelectSample={handleSelectSample}
        onUploadMediaFile={handleUploadMediaFile}
        onRecordCaptured={handleRecordCaptured}
      />
    </div>
  );
}

export default App;
