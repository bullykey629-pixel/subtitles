import React, { useRef, useState, useEffect } from "react";
import {
  Play,
  Pause,
  Scissors,
  Plus,
  Link,
  ZoomIn,
  ZoomOut,
  Maximize,
  ChevronLeft,
  ChevronRight,
  Zap,
} from "lucide-react";
import { SubtitleItem } from "../types";

interface TimelineEditorProps {
  duration: number;
  currentTime: number;
  isPlaying: boolean;
  onPlayPause: () => void;
  onSeek: (time: number) => void;
  subtitles: SubtitleItem[];
  onUpdateSubtitle: (id: string, updates: Partial<SubtitleItem>) => void;
  onAddSubtitle: (time: number) => void;
  onSplitSubtitle: (id: string, splitTime: number) => void;
  onMergeSubtitle: (id: string) => void;
  onSnapGaps: () => void;
  selectedSubtitleId: string | null;
  onSelectSubtitle: (id: string) => void;
}

export const TimelineEditor: React.FC<TimelineEditorProps> = ({
  duration,
  currentTime,
  isPlaying,
  onPlayPause,
  onSeek,
  subtitles,
  onUpdateSubtitle,
  onAddSubtitle,
  onSplitSubtitle,
  onMergeSubtitle,
  onSnapGaps,
  selectedSubtitleId,
  onSelectSubtitle,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [zoomLevel, setZoomLevel] = useState(1); // 1 = fit/normal, 2 = 2x, 4 = 4x
  const [isScrubbing, setIsScrubbing] = useState(false);

  // Dragging / Resizing caption block states
  const [draggingBlockId, setDraggingBlockId] = useState<string | null>(null);
  const [dragType, setDragType] = useState<"move" | "resize-start" | "resize-end" | null>(null);
  const [dragStartX, setDragStartX] = useState(0);
  const [dragInitialStart, setDragInitialStart] = useState(0);
  const [dragInitialEnd, setDragInitialEnd] = useState(0);

  const totalDuration = Math.max(1, duration || 30);
  const pixelsPerSecond = 60 * zoomLevel;
  const trackWidth = Math.max(800, totalDuration * pixelsPerSecond);

  // Find active subtitle at current playhead
  const activeSub = subtitles.find(
    (s) => currentTime >= s.startTime && currentTime <= s.endTime
  );

  // Handle Playhead Scrubbing on Track Click / Drag / Touch
  const handleTrackMouseDown = (e: React.MouseEvent) => {
    if (!trackRef.current) return;
    const rect = trackRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const newTime = Math.max(0, Math.min(totalDuration, clickX / pixelsPerSecond));
    onSeek(newTime);
    setIsScrubbing(true);
  };

  const handleTrackTouchStart = (e: React.TouchEvent) => {
    if (!trackRef.current || e.touches.length === 0) return;
    const rect = trackRef.current.getBoundingClientRect();
    const touchX = e.touches[0].clientX - rect.left;
    const newTime = Math.max(0, Math.min(totalDuration, touchX / pixelsPerSecond));
    onSeek(newTime);
    setIsScrubbing(true);
  };

  useEffect(() => {
    const handlePointerMove = (clientX: number) => {
      if (isScrubbing && trackRef.current) {
        const rect = trackRef.current.getBoundingClientRect();
        const clickX = clientX - rect.left;
        const newTime = Math.max(0, Math.min(totalDuration, clickX / pixelsPerSecond));
        onSeek(newTime);
      }

      // Handle Caption Block Dragging or Resizing
      if (draggingBlockId && trackRef.current && dragType) {
        const deltaPixels = clientX - dragStartX;
        const deltaTime = deltaPixels / pixelsPerSecond;

        if (dragType === "move") {
          const duration = dragInitialEnd - dragInitialStart;
          let newStart = Math.max(0, dragInitialStart + deltaTime);
          let newEnd = newStart + duration;
          if (newEnd > totalDuration) {
            newEnd = totalDuration;
            newStart = Math.max(0, newEnd - duration);
          }
          onUpdateSubtitle(draggingBlockId, {
            startTime: Math.round(newStart * 100) / 100,
            endTime: Math.round(newEnd * 100) / 100,
          });
        } else if (dragType === "resize-start") {
          let newStart = Math.max(0, Math.min(dragInitialEnd - 0.3, dragInitialStart + deltaTime));
          onUpdateSubtitle(draggingBlockId, {
            startTime: Math.round(newStart * 100) / 100,
          });
        } else if (dragType === "resize-end") {
          let newEnd = Math.max(dragInitialStart + 0.3, Math.min(totalDuration, dragInitialEnd + deltaTime));
          onUpdateSubtitle(draggingBlockId, {
            endTime: Math.round(newEnd * 100) / 100,
          });
        }
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      handlePointerMove(e.clientX);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        handlePointerMove(e.touches[0].clientX);
      }
    };

    const handlePointerUp = () => {
      setIsScrubbing(false);
      setDraggingBlockId(null);
      setDragType(null);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handlePointerUp);
    window.addEventListener("touchmove", handleTouchMove, { passive: true });
    window.addEventListener("touchend", handlePointerUp);
    window.addEventListener("touchcancel", handlePointerUp);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handlePointerUp);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handlePointerUp);
      window.removeEventListener("touchcancel", handlePointerUp);
    };
  }, [
    isScrubbing,
    draggingBlockId,
    dragType,
    dragStartX,
    dragInitialStart,
    dragInitialEnd,
    pixelsPerSecond,
    totalDuration,
    onSeek,
    onUpdateSubtitle,
  ]);

  const startBlockDrag = (
    clientX: number,
    sub: SubtitleItem,
    type: "move" | "resize-start" | "resize-end"
  ) => {
    setDraggingBlockId(sub.id);
    setDragType(type);
    setDragStartX(clientX);
    setDragInitialStart(sub.startTime);
    setDragInitialEnd(sub.endTime);
    onSelectSubtitle(sub.id);
  };

  // Time rulers markings
  const renderRuler = () => {
    const marks = [];
    const step = zoomLevel >= 2 ? 1 : 2; // every 1s or 2s mark
    for (let sec = 0; sec <= totalDuration; sec += step) {
      const leftPos = sec * pixelsPerSecond;
      marks.push(
        <div
          key={sec}
          className="absolute top-0 flex flex-col items-center select-none pointer-events-none"
          style={{ left: `${leftPos}px` }}
        >
          <span className="text-[10px] font-mono text-zinc-500 -translate-x-1/2">
            {formatRulerTime(sec)}
          </span>
          <div className="w-px h-2 bg-zinc-700 mt-0.5" />
        </div>
      );
    }
    return marks;
  };

  return (
    <div className="h-44 bg-zinc-900 border-t border-zinc-800 flex flex-col select-none z-20">
      {/* Top Toolbar */}
      <div className="h-11 px-3 sm:px-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/90 text-xs overflow-x-auto gap-2 scrollbar-none">
        {/* Playback Controls & Frame Steppers */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
          <button
            onClick={onPlayPause}
            className="w-8 h-8 rounded-lg bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold flex items-center justify-center transition-all active:scale-95 shadow-sm"
            title="Play / Pause (Space)"
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
          </button>

          <button
            onClick={() => onSeek(Math.max(0, currentTime - 0.1))}
            className="p-1.5 rounded-md hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors"
            title="Step back 0.1s"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => onSeek(Math.min(totalDuration, currentTime + 0.1))}
            className="p-1.5 rounded-md hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 transition-colors"
            title="Step forward 0.1s"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-px bg-zinc-800 mx-0.5 hidden sm:block" />

          <div className="font-mono text-zinc-300 bg-zinc-950 px-2 py-0.5 rounded border border-zinc-800 text-[11px] whitespace-nowrap">
            <span className="text-amber-400 font-bold">{formatPreciseTime(currentTime)}</span>
            <span className="text-zinc-600"> / </span>
            <span className="text-zinc-400">{formatPreciseTime(totalDuration)}</span>
          </div>
        </div>

        {/* Timeline Editing Actions: Split, Merge, Add, Snap */}
        <div className="flex items-center gap-1 sm:gap-1.5 flex-shrink-0">
          <button
            onClick={() => {
              if (activeSub) {
                onSplitSubtitle(activeSub.id, currentTime);
              }
            }}
            disabled={!activeSub || currentTime <= activeSub.startTime + 0.2 || currentTime >= activeSub.endTime - 0.2}
            className={`flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-md text-[11px] font-medium border transition-all ${
              activeSub && currentTime > activeSub.startTime + 0.2 && currentTime < activeSub.endTime - 0.2
                ? "bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border-zinc-700 hover:border-amber-400/50"
                : "text-zinc-600 border-transparent cursor-not-allowed"
            }`}
            title="Split subtitle at current playhead (✂️)"
          >
            <Scissors className="w-3 h-3 text-amber-400" />
            <span className="whitespace-nowrap">Split</span>
          </button>

          <button
            onClick={() => {
              const target = selectedSubtitleId || activeSub?.id;
              if (target) onMergeSubtitle(target);
            }}
            disabled={!selectedSubtitleId && !activeSub}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-md text-[11px] font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 transition-all"
            title="Merge with next subtitle block"
          >
            <Link className="w-3 h-3 text-sky-400" />
            <span className="whitespace-nowrap">Merge</span>
          </button>

          <button
            onClick={() => onAddSubtitle(currentTime)}
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-md text-[11px] font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 transition-all"
            title="Add new subtitle cue at current playhead"
          >
            <Plus className="w-3 h-3 text-emerald-400" />
            <span className="whitespace-nowrap">Add Cue</span>
          </button>

          <button
            onClick={onSnapGaps}
            className="hidden sm:flex items-center gap-1 px-2 py-1.5 rounded-md text-[11px] font-medium bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 transition-all"
            title="Auto-snap small gaps between subtitles"
          >
            <Zap className="w-3 h-3 text-amber-400" />
            <span>Snap</span>
          </button>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={() => setZoomLevel((z) => Math.max(0.5, z - 0.25))}
            className="p-1.5 rounded hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-[10px] font-mono text-zinc-400 w-7 text-center">{Math.round(zoomLevel * 100)}%</span>
          <button
            onClick={() => setZoomLevel((z) => Math.min(4, z + 0.25))}
            className="p-1.5 rounded hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Interactive Timeline Scroll Container */}
      <div
        ref={containerRef}
        className="flex-1 overflow-x-auto overflow-y-hidden relative bg-zinc-950/80 cursor-pointer touch-pan-x"
      >
        <div
          ref={trackRef}
          onMouseDown={handleTrackMouseDown}
          onTouchStart={handleTrackTouchStart}
          style={{ width: `${trackWidth}px` }}
          className="h-full relative select-none"
        >
          {/* Time Ruler */}
          <div className="h-6 w-full relative border-b border-zinc-800/80 bg-zinc-900/40">
            {renderRuler()}
          </div>

          {/* Subtitle Blocks Track */}
          <div className="h-16 relative mt-2 px-2">
            {subtitles.map((sub) => {
              const startX = sub.startTime * pixelsPerSecond;
              const width = Math.max(30, (sub.endTime - sub.startTime) * pixelsPerSecond);
              const isCurrent = currentTime >= sub.startTime && currentTime <= sub.endTime;
              const isSelected = selectedSubtitleId === sub.id;

              return (
                <div
                  key={sub.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectSubtitle(sub.id);
                    onSeek(sub.startTime);
                  }}
                  onMouseDown={(e) => {
                    e.stopPropagation();
                    startBlockDrag(e.clientX, sub, "move");
                  }}
                  onTouchStart={(e) => {
                    if (e.touches.length > 0) {
                      e.stopPropagation();
                      startBlockDrag(e.touches[0].clientX, sub, "move");
                    }
                  }}
                  style={{
                    left: `${startX}px`,
                    width: `${width}px`,
                  }}
                  className={`absolute top-1 bottom-1 rounded-lg border flex items-center px-2 text-xs font-semibold cursor-grab active:cursor-grabbing overflow-hidden group shadow-md transition-colors ${
                    isCurrent
                      ? "bg-amber-500/90 text-zinc-950 border-amber-300 ring-2 ring-amber-400/40"
                      : isSelected
                      ? "bg-zinc-700 text-zinc-100 border-amber-400"
                      : "bg-zinc-800 hover:bg-zinc-750 text-zinc-200 border-zinc-700 hover:border-zinc-500"
                  }`}
                  title={`${sub.speaker ? sub.speaker + ": " : ""}${sub.text} (${formatPreciseTime(sub.startTime)} - ${formatPreciseTime(sub.endTime)})`}
                >
                  {/* Left Resize Handle */}
                  <div
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startBlockDrag(e.clientX, sub, "resize-start");
                    }}
                    onTouchStart={(e) => {
                      if (e.touches.length > 0) {
                        e.stopPropagation();
                        startBlockDrag(e.touches[0].clientX, sub, "resize-start");
                      }
                    }}
                    className="absolute left-0 top-0 bottom-0 w-3 sm:w-2.5 cursor-ew-resize hover:bg-amber-300/60 transition-colors flex items-center justify-center opacity-70 sm:opacity-0 group-hover:opacity-100 z-10"
                  >
                    <div className="w-1 sm:w-0.5 h-3 bg-zinc-950 rounded-full" />
                  </div>

                  {/* Subtitle Text Preview */}
                  <span className="truncate w-full px-1 text-[11px] leading-tight select-none">
                    {sub.text}
                  </span>

                  {/* Right Resize Handle */}
                  <div
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      startBlockDrag(e.clientX, sub, "resize-end");
                    }}
                    onTouchStart={(e) => {
                      if (e.touches.length > 0) {
                        e.stopPropagation();
                        startBlockDrag(e.touches[0].clientX, sub, "resize-end");
                      }
                    }}
                    className="absolute right-0 top-0 bottom-0 w-3 sm:w-2.5 cursor-ew-resize hover:bg-amber-300/60 transition-colors flex items-center justify-center opacity-70 sm:opacity-0 group-hover:opacity-100 z-10"
                  >
                    <div className="w-1 sm:w-0.5 h-3 bg-zinc-950 rounded-full" />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Draggable Playhead Scrubber Line */}
          <div
            style={{ left: `${currentTime * pixelsPerSecond}px` }}
            className="absolute top-0 bottom-0 w-0.5 bg-amber-400 z-30 pointer-events-none -translate-x-1/2 flex flex-col items-center shadow-lg shadow-amber-400/50"
          >
            {/* Playhead Top Head Triangle */}
            <div className="w-3 h-3 bg-amber-400 rotate-45 -mt-1.5 rounded-xs shadow-md" />
          </div>
        </div>
      </div>
    </div>
  );
};

function formatRulerTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${String(secs).padStart(2, "0")}`;
}

function formatPreciseTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 100);
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${String(ms).padStart(2, "0")}`;
}
