import React, { useState } from "react";
import {
  Undo2,
  Redo2,
  History,
  Cloud,
  CloudOff,
  RefreshCw,
  Sparkles,
  Download,
  Languages,
  FolderKanban,
  Smartphone,
  Monitor,
  Square,
  Share2,
  Video,
  Menu,
  X,
  Sliders,
  RotateCcw,
  Palette,
} from "lucide-react";
import { Project } from "../types";
import { SUPPORTED_LANGUAGES } from "../data/languages";

interface HeaderProps {
  project?: Project;
  projectTitle?: string;
  onUpdateTitle?: (title: string) => void;
  onUpdateProjectTitle?: (title: string) => void;
  onUpdateAspectRatio?: (ratio: "16:9" | "9:16" | "1:1" | "4:5") => void;
  canUndo?: boolean;
  canRedo?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
  onOpenVersions?: () => void;
  onOpenCloudSync?: () => void;
  onOpenAITools?: () => void;
  onOpenExport?: () => void;
  onOpenUploadModal?: () => void;
  onResetToDefault?: () => void;
  isSyncing?: boolean;
  isCloudSynced?: boolean;
  lastSavedTime?: number;
  onQuickTranslate?: (langCode: string) => void;
  showCaptionsPanel?: boolean;
  onToggleCaptionsPanel?: () => void;
  showStylePanel?: boolean;
  onToggleStylePanel?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  project,
  projectTitle,
  onUpdateTitle,
  onUpdateProjectTitle,
  onUpdateAspectRatio,
  canUndo = false,
  canRedo = false,
  onUndo,
  onRedo,
  onOpenVersions,
  onOpenCloudSync,
  onOpenAITools,
  onOpenExport,
  onOpenUploadModal,
  onResetToDefault,
  isSyncing = false,
  isCloudSynced,
  lastSavedTime,
  onQuickTranslate,
  showCaptionsPanel,
  onToggleCaptionsPanel,
  showStylePanel,
  onToggleStylePanel,
}) => {
  const currentTitle = project?.title || projectTitle || "Untitled Project";
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(currentTitle);
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Sync state when external project title changes
  React.useEffect(() => {
    setTitleInput(currentTitle);
  }, [currentTitle]);

  const handleTitleSubmit = () => {
    setIsEditingTitle(false);
    const trimmed = titleInput.trim();
    if (trimmed) {
      if (onUpdateTitle) onUpdateTitle(trimmed);
      else if (onUpdateProjectTitle) onUpdateProjectTitle(trimmed);
    } else {
      setTitleInput(currentTitle);
    }
  };

  const currentAspectRatio = project?.videoAspectRatio || "16:9";
  const currentLanguageCode = project?.currentLanguage || "en";
  const cloudSynced = isCloudSynced !== undefined ? isCloudSynced : (project?.isCloudSynced ?? true);

  const currentLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguageCode) ||
    SUPPORTED_LANGUAGES[0];

  return (
    <header className="h-14 sm:h-16 bg-zinc-900/95 backdrop-blur-md border-b border-zinc-800 text-zinc-100 px-3 sm:px-4 flex items-center justify-between select-none z-30 sticky top-0">
      {/* Left section: App Brand + Project Title */}
      <div className="flex items-center gap-2 sm:gap-4 min-w-0">
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-yellow-200 flex items-center justify-center shadow-md shadow-amber-500/20 text-zinc-950 font-black tracking-tight text-base sm:text-lg">
            C
          </div>
          <div className="hidden md:block">
            <h1 className="font-extrabold text-xs sm:text-sm tracking-tight text-zinc-100 flex items-center gap-1.5">
              CaptionAI <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 font-semibold border border-amber-400/30">PRO</span>
            </h1>
          </div>
        </div>

        <div className="h-4 w-px bg-zinc-800 hidden md:block" />

        {/* Project Title Editor */}
        <div className="flex items-center gap-1.5 min-w-0">
          {isEditingTitle ? (
            <input
              type="text"
              value={titleInput}
              onChange={(e) => setTitleInput(e.target.value)}
              onBlur={handleTitleSubmit}
              onKeyDown={(e) => e.key === "Enter" && handleTitleSubmit()}
              autoFocus
              className="bg-zinc-800 border border-amber-500/50 rounded-lg px-2 py-0.5 sm:px-2.5 sm:py-1 text-xs sm:text-sm text-zinc-100 focus:outline-none focus:ring-1 focus:ring-amber-400 w-28 sm:w-56"
            />
          ) : (
            <button
              onClick={() => {
                setTitleInput(currentTitle);
                setIsEditingTitle(true);
              }}
              className="flex items-center gap-1 text-xs sm:text-sm font-semibold text-zinc-200 hover:text-white px-1.5 sm:px-2 py-1 rounded-lg hover:bg-zinc-800/60 transition-colors group max-w-[100px] sm:max-w-[180px] md:max-w-xs truncate"
              title="Click to rename project"
            >
              <span className="truncate">{currentTitle}</span>
              <span className="text-zinc-500 text-xs opacity-0 group-hover:opacity-100 transition-opacity">✏️</span>
            </button>
          )}
        </div>

        {/* Mobile Quick Aspect Ratio Pill */}
        {onUpdateAspectRatio && (
          <button
            onClick={() => {
              const ratios: ("9:16" | "1:1" | "16:9" | "4:5")[] = ["9:16", "1:1", "16:9", "4:5"];
              const nextIndex = (ratios.indexOf(currentAspectRatio as any) + 1) % ratios.length;
              onUpdateAspectRatio(ratios[nextIndex]);
            }}
            className="xl:hidden flex items-center gap-1 px-2 py-1 rounded-full bg-zinc-800 border border-zinc-700/80 text-[11px] font-bold text-amber-400 active:scale-95 transition-all shadow-sm"
            title="Tap to change ratio (9:16 Reels / 16:9 Landscape / 1:1 Square)"
          >
            {currentAspectRatio === "9:16" && <Smartphone className="w-3 h-3 text-amber-400" />}
            {currentAspectRatio === "16:9" && <Monitor className="w-3 h-3 text-amber-400" />}
            {currentAspectRatio === "1:1" && <Square className="w-3 h-3 text-amber-400" />}
            {currentAspectRatio === "4:5" && <Smartphone className="w-3 h-3 text-amber-400" />}
            <span>{currentAspectRatio}</span>
          </button>
        )}

        {/* Media Upload / Switch Sample Button */}
        {onOpenUploadModal && (
          <button
            onClick={onOpenUploadModal}
            className="hidden sm:flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-medium text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-800 transition-all flex-shrink-0"
            title="Import Video or Pick Sample Demo"
          >
            <Video className="w-3.5 h-3.5 text-amber-400" />
            <span>Media</span>
          </button>
        )}

        {/* Aspect Ratio Toggles (Desktop / Large Tablet) */}
        {onUpdateAspectRatio && (
          <div className="hidden xl:flex items-center bg-zinc-950 p-0.5 rounded-lg border border-zinc-800">
            <button
              onClick={() => onUpdateAspectRatio("16:9")}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-all ${
                currentAspectRatio === "16:9"
                  ? "bg-zinc-800 text-amber-400 shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
              title="16:9 Landscape (YouTube, TV)"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>16:9</span>
            </button>
            <button
              onClick={() => onUpdateAspectRatio("9:16")}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-all ${
                currentAspectRatio === "9:16"
                  ? "bg-zinc-800 text-amber-400 shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
              title="9:16 Vertical (TikTok, Reels, Shorts)"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>9:16</span>
            </button>
            <button
              onClick={() => onUpdateAspectRatio("1:1")}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-all ${
                currentAspectRatio === "1:1"
                  ? "bg-zinc-800 text-amber-400 shadow-sm"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
              title="1:1 Square (Feed, Instagram)"
            >
              <Square className="w-3.5 h-3.5" />
              <span>1:1</span>
            </button>
          </div>
        )}
        {/* Panel Toggles for Desktop/Laptop/Tablet (Captions & Style) */}
        <div className="hidden lg:flex items-center bg-zinc-950 p-0.5 rounded-lg border border-zinc-800">
          {onToggleCaptionsPanel && (
            <button
              onClick={onToggleCaptionsPanel}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-all ${
                showCaptionsPanel
                  ? "bg-zinc-800 text-amber-400 shadow-sm"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
              title={showCaptionsPanel ? "Hide Captions Panel (Maximize Canvas)" : "Show Captions Panel"}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">List</span>
            </button>
          )}

          {onToggleStylePanel && (
            <button
              onClick={onToggleStylePanel}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium transition-all ${
                showStylePanel
                  ? "bg-zinc-800 text-amber-400 shadow-sm"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
              title={showStylePanel ? "Hide Style Panel (Maximize Canvas)" : "Show Style Panel"}
            >
              <Palette className="w-3.5 h-3.5" />
              <span className="hidden xl:inline">Style</span>
            </button>
          )}
        </div>
      </div>

      {/* Center section: Undo/Redo & Versions (Tablet & Desktop) */}
      <div className="hidden md:flex items-center gap-1 sm:gap-2">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          className={`p-2 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
            canUndo
              ? "text-zinc-300 hover:text-white hover:bg-zinc-800 active:scale-95"
              : "text-zinc-600 cursor-not-allowed"
          }`}
          title="Undo (Ctrl+Z)"
        >
          <Undo2 className="w-4 h-4" />
        </button>

        <button
          onClick={onRedo}
          disabled={!canRedo}
          className={`p-2 rounded-lg text-xs font-medium flex items-center gap-1 transition-all ${
            canRedo
              ? "text-zinc-300 hover:text-white hover:bg-zinc-800 active:scale-95"
              : "text-zinc-600 cursor-not-allowed"
          }`}
          title="Redo (Ctrl+Y)"
        >
          <Redo2 className="w-4 h-4" />
        </button>

        {onOpenVersions && (
          <button
            onClick={onOpenVersions}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-800 transition-all"
            title="Project Version History & Milestones"
          >
            <History className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden lg:inline">Versions</span>
            <span className="bg-zinc-800 text-zinc-400 px-1.5 py-0.2 rounded-full text-[10px] font-mono">
              {project?.versions?.length || 1}
            </span>
          </button>
        )}

        {onOpenCloudSync && (
          <button
            onClick={onOpenCloudSync}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-800 transition-all"
            title="Cloud Synchronization & Projects Manager"
          >
            {isSyncing ? (
              <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            ) : cloudSynced ? (
              <Cloud className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <CloudOff className="w-3.5 h-3.5 text-zinc-500" />
            )}
            <span className="hidden lg:inline">{cloudSynced ? "Cloud" : "Local"}</span>
          </button>
        )}

        {onResetToDefault && (
          <button
            onClick={() => {
              if (window.confirm("App ko pehle jaise (default initial state) par reset karna chahte hain? Sabhi captions aur style default restore ho jayenge.")) {
                onResetToDefault();
              }
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-amber-300/90 hover:text-amber-200 hover:bg-amber-500/10 border border-amber-500/20 transition-all"
            title="Reset to Initial Default Demo (Pehle Jaisa)"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden xl:inline">Reset</span>
          </button>
        )}
      </div>

      {/* Right section: AI Tools, Language, Export, and Mobile Menu */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Language selector dropdown */}
        {onQuickTranslate && (
          <div className="relative">
            <button
              onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
              className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-800 text-xs font-medium text-zinc-200 border border-zinc-700/60 transition-all"
              title="Translate Subtitles"
            >
              <Languages className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">{currentLangObj.flag} {currentLangObj.name}</span>
              <span className="md:hidden text-sm">{currentLangObj.flag}</span>
            </button>

            {isLangDropdownOpen && (
              <div className="absolute right-0 mt-2 w-56 max-h-72 overflow-y-auto bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl p-1 z-50">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-zinc-400 uppercase tracking-wider border-b border-zinc-800">
                  Translate to Language
                </div>
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      setIsLangDropdownOpen(false);
                      onQuickTranslate(lang.code);
                    }}
                    className={`w-full text-left flex items-center justify-between px-2.5 py-2 rounded-lg text-xs transition-colors ${
                      currentLanguageCode === lang.code
                        ? "bg-amber-400/10 text-amber-300 font-semibold"
                        : "text-zinc-300 hover:bg-zinc-800 hover:text-white"
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      <span>{lang.name}</span>
                    </span>
                    <span className="text-[10px] text-zinc-500 font-mono">{lang.nativeName}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* AI Caption Generator / Assistant */}
        {onOpenAITools && (
          <button
            onClick={onOpenAITools}
            className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all"
            title="Auto Transcribe Audio to Subtitles using Gemini AI"
          >
            <Sparkles className="w-3.5 h-3.5 fill-current" />
            <span className="hidden sm:inline">AI Captions</span>
            <span className="sm:hidden">AI</span>
          </button>
        )}

        {/* Export / Download Video Button */}
        {onOpenExport && (
          <button
            onClick={onOpenExport}
            className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-zinc-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all"
            title="Download Subtitled Video (MP4 / WebM)"
          >
            <Download className="w-3.5 sm:w-4 h-3.5 sm:h-4" />
            <span className="hidden sm:inline">Export</span>
          </button>
        )}

        {/* Mobile Menu Toggle Button */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden p-2 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
          title="More Options"
        >
          {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
        </button>
      </div>

      {/* Mobile Drawer Dropdown Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-14 left-0 right-0 bg-zinc-900 border-b border-zinc-800 shadow-2xl p-3 flex flex-col gap-2 z-50 animate-in fade-in slide-in-from-top-2">
          {/* Aspect Ratio Row */}
          {onUpdateAspectRatio && (
            <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-950/60 border border-zinc-800">
              <span className="text-xs text-zinc-400 font-medium">Aspect Ratio:</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onUpdateAspectRatio("16:9")}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${
                    currentAspectRatio === "16:9" ? "bg-amber-400 text-zinc-950 font-bold" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  16:9
                </button>
                <button
                  onClick={() => onUpdateAspectRatio("9:16")}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${
                    currentAspectRatio === "9:16" ? "bg-amber-400 text-zinc-950 font-bold" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  9:16
                </button>
                <button
                  onClick={() => onUpdateAspectRatio("1:1")}
                  className={`px-2.5 py-1 rounded text-xs font-medium transition-all ${
                    currentAspectRatio === "1:1" ? "bg-amber-400 text-zinc-950 font-bold" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  1:1
                </button>
              </div>
            </div>
          )}

          {/* Undo / Redo Row */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                onUndo?.();
                setIsMobileMenuOpen(false);
              }}
              disabled={!canUndo}
              className={`flex items-center justify-center gap-1.5 p-2 rounded-lg text-xs font-medium border border-zinc-800 ${
                canUndo ? "text-zinc-200 bg-zinc-800 hover:bg-zinc-750" : "text-zinc-600 bg-zinc-950 cursor-not-allowed"
              }`}
            >
              <Undo2 className="w-3.5 h-3.5" />
              <span>Undo</span>
            </button>
            <button
              onClick={() => {
                onRedo?.();
                setIsMobileMenuOpen(false);
              }}
              disabled={!canRedo}
              className={`flex items-center justify-center gap-1.5 p-2 rounded-lg text-xs font-medium border border-zinc-800 ${
                canRedo ? "text-zinc-200 bg-zinc-800 hover:bg-zinc-750" : "text-zinc-600 bg-zinc-950 cursor-not-allowed"
              }`}
            >
              <Redo2 className="w-3.5 h-3.5" />
              <span>Redo</span>
            </button>
          </div>

          {/* Versions, Cloud Sync & Reset Row */}
          <div className="grid grid-cols-2 gap-2">
            {onOpenVersions && (
              <button
                onClick={() => {
                  onOpenVersions();
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center justify-center gap-1.5 p-2 rounded-lg text-xs font-medium text-zinc-200 bg-zinc-800 hover:bg-zinc-750 border border-zinc-800"
              >
                <History className="w-3.5 h-3.5 text-amber-400" />
                <span>Versions ({project?.versions?.length || 1})</span>
              </button>
            )}
            {onOpenCloudSync && (
              <button
                onClick={() => {
                  onOpenCloudSync();
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center justify-center gap-1.5 p-2 rounded-lg text-xs font-medium text-zinc-200 bg-zinc-800 hover:bg-zinc-750 border border-zinc-800"
              >
                {cloudSynced ? <Cloud className="w-3.5 h-3.5 text-emerald-400" /> : <CloudOff className="w-3.5 h-3.5 text-zinc-500" />}
                <span>{cloudSynced ? "Cloud Sync" : "Local Save"}</span>
              </button>
            )}
          </div>

          {onResetToDefault && (
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                if (window.confirm("App ko pehle jaise (default initial state) par reset karna chahte hain?")) {
                  onResetToDefault();
                }
              }}
              className="w-full flex items-center justify-center gap-1.5 p-2 rounded-lg text-xs font-semibold text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
              <span>Reset to Default (Pehle Jaisa)</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};
