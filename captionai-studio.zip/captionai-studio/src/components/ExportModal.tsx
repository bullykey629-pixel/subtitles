import React, { useState, useMemo } from "react";
import {
  Download,
  Copy,
  Check,
  Film,
  FileCode,
  X,
  Sparkles,
  Loader2,
  AlertCircle,
  Play,
  RotateCcw,
  Sliders,
  Volume2,
} from "lucide-react";
import confetti from "canvas-confetti";
import { SubtitleItem, SubtitleStyle, Project } from "../types";
import {
  exportToSRT,
  exportToVTT,
  exportToTXT,
  exportToJSON,
  exportToCSV,
  exportToASS,
} from "../utils/captionConverters";
import { renderBurnedVideo, RenderProgress } from "../utils/videoRenderer";
import { safeJsonStringify } from "../utils/safeJson";

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  subtitles: SubtitleItem[];
  style: SubtitleStyle;
  videoElement: HTMLVideoElement | null;
  mediaFile?: File | Blob | null;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  project,
  subtitles,
  style,
  videoElement,
  mediaFile,
}) => {
  const [activeTab, setActiveTab] = useState<"video" | "subtitles">("video");
  const [selectedFormat, setSelectedFormat] = useState<"srt" | "vtt" | "txt" | "json" | "csv" | "ass">("srt");
  const [videoExportFormat, setVideoExportFormat] = useState<"webm" | "mp4">("mp4");
  const [copied, setCopied] = useState(false);
  const [resolution, setResolution] = useState<"original" | "1080p" | "720p">("original");

  // Video Rendering progress state
  const [renderProgress, setRenderProgress] = useState<RenderProgress>({
    status: "idle",
    progress: 0,
    currentTime: 0,
    totalTime: 0,
  });
  const [renderedResult, setRenderedResult] = useState<{
    url: string;
    filename: string;
    mimeType: string;
    sizeMB: string;
  } | null>(null);
  const [renderError, setRenderError] = useState<string | null>(null);

  const generatedContent = useMemo(() => {
    if (!isOpen) return "";
    switch (selectedFormat) {
      case "srt":
        return exportToSRT(subtitles || []);
      case "vtt":
        return exportToVTT(subtitles || []);
      case "txt":
        return exportToTXT(subtitles || [], true, true);
      case "json":
        return safeJsonStringify({ project, subtitles, style }, 2);
      case "csv":
        return exportToCSV(subtitles || []);
      case "ass":
        return exportToASS(subtitles || [], style);
      default:
        return "";
    }
  }, [selectedFormat, subtitles, style, project, isOpen]);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSubtitleFile = () => {
    const filename = `${(project?.title || "captions").toLowerCase().replace(/\s+/g, "_")}.${selectedFormat}`;
    const blob = new Blob([generatedContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);

    try {
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
    } catch {}
  };

  const handleStartVideoRender = async () => {
    setRenderError(null);
    setRenderedResult(null);

    // Pause any background playback so no audio plays during export
    if (videoElement && !videoElement.paused) {
      try {
        videoElement.pause();
      } catch {}
    }

    // Source priority: project.videoUrl > videoElement
    const videoSource = project.videoUrl || videoElement;
    if (!videoSource) {
      setRenderError("No active video source found. Please load or upload a video first.");
      return;
    }

    try {
      const result = await renderBurnedVideo(
        videoSource,
        subtitles,
        style,
        (prog) => {
          setRenderProgress(prog);
        },
        {
          bilingualMode: project.bilingualMode,
          resolution,
          format: videoExportFormat,
          mediaFile,
        }
      );

      const downloadUrl = URL.createObjectURL(result.blob);
      const sizeMB = (result.blob.size / (1024 * 1024)).toFixed(2);

      const titleSafe = (project?.title || "video").toLowerCase().replace(/[^a-z0-9]/g, "_");
      const ext = result.filename.split(".").pop() || videoExportFormat;
      const finalFilename = `${titleSafe}_with_subtitles.${ext}`;

      setRenderedResult({
        url: downloadUrl,
        filename: finalFilename,
        mimeType: result.mimeType,
        sizeMB,
      });

      // Trigger instant automatic download
      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = finalFilename;
      document.body.appendChild(a);
      a.click();
      a.remove();

      try {
        confetti({ particleCount: 80, spread: 80, origin: { y: 0.6 } });
      } catch {}
    } catch (err: any) {
      console.error("Burn-in video export error:", err);
      setRenderError(err.message || "Failed to render video frames. Please check your connection.");
      setRenderProgress({
        status: "error",
        progress: 0,
        currentTime: 0,
        totalTime: 0,
        errorMessage: err.message,
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center border border-amber-400/30">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-zinc-100">Export & Download Center</h2>
              <p className="text-[11px] text-zinc-400">
                Burn subtitles directly into video or download standard subtitle files
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center border-b border-zinc-800 bg-zinc-950/60 text-xs px-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab("video")}
            className={`py-2.5 px-3 sm:px-4 font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === "video"
                ? "border-amber-400 text-amber-300"
                : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Subtitled Video (MP4 / WebM)</span>
            <span className="sm:hidden">Video Export</span>
          </button>

          <button
            onClick={() => setActiveTab("subtitles")}
            className={`py-2.5 px-3 sm:px-4 font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === "subtitles"
                ? "border-amber-400 text-amber-300"
                : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Subtitle Files (.srt, .vtt, .ass, .json)</span>
            <span className="sm:hidden">Subtitle Files</span>
          </button>
        </div>

        {/* Tab 1: Video Burn-In Renderer */}
        {activeTab === "video" && (
          <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
            {/* Feature Overview Card */}
            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-zinc-200 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Hardcoded Subtitle Video Compositor
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Ready to Export
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                Aapke video me custom colors (Dual Highlight), chosen font ({style.fontFamily.split(",")[0]}), {style.fontSize}px size, aur active word animations seedhe frames ke andar bake ho jayenge.
              </p>
            </div>

            {/* Format & Audio Quality Selector */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Format */}
              <div className="p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 space-y-1.5">
                <label className="text-[11px] font-semibold text-zinc-300 flex items-center gap-1">
                  <Film className="w-3 h-3 text-amber-400" />
                  Video Format:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setVideoExportFormat("mp4")}
                    className={`py-2 px-2.5 rounded-lg border text-center transition-all text-xs font-semibold ${
                      videoExportFormat === "mp4"
                        ? "bg-amber-400 text-zinc-950 border-amber-400 shadow-sm"
                        : "bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700"
                    }`}
                  >
                    MP4 (Universal)
                  </button>
                  <button
                    onClick={() => setVideoExportFormat("webm")}
                    className={`py-2 px-2.5 rounded-lg border text-center transition-all text-xs font-semibold ${
                      videoExportFormat === "webm"
                        ? "bg-amber-400 text-zinc-950 border-amber-400 shadow-sm"
                        : "bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700"
                    }`}
                  >
                    WebM (Opus Audio)
                  </button>
                </div>
              </div>

              {/* Audio Track Preservation Indicator */}
              <div className="p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 flex flex-col justify-between space-y-1.5">
                <label className="text-[11px] font-semibold text-zinc-300 flex items-center gap-1">
                  <Volume2 className="w-3 h-3 text-emerald-400" />
                  Audio Synchronization:
                </label>
                <div className="flex items-center gap-2 p-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-[11px] text-emerald-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                  <span className="font-medium truncate">HQ 192kbps Audio Track Active</span>
                </div>
              </div>
            </div>

            {/* Resolution Selector */}
            <div className="p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 space-y-1.5">
              <label className="text-[11px] font-semibold text-zinc-300 flex items-center gap-1">
                <Sliders className="w-3 h-3 text-amber-400" />
                Export Quality / Resolution:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "original", label: "Original Quality", desc: "Native video size" },
                  { id: "1080p", label: "1080p Full HD", desc: "1920x1080 standard" },
                  { id: "720p", label: "720p Fast Export", desc: "1280x720 compact" },
                ].map((res) => (
                  <button
                    key={res.id}
                    onClick={() => setResolution(res.id as any)}
                    className={`p-2 rounded-lg border text-left transition-all ${
                      resolution === res.id
                        ? "bg-amber-400 text-zinc-950 font-bold border-amber-400 shadow-sm"
                        : "bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700"
                    }`}
                  >
                    <span className="text-[11px] font-bold block">{res.label}</span>
                    <span className={`text-[9px] block ${resolution === res.id ? "text-zinc-900" : "text-zinc-500"}`}>
                      {res.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Error Message Banner */}
            {renderError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1 flex-1">
                  <span className="font-bold block text-xs">Export Error</span>
                  <p className="text-[11px] leading-snug">{renderError}</p>
                  <button
                    onClick={handleStartVideoRender}
                    className="mt-1 px-2.5 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-[10px] font-semibold border border-rose-500/40 inline-flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" /> Retry Export
                  </button>
                </div>
              </div>
            )}

            {/* Progress Bar when rendering */}
            {renderProgress.status === "rendering" && (
              <div className="p-4 bg-zinc-950 border border-amber-500/40 rounded-xl space-y-2.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-amber-400 flex items-center gap-1.5">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Rendering video with subtitles...</span>
                  </span>
                  <span className="font-mono text-amber-300 font-bold">{renderProgress.progress}%</span>
                </div>
                <div className="w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden p-0.5">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-300 rounded-full transition-all duration-150"
                    style={{ width: `${renderProgress.progress}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] font-mono text-zinc-400">
                  <span>Encoding frames at 30 FPS</span>
                  <span>
                    {renderProgress.currentTime.toFixed(1)}s / {renderProgress.totalTime.toFixed(1)}s
                  </span>
                </div>
              </div>
            )}

            {/* Success Result Card & Download */}
            {renderedResult && (
              <div className="p-4 bg-emerald-500/10 border border-emerald-400/30 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Video export complete ({renderedResult.sizeMB} MB)!</span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-400/80 uppercase">
                    {renderedResult.mimeType.split(";")[0]}
                  </span>
                </div>

                {/* Inline Video Preview */}
                <div className="rounded-lg overflow-hidden border border-zinc-800 bg-black aspect-video max-h-44 flex items-center justify-center">
                  <video
                    src={renderedResult.url}
                    controls
                    autoPlay={false}
                    className="w-full h-full object-contain"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={renderedResult.url}
                    download={renderedResult.filename}
                    className="flex-1 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold flex items-center justify-center gap-2 text-xs shadow-md transition-all active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Again ({renderedResult.filename})</span>
                  </a>
                </div>
              </div>
            )}

            {/* Main Action Render Button */}
            <button
              onClick={handleStartVideoRender}
              disabled={renderProgress.status === "rendering"}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all disabled:opacity-50"
            >
              {renderProgress.status === "rendering" ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Video Frames ({renderProgress.progress}%)...</span>
                </>
              ) : (
                <>
                  <Film className="w-4 h-4 fill-current" />
                  <span>{renderedResult ? "Re-Render Video" : "Start Video Export & Download (MP4/WebM)"}</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Tab 2: Subtitle Files */}
        {activeTab === "subtitles" && (
          <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
            {/* Format Picker Pills */}
            <div>
              <label className="text-zinc-400 block mb-2 font-medium">Select Subtitle Format:</label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {[
                  { id: "srt", label: "SRT", desc: "Universal" },
                  { id: "vtt", label: "VTT", desc: "Web Players" },
                  { id: "txt", label: "TXT", desc: "Transcript" },
                  { id: "json", label: "JSON", desc: "Metadata" },
                  { id: "csv", label: "CSV", desc: "Spreadsheet" },
                  { id: "ass", label: "ASS", desc: "SubStation" },
                ].map((fmt) => (
                  <button
                    key={fmt.id}
                    onClick={() => setSelectedFormat(fmt.id as any)}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      selectedFormat === fmt.id
                        ? "bg-amber-400 text-zinc-950 font-bold border-amber-400 shadow-md"
                        : "bg-zinc-950 text-zinc-300 border-zinc-800 hover:border-zinc-700"
                    }`}
                  >
                    <span className="block text-xs uppercase font-mono">{fmt.label}</span>
                    <span
                      className={`text-[9px] block truncate ${
                        selectedFormat === fmt.id ? "text-zinc-900" : "text-zinc-500"
                      }`}
                    >
                      {fmt.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Live Syntax Preview */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-zinc-400 text-[11px]">
                <span>Preview ({subtitles.length} subtitle cues)</span>
                <span className="font-mono text-zinc-500 text-[10px]">
                  .{selectedFormat.toUpperCase()} format
                </span>
              </div>
              <pre className="p-3 bg-zinc-950 rounded-xl border border-zinc-800 text-zinc-300 font-mono text-[11px] max-h-48 overflow-y-auto whitespace-pre leading-relaxed select-text">
                {generatedContent}
              </pre>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleCopy}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-750 text-zinc-200 font-bold border border-zinc-700 flex items-center justify-center gap-2 transition-colors active:scale-95"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? "Copied to Clipboard!" : "Copy Text"}</span>
              </button>

              <button
                onClick={handleDownloadSubtitleFile}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>Download .{selectedFormat.toUpperCase()} File</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
