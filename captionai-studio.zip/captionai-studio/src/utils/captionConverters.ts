import { SubtitleItem, SubtitleStyle } from "../types";
import { safeJsonStringify } from "./safeJson";

// Format seconds into SRT timestamp: 00:01:23,456
export function formatSRTTime(seconds: number): string {
  const s = Math.max(0, seconds);
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = Math.floor(s % 60);
  const ms = Math.floor((s % 1) * 1000);

  return `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")},${String(ms).padStart(3, "0")}`;
}

// Format seconds into VTT timestamp: 00:01:23.456
export function formatVTTTime(seconds: number): string {
  const s = Math.max(0, seconds);
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = Math.floor(s % 60);
  const ms = Math.floor((s % 1) * 1000);

  return `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${String(ms).padStart(3, "0")}`;
}

// Format seconds into ASS timestamp: 0:01:23.45
export function formatASSTime(seconds: number): string {
  const s = Math.max(0, seconds);
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = Math.floor(s % 60);
  const cs = Math.floor((s % 1) * 100);

  return `${hrs}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
}

export function formatDurationDisplay(seconds: number): string {
  const s = Math.max(0, seconds);
  const mins = Math.floor(s / 60);
  const secs = Math.floor(s % 60);
  const ms = Math.floor((s % 1) * 10);
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${ms}`;
}

/**
 * Exports to standard .SRT
 */
export function exportToSRT(subtitles: SubtitleItem[]): string {
  return subtitles
    .sort((a, b) => a.startTime - b.startTime)
    .map((sub, index) => {
      const idx = index + 1;
      const start = formatSRTTime(sub.startTime);
      const end = formatSRTTime(sub.endTime);
      const text = sub.text.trim();
      return `${idx}\n${start} --> ${end}\n${text}\n`;
    })
    .join("\n");
}

/**
 * Exports to WebVTT (.vtt)
 */
export function exportToVTT(subtitles: SubtitleItem[]): string {
  const header = "WEBVTT\n\n";
  const body = subtitles
    .sort((a, b) => a.startTime - b.startTime)
    .map((sub, index) => {
      const start = formatVTTTime(sub.startTime);
      const end = formatVTTTime(sub.endTime);
      const speakerPrefix = sub.speaker ? `<v ${sub.speaker}>` : "";
      return `${index + 1}\n${start} --> ${end}\n${speakerPrefix}${sub.text.trim()}\n`;
    })
    .join("\n");
  return header + body;
}

/**
 * Exports to Plain Text (.txt)
 */
export function exportToTXT(subtitles: SubtitleItem[], includeTimestamps = true, includeSpeakers = true): string {
  return subtitles
    .sort((a, b) => a.startTime - b.startTime)
    .map((sub) => {
      const time = includeTimestamps ? `[${formatDurationDisplay(sub.startTime)} - ${formatDurationDisplay(sub.endTime)}] ` : "";
      const speaker = includeSpeakers && sub.speaker ? `${sub.speaker}: ` : "";
      return `${time}${speaker}${sub.text.trim()}`;
    })
    .join("\n\n");
}

/**
 * Exports to JSON (.json)
 */
export function exportToJSON(subtitles: SubtitleItem[], style?: SubtitleStyle): string {
  return safeJsonStringify({ subtitles, style }, 2);
}

/**
 * Exports to CSV (.csv)
 */
export function exportToCSV(subtitles: SubtitleItem[]): string {
  const headers = ["Index", "StartTime_Sec", "EndTime_Sec", "StartTime_Formatted", "EndTime_Formatted", "Speaker", "Text"];
  const rows = subtitles.map((sub, idx) => [
    idx + 1,
    sub.startTime.toFixed(3),
    sub.endTime.toFixed(3),
    `"${formatSRTTime(sub.startTime)}"`,
    `"${formatSRTTime(sub.endTime)}"`,
    `"${(sub.speaker || "").replace(/"/g, '""')}"`,
    `"${sub.text.replace(/"/g, '""')}"`,
  ]);

  return [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
}

/**
 * Exports to Advanced SubStation Alpha (.ass) with custom styles
 */
export function exportToASS(subtitles: SubtitleItem[], style: SubtitleStyle): string {
  const header = `[Script Info]
Title: CaptionAI Studio Subtitles
ScriptType: v4.00+
WrapStyle: 0
ScaledBorderAndShadow: yes
PlayResX: 1920
PlayResY: 1080

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,${Math.round(style.fontSize * 1.8)},&H00FFFFFF,&H0000FFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,${style.strokeWidth * 2},${style.shadowBlur},2,20,20,40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const events = subtitles
    .sort((a, b) => a.startTime - b.startTime)
    .map((sub) => {
      const start = formatASSTime(sub.startTime);
      const end = formatASSTime(sub.endTime);
      const speaker = sub.speaker || "";
      const text = sub.text.replace(/\n/g, "\\N");
      return `Dialogue: 0,${start},${end},Default,${speaker},0,0,0,,${text}`;
    })
    .join("\n");

  return header + events;
}

/**
 * Parses user uploaded .SRT or .VTT files
 */
export function parseSubtitleFile(content: string): SubtitleItem[] {
  const lines = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  const items: SubtitleItem[] = [];

  let currentItem: Partial<SubtitleItem> = {};
  let textBuffer: string[] = [];

  const timeRegex = /((\d{1,2}:)?\d{1,2}:\d{2}[,.]\d{2,3})\s*-->\s*((\d{1,2}:)?\d{1,2}:\d{2}[,.]\d{2,3})/;

  function parseTimeToSeconds(timeStr: string): number {
    const parts = timeStr.trim().replace(",", ".").split(":");
    if (parts.length === 3) {
      return parseFloat(parts[0]) * 3600 + parseFloat(parts[1]) * 60 + parseFloat(parts[2]);
    } else if (parts.length === 2) {
      return parseFloat(parts[0]) * 60 + parseFloat(parts[1]);
    }
    return 0;
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) {
      if (currentItem.startTime !== undefined && textBuffer.length > 0) {
        const text = textBuffer.join(" ").trim();
        const startTime = currentItem.startTime;
        const endTime = currentItem.endTime || startTime + 2;
        const words = text.split(/\s+/).map((w, wI, arr) => {
          const dur = (endTime - startTime) / Math.max(1, arr.length);
          return { word: w, startTime: startTime + wI * dur, endTime: startTime + (wI + 1) * dur };
        });

        items.push({
          id: `cue-imported-${Date.now()}-${items.length}`,
          startTime,
          endTime,
          text,
          speaker: currentItem.speaker || "Speaker 1",
          words,
        });
        currentItem = {};
        textBuffer = [];
      }
      continue;
    }

    const match = line.match(timeRegex);
    if (match) {
      currentItem.startTime = parseTimeToSeconds(match[1]);
      currentItem.endTime = parseTimeToSeconds(match[3]);
    } else if (currentItem.startTime !== undefined) {
      // Check for speaker pattern like "<v Host>Hello" or "Host: Hello"
      let cleanLine = line.replace(/<\/?[^>]+(>|$)/g, ""); // remove html tags
      if (cleanLine.includes(":") && !currentItem.speaker) {
        const parts = cleanLine.split(":");
        if (parts[0].length < 25) {
          currentItem.speaker = parts[0].trim();
          cleanLine = parts.slice(1).join(":").trim();
        }
      }
      textBuffer.push(cleanLine);
    }
  }

  // Final flush
  if (currentItem.startTime !== undefined && textBuffer.length > 0) {
    const text = textBuffer.join(" ").trim();
    const startTime = currentItem.startTime;
    const endTime = currentItem.endTime || startTime + 2;
    const words = text.split(/\s+/).map((w, wI, arr) => {
      const dur = (endTime - startTime) / Math.max(1, arr.length);
      return { word: w, startTime: startTime + wI * dur, endTime: startTime + (wI + 1) * dur };
    });

    items.push({
      id: `cue-imported-${Date.now()}-${items.length}`,
      startTime,
      endTime,
      text,
      speaker: currentItem.speaker || "Speaker 1",
      words,
    });
  }

  return items;
}
