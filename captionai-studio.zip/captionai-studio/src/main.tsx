import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { cleanSerializableObject } from './utils/safeJson';

// Global shield: sanitize console outputs so iframe logger JSON serialization never throws circular errors
const originalWarn = console.warn;
const originalError = console.error;
const originalLog = console.log;

const safeArg = (arg: any) => {
  if (arg === null || arg === undefined) return arg;
  if (typeof arg === "string" || typeof arg === "number" || typeof arg === "boolean") return arg;
  if (arg instanceof Error) return arg.message || String(arg);
  if (typeof Node !== "undefined" && arg instanceof Node) return `[${arg.nodeName || 'DOMNode'}]`;
  return cleanSerializableObject(arg);
};

console.warn = (...args: any[]) => {
  originalWarn.apply(console, args.map(safeArg));
};
console.error = (...args: any[]) => {
  originalError.apply(console, args.map(safeArg));
};
console.log = (...args: any[]) => {
  originalLog.apply(console, args.map(safeArg));
};

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
