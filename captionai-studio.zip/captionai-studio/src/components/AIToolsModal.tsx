import React, { useState } from "react";
import {
  Sparkles,
  X,
  Languages,
  Zap,
  CheckCheck,
  Smile,
  Hash,
  Loader2,
  FileText,
  Volume2,
} from "lucide-react";
import { SubtitleItem } from "../types";
import { SUPPORTED_LANGUAGES } from "../data/languages";

interface AIToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerateCaptions: (params: {
    language: string;
    contextPrompt: string;
    onProgress?: (status: { message: string; percent: number }) => void;
  }) => Promise<void>;
  onTranslateCaptions: (targetLang: string, makeBilingual: boolean) => Promise<void>;
  onEnhanceCaptions: (action: "punchy" | "grammar" | "tone", tone?: string) => Promise<void>;
  currentSubtitles: SubtitleItem[];
  currentLanguage: string;
  videoDuration?: number;
}

export const AIToolsModal: React.FC<AIToolsModalProps> = ({
  isOpen,
  onClose,
  onGenerateCaptions,
  onTranslateCaptions,
  onEnhanceCaptions,
  currentSubtitles,
  currentLanguage,
  videoDuration = 0,
}) => {
  const [activeTab, setActiveTab] = useState<"transcribe" | "translate" | "pacing" | "grammar" | "social">("transcribe");
  const [transcribeLang, setTranscribeLang] = useState("auto");
  const [contextPrompt, setContextPrompt] = useState("");
  const [targetLang, setTargetLang] = useState("es");
  const [makeBilingual, setMakeBilingual] = useState(false);
  const [toneSelection, setToneSelection] = useState("viral");
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [progressPercent, setProgressPercent] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [socialResult, setSocialResult] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleTranscribe = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setStatusMessage("Extracting full audio & preparing multi-segment analysis...");
    setProgressPercent(10);
    try {
      await onGenerateCaptions({
        language: transcribeLang === "auto" ? "auto (auto-detect: Hindi, Hinglish, English, etc.)" : transcribeLang,
        contextPrompt,
        onProgress: (status) => {
          setStatusMessage(status.message);
          setProgressPercent(status.percent);
        },
      });
      onClose();
    } catch (err: any) {
      setErrorMessage(
        err.message?.includes("503") || err.message?.includes("high demand")
          ? "Gemini AI is currently processing high traffic. We automatically retried with fallback models. Please click 'Try Again' in a moment."
          : err.message || "Failed to generate captions. Please try again."
      );
    } finally {
      setIsLoading(false);
      setProgressPercent(null);
    }
  };

  const handleTranslate = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setStatusMessage(`Translating timed subtitles to ${targetLang}...`);
    try {
      await onTranslateCaptions(targetLang, makeBilingual);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to translate subtitles. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleEnhance = async (action: "punchy" | "grammar" | "tone") => {
    setIsLoading(true);
    setErrorMessage(null);
    setStatusMessage(
      action === "punchy"
        ? "AI Smart Pacing: splitting sentences into punchy viral shorts cues..."
        : action === "grammar"
        ? "Fixing grammar, spelling & punctuation..."
        : "Adjusting tone & style..."
    );
    try {
      await onEnhanceCaptions(action, toneSelection);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to enhance subtitles. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const generateSocialHook = () => {
    const allText = currentSubtitles.map((s) => s.text).join(" ");
    const hook = `🔥 "${currentSubtitles[0]?.text || "Watch until the end!"}"\n\n${allText.slice(0, 180)}...\n\n👉 Share with someone who needs this! \n#ContentCreator #ViralVideo #CaptionAI #VideoEditor #Shorts`;
    setSocialResult(hook);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center border border-amber-400/30">
              <Sparkles className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-zinc-100">AI Video Studio Tools</h2>
              <p className="text-[11px] text-zinc-400">Powered by Gemini 3.7 Flash Multimodal Engine</p>
            </div>
          </div>

          <button
            onClick={onClose}
            disabled={isLoading}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center border-b border-zinc-800 bg-zinc-950/60 text-xs px-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab("transcribe")}
            className={`py-2.5 px-3 font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === "transcribe" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Auto Subtitles</span>
          </button>

          <button
            onClick={() => setActiveTab("translate")}
            className={`py-2.5 px-3 font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === "translate" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Languages className="w-3.5 h-3.5" />
            <span>Translate (50+)</span>
          </button>

          <button
            onClick={() => setActiveTab("pacing")}
            className={`py-2.5 px-3 font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === "pacing" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Smart Pacing</span>
          </button>

          <button
            onClick={() => setActiveTab("grammar")}
            className={`py-2.5 px-3 font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === "grammar" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>Fix Grammar</span>
          </button>

          <button
            onClick={() => setActiveTab("social")}
            className={`py-2.5 px-3 font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-colors ${
              activeTab === "social" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Hash className="w-3.5 h-3.5" />
            <span>Social Captions</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
          {errorMessage && (
            <div className="p-3 bg-red-950/60 border border-red-800/80 rounded-xl text-red-200 flex items-start justify-between gap-3 animate-in fade-in">
              <div className="space-y-1">
                <p className="font-semibold text-red-300">Request Notice</p>
                <p className="text-[11px] text-red-200/90 leading-relaxed">{errorMessage}</p>
              </div>
              <button
                onClick={() => setErrorMessage(null)}
                className="text-red-400 hover:text-red-200 text-xs px-2 py-1 bg-red-900/40 rounded-lg hover:bg-red-900/60"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* 1. Transcribe Tab */}
          {activeTab === "transcribe" && (
            <div className="space-y-4">
              <div className="p-3 bg-amber-400/10 border border-amber-400/20 rounded-xl text-amber-300 flex items-start gap-2">
                <Sparkles className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-[11px] font-semibold">Gemini Full-Duration Speech-to-Subtitles Engine</p>
                  <p className="text-[10.5px] text-amber-300/80 leading-relaxed">
                    Supports both short clips and long videos (e.g. 5m, 15m, 30m+). Generates precise timestamps, speaker tags, and word-by-word karaoke breakdown with zero cutoffs.
                  </p>
                </div>
              </div>

              {videoDuration > 60 && (
                <div className="p-2.5 bg-blue-950/40 border border-blue-800/60 rounded-xl text-blue-200 flex items-center justify-between text-[11px]">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                    <span>Long Video Detected ({Math.floor(videoDuration / 60)}m {Math.floor(videoDuration % 60)}s)</span>
                  </div>
                  <span className="font-semibold text-blue-300">Continuous Full Coverage</span>
                </div>
              )}

              <div>
                <label className="text-zinc-300 font-medium block mb-1.5">Spoken Video Language</label>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {[
                    { label: "🌐 Auto Detect", value: "auto" },
                    { label: "🇮🇳 Hindi (हिंदी)", value: "Hindi" },
                    { label: "🇮🇳 Hinglish", value: "Hinglish" },
                    { label: "🇬🇧 English", value: "English" },
                    { label: "🇵🇰 Urdu (اردو)", value: "Urdu" },
                    { label: "🇪🇸 Spanish", value: "Spanish" },
                    { label: "🇸🇦 Arabic", value: "Arabic" },
                  ].map((p) => (
                    <button
                      key={p.value}
                      type="button"
                      onClick={() => setTranscribeLang(p.value)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition-all ${
                        transcribeLang === p.value
                          ? "bg-amber-400/20 text-amber-300 border-amber-400/40 font-semibold"
                          : "bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                <select
                  value={transcribeLang}
                  onChange={(e) => setTranscribeLang(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2.5 text-zinc-200 focus:outline-none focus:border-amber-400 text-xs"
                >
                  <option value="auto">🌐 Auto-Detect Spoken Language</option>
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.name}>
                      {l.flag} {l.name} ({l.nativeName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-zinc-300 font-medium block mb-1.5">Context or Topic Note (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. reel about tech, tutorial, podcast conversation, motivation..."
                  value={contextPrompt}
                  onChange={(e) => setContextPrompt(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2.5 text-zinc-200 focus:outline-none focus:border-amber-400 text-xs"
                />
              </div>

              {isLoading && progressPercent !== null && (
                <div className="space-y-1.5 p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
                  <div className="flex justify-between items-center text-[11px] text-zinc-300">
                    <span className="font-medium text-amber-300 truncate pr-2">{statusMessage}</span>
                    <span className="font-mono text-zinc-400 shrink-0">{progressPercent}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-300 rounded-full"
                      style={{ width: `${Math.min(100, Math.max(5, progressPercent))}%` }}
                    />
                  </div>
                </div>
              )}

              <button
                onClick={handleTranscribe}
                disabled={isLoading}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing Full Video Audio...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 fill-current" />
                    <span>Transcribe Audio to Subtitles</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* 2. Translate Tab */}
          {activeTab === "translate" && (
            <div className="space-y-4">
              <p className="text-zinc-300">
                Translate all existing subtitles to another language while preserving exact time codes and word alignment.
              </p>

              <div>
                <label className="text-zinc-300 font-medium block mb-1.5">Target Language</label>
                <select
                  value={targetLang}
                  onChange={(e) => setTargetLang(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2.5 text-zinc-200 focus:outline-none focus:border-amber-400"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.name}>
                      {l.flag} {l.name} ({l.nativeName})
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-between p-3 bg-zinc-950 rounded-xl border border-zinc-800">
                <div>
                  <span className="font-semibold text-zinc-200 block">Bilingual Subtitles Mode</span>
                  <span className="text-[11px] text-zinc-400">Keep original language on top and translated underneath</span>
                </div>
                <input
                  type="checkbox"
                  checked={makeBilingual}
                  onChange={(e) => setMakeBilingual(e.target.checked)}
                  className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
                />
              </div>

              <button
                onClick={handleTranslate}
                disabled={isLoading || currentSubtitles.length === 0}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{statusMessage || "Translating..."}</span>
                  </>
                ) : (
                  <>
                    <Languages className="w-4 h-4" />
                    <span>Translate All Captions Now</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* 3. Smart Pacing Tab */}
          {activeTab === "pacing" && (
            <div className="space-y-4">
              <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
                <span className="font-bold text-amber-400 block mb-1">⚡ Viral Shorts Pacing Optimizer</span>
                <p className="text-[11px] text-zinc-400">
                  Splits long sentence blocks into fast, punchy 1-4 word subtitle segments designed for maximum viewer retention on TikTok, Instagram Reels, and YouTube Shorts.
                </p>
              </div>

              <button
                onClick={() => handleEnhance("punchy")}
                disabled={isLoading || currentSubtitles.length === 0}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{statusMessage}</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 fill-current" />
                    <span>Apply Punchy Viral Pacing</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* 4. Fix Grammar & Tone */}
          {activeTab === "grammar" && (
            <div className="space-y-4">
              <p className="text-zinc-300">
                Fix any transcription errors, spelling, punctuation, capitalization, and adjust wording style.
              </p>

              <div>
                <label className="text-zinc-300 font-medium block mb-1.5">Style & Tone Adjustment</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "viral", label: "🔥 Viral & Engaging" },
                    { id: "formal", label: "💼 Professional & Formal" },
                    { id: "casual", label: "💬 Casual & Conversational" },
                    { id: "concise", label: "✂️ Concise & Direct" },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setToneSelection(t.id)}
                      className={`p-2.5 rounded-lg border text-left font-medium transition-all ${
                        toneSelection === t.id
                          ? "bg-amber-400/20 text-amber-300 border-amber-400/60"
                          : "bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200"
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => handleEnhance("grammar")}
                  disabled={isLoading || currentSubtitles.length === 0}
                  className="flex-1 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-100 font-bold border border-zinc-700 flex items-center justify-center gap-2"
                >
                  <CheckCheck className="w-4 h-4 text-emerald-400" />
                  <span>Fix Grammar Only</span>
                </button>

                <button
                  onClick={() => handleEnhance("tone")}
                  disabled={isLoading || currentSubtitles.length === 0}
                  className="flex-1 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold flex items-center justify-center gap-2"
                >
                  <Smile className="w-4 h-4" />
                  <span>Apply Tone Polish</span>
                </button>
              </div>
            </div>
          )}

          {/* 5. Social Captions */}
          {activeTab === "social" && (
            <div className="space-y-4">
              <p className="text-zinc-300">
                Generate high-converting descriptions, hooks, and trending hashtags for YouTube Shorts, TikTok, and Instagram.
              </p>

              <button
                onClick={generateSocialHook}
                className="w-full py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-100 font-bold border border-zinc-700 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Generate Video Post Hook & Hashtags</span>
              </button>

              {socialResult && (
                <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800 space-y-2">
                  <div className="flex justify-between items-center text-zinc-400 text-[10px]">
                    <span>Social Media Caption Copy</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(socialResult);
                        alert("Copied to clipboard!");
                      }}
                      className="text-amber-400 hover:underline"
                    >
                      Copy All
                    </button>
                  </div>
                  <pre className="text-zinc-200 text-xs font-sans whitespace-pre-wrap leading-relaxed">
                    {socialResult}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
