import React, { useState, useRef } from "react";
import {
  Upload,
  Film,
  Video,
  FileCode,
  Sparkles,
  Camera,
  StopCircle,
  X,
  Play,
  Check,
} from "lucide-react";
import { SampleVideo } from "../types";
import { SAMPLE_VIDEOS } from "../data/sampleVideos";
import { parseSubtitleFile } from "../utils/captionConverters";

interface UploadOrSampleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSample: (sample: SampleVideo) => void;
  onUploadMediaFile: (file: File, subtitleFile?: File, autoTranscribe?: boolean) => void;
  onRecordCaptured: (blob: Blob, autoTranscribe?: boolean) => void;
}

export const UploadOrSampleModal: React.FC<UploadOrSampleModalProps> = ({
  isOpen,
  onClose,
  onSelectSample,
  onUploadMediaFile,
  onRecordCaptured,
}) => {
  const [activeTab, setActiveTab] = useState<"samples" | "upload" | "record">("upload");
  const [autoTranscribe, setAutoTranscribe] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const webcamVideoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  if (!isOpen) return null;

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files) as File[];
    const mediaFile = files.find((f: File) => f.type.startsWith("video/") || f.type.startsWith("audio/"));
    const subFile = files.find((f: File) => f.name.endsWith(".srt") || f.name.endsWith(".vtt"));

    if (mediaFile) {
      onUploadMediaFile(mediaFile, subFile, autoTranscribe);
      onClose();
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadMediaFile(file, undefined, autoTranscribe);
      onClose();
    }
  };

  const startWebcamRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      streamRef.current = stream;
      if (webcamVideoRef.current) {
        webcamVideoRef.current.srcObject = stream;
        webcamVideoRef.current.play();
      }

      const recorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      recorder.onstop = () => {
        const fullBlob = new Blob(chunks, { type: "video/webm" });
        onRecordCaptured(fullBlob, autoTranscribe);
        stream.getTracks().forEach((track) => track.stop());
        onClose();
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
    } catch (err: any) {
      alert("Camera / Microphone permission denied or unavailable: " + err.message);
    }
  };

  const stopWebcamRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in select-none">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center border border-amber-400/30">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-sm text-zinc-100">Select or Upload Video</h2>
              <p className="text-[11px] text-zinc-400">Choose from ready sample clips, upload your own video/audio, or record live</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-zinc-800 bg-zinc-950/60 text-xs px-2">
          <button
            onClick={() => setActiveTab("samples")}
            className={`py-2.5 px-4 font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === "samples" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Sample Demo Videos</span>
          </button>

          <button
            onClick={() => setActiveTab("upload")}
            className={`py-2.5 px-4 font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === "upload" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload File (MP4, MOV, MP3...)</span>
          </button>

          <button
            onClick={() => setActiveTab("record")}
            className={`py-2.5 px-4 font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
              activeTab === "record" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Record Live Video</span>
          </button>
        </div>

        {/* Body */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4 text-xs">
          {/* 1. Curated Sample Videos */}
          {activeTab === "samples" && (
            <div className="space-y-3">
              <p className="text-zinc-400 text-[11px]">Instant test videos with pre-aligned captions and speech tracks:</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {SAMPLE_VIDEOS.map((sample) => (
                  <div
                    key={sample.id}
                    onClick={() => {
                      onSelectSample(sample);
                      onClose();
                    }}
                    className="group bg-zinc-950 rounded-xl border border-zinc-800 hover:border-amber-400/80 overflow-hidden cursor-pointer transition-all hover:scale-[1.02] shadow-sm flex flex-col"
                  >
                    <div className="h-28 relative overflow-hidden bg-zinc-900">
                      <img
                        src={sample.thumbnail}
                        alt={sample.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-9 h-9 rounded-full bg-amber-400 text-zinc-950 flex items-center justify-center shadow-lg">
                          <Play className="w-4 h-4 fill-current ml-0.5" />
                        </div>
                      </div>
                      <span className="absolute bottom-1.5 right-1.5 bg-black/80 text-white font-mono text-[9px] px-1.5 py-0.5 rounded">
                        {sample.duration}s
                      </span>
                    </div>

                    <div className="p-2.5 flex-1 flex flex-col justify-between">
                      <div>
                        <span className="text-[9px] uppercase tracking-wider text-amber-400 font-semibold block mb-0.5">
                          {sample.category}
                        </span>
                        <h4 className="font-bold text-xs text-zinc-100 group-hover:text-amber-300 transition-colors line-clamp-1">
                          {sample.title}
                        </h4>
                      </div>
                      <p className="text-[10px] text-zinc-500 line-clamp-2 mt-1">
                        {sample.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 2. Drag & Drop Upload File */}
          {activeTab === "upload" && (
            <div className="space-y-4">
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center transition-colors ${
                  isDragging ? "border-amber-400 bg-amber-400/10" : "border-zinc-700 bg-zinc-950/60 hover:border-zinc-600"
                }`}
              >
                <div className="w-14 h-14 rounded-2xl bg-zinc-800 flex items-center justify-center text-amber-400 mb-3 shadow-md">
                  <Upload className="w-7 h-7" />
                </div>
                <h3 className="font-bold text-sm text-zinc-200">Drag and drop your media file here</h3>
                <p className="text-xs text-zinc-400 mt-1 max-w-sm">
                  Supports MP4, WebM, MOV, MKV, MP3, WAV, M4A, plus optional .SRT / .VTT subtitles file.
                </p>

                <label className="mt-4 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs cursor-pointer shadow-md transition-all">
                  <span>Browse Files</span>
                  <input
                    type="file"
                    accept="video/*,audio/*,.srt,.vtt"
                    onChange={handleFileInput}
                    className="hidden"
                  />
                </label>

                {/* Auto-transcribe checkbox */}
                <label className="mt-4 flex items-center gap-2 cursor-pointer text-zinc-300 hover:text-white bg-zinc-900/90 px-3.5 py-2 rounded-xl border border-zinc-800 transition-colors">
                  <input
                    type="checkbox"
                    checked={autoTranscribe}
                    onChange={(e) => setAutoTranscribe(e.target.checked)}
                    className="w-4 h-4 rounded border-zinc-700 bg-zinc-950 text-amber-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
                  />
                  <span className="text-xs font-semibold text-amber-300">⚡ Auto-Generate Subtitles with Gemini AI on Upload</span>
                </label>
              </div>
            </div>
          )}

          {/* 3. Live Webcam Recording */}
          {activeTab === "record" && (
            <div className="space-y-4 text-center">
              <div className="aspect-video max-w-md mx-auto bg-black rounded-2xl overflow-hidden border border-zinc-800 relative flex items-center justify-center">
                {isRecording ? (
                  <video
                    ref={webcamVideoRef}
                    autoPlay
                    muted
                    playsInline
                    onError={(e) => e.preventDefault()}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950/80 text-zinc-400 p-4">
                    <Camera className="w-8 h-8 text-amber-400 mb-2" />
                    <p className="font-semibold text-zinc-200">Record direct camera & microphone clip</p>
                    <p className="text-xs text-zinc-500 mt-1">Click start to enable your camera and microphone</p>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-center gap-3">
                {!isRecording ? (
                  <button
                    onClick={startWebcamRecording}
                    className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/30"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Start Recording</span>
                  </button>
                ) : (
                  <button
                    onClick={stopWebcamRecording}
                    className="px-5 py-2.5 rounded-xl bg-zinc-100 hover:bg-white text-zinc-950 font-bold text-xs flex items-center gap-2 animate-pulse shadow-lg"
                  >
                    <StopCircle className="w-4 h-4 text-rose-600" />
                    <span>Stop Recording & Use Video</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
