/**
 * Procedural Video Generator
 * Generates reliable animated WebM video blobs in browser using HTML5 Canvas & Web Audio.
 * Ensures zero network dependency, no 403/CORS issues, and 100% uptime in sandbox environments.
 */

const videoCache: Record<string, string> = {};

export async function generateSyntheticVideoBlob(
  type: "tech" | "nature" | "fitness" = "tech",
  durationSec: number = 16
): Promise<string> {
  const cacheKey = `${type}_${durationSec}`;
  if (videoCache[cacheKey]) {
    return videoCache[cacheKey];
  }

  return new Promise((resolve) => {
    try {
      const width = 854;
      const height = 480;
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");

      if (!ctx || typeof window === "undefined" || !("MediaRecorder" in window)) {
        // Fallback placeholder empty video
        resolve("");
        return;
      }

      // Web Audio stream
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      let audioCtx: AudioContext | null = null;
      let dest: MediaStreamAudioDestinationNode | null = null;
      let osc: OscillatorNode | null = null;
      let gain: GainNode | null = null;

      try {
        audioCtx = new AudioCtxClass();
        dest = audioCtx.createMediaStreamDestination();
        osc = audioCtx.createOscillator();
        gain = audioCtx.createGain();
        gain.gain.value = 0.05;
        osc.connect(gain);
        gain.connect(dest);
        osc.start();
      } catch (err) {
        console.warn("AudioContext setup optional for synthetic video:", err);
      }

      const canvasStream = canvas.captureStream(30);
      const combinedStream = new MediaStream([
        ...canvasStream.getVideoTracks(),
        ...(dest ? dest.stream.getAudioTracks() : []),
      ]);

      let mimeType = "video/webm;codecs=vp9,opus";
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = "video/webm";
      }
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = "";
      }

      const mediaRecorder = new MediaRecorder(combinedStream, mimeType ? { mimeType } : undefined);
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        try {
          if (osc) osc.stop();
          if (audioCtx && audioCtx.state !== "closed") audioCtx.close();
        } catch {}
        const blob = new Blob(chunks, { type: mimeType || "video/webm" });
        const url = URL.createObjectURL(blob);
        videoCache[cacheKey] = url;
        resolve(url);
      };

      mediaRecorder.start(100);

      const startTime = performance.now();
      const totalMs = durationSec * 1000;

      function renderFrame() {
        if (!ctx) return;
        const now = performance.now();
        const elapsed = (now - startTime) / 1000;
        const progress = Math.min(1, elapsed / durationSec);

        // Background
        if (type === "tech") {
          const grad = ctx.createLinearGradient(0, 0, width, height);
          grad.addColorStop(0, "#09090b");
          grad.addColorStop(0.5, "#18181b");
          grad.addColorStop(1, "#020617");
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, width, height);

          // Grid pattern
          ctx.strokeStyle = "rgba(245, 158, 11, 0.08)";
          ctx.lineWidth = 1;
          const gridSize = 40;
          for (let x = 0; x < width; x += gridSize) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, height);
            ctx.stroke();
          }
          for (let y = 0; y < height; y += gridSize) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(width, y);
            ctx.stroke();
          }

          // Central glowing circle / pulse
          const pulse = Math.sin(elapsed * 4) * 15 + 60;
          ctx.fillStyle = "rgba(245, 158, 11, 0.15)";
          ctx.beginPath();
          ctx.arc(width / 2, height / 2 - 20, pulse + 20, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = "rgba(245, 158, 11, 0.8)";
          ctx.beginPath();
          ctx.arc(width / 2, height / 2 - 20, pulse, 0, Math.PI * 2);
          ctx.fill();

          // Title & Equalizer
          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 28px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("AI STARTUP PRODUCT DEMO", width / 2, height / 2 + 70);

          ctx.fillStyle = "#f59e0b";
          ctx.font = "16px sans-serif";
          ctx.fillText(`TRANSCRIPTION PREVIEW • ${elapsed.toFixed(1)}s / ${durationSec}s`, width / 2, height / 2 + 100);

          // Audio visualizer bars
          const numBars = 24;
          const barWidth = 8;
          const barGap = 6;
          const startX = width / 2 - ((numBars * (barWidth + barGap)) / 2);
          for (let i = 0; i < numBars; i++) {
            const h = Math.abs(Math.sin(elapsed * 5 + i * 0.4)) * 35 + 8;
            ctx.fillStyle = i % 2 === 0 ? "#f59e0b" : "#fbbf24";
            ctx.fillRect(startX + i * (barWidth + barGap), height - 80 - h, barWidth, h);
          }
        } else if (type === "nature") {
          const grad = ctx.createLinearGradient(0, 0, 0, height);
          grad.addColorStop(0, "#082f49");
          grad.addColorStop(0.5, "#0369a1");
          grad.addColorStop(1, "#0c4a6e");
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, width, height);

          // Floating bubbles
          for (let i = 0; i < 15; i++) {
            const bx = (Math.sin(elapsed + i * 2) * 0.5 + 0.5) * width;
            const by = (height - ((elapsed * 40 + i * 45) % (height + 40)));
            const br = (i % 3) * 6 + 8;
            ctx.fillStyle = "rgba(255, 255, 255, 0.25)";
            ctx.beginPath();
            ctx.arc(bx, by, br, 0, Math.PI * 2);
            ctx.fill();
          }

          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 28px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("OCEAN EXPLORATION DOCUMENTARY", width / 2, height / 2 - 10);

          ctx.fillStyle = "#38bdf8";
          ctx.font = "16px sans-serif";
          ctx.fillText(`CINEMATIC 4K SANCTUARY • ${elapsed.toFixed(1)}s / ${durationSec}s`, width / 2, height / 2 + 25);
        } else {
          // Fitness
          const grad = ctx.createLinearGradient(0, 0, width, height);
          grad.addColorStop(0, "#450a0a");
          grad.addColorStop(0.5, "#881337");
          grad.addColorStop(1, "#1c1917");
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, width, height);

          // Dynamic radial pulse
          const pulse = Math.abs(Math.sin(elapsed * 6)) * 40 + 50;
          ctx.strokeStyle = "rgba(244, 63, 94, 0.6)";
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.arc(width / 2, height / 2 - 30, pulse, 0, Math.PI * 2);
          ctx.stroke();

          ctx.fillStyle = "#ffffff";
          ctx.font = "bold 32px sans-serif";
          ctx.textAlign = "center";
          ctx.fillText("HIGH ENERGY WORKOUT MOTIVATION", width / 2, height / 2 + 50);

          ctx.fillStyle = "#f43f5e";
          ctx.font = "18px sans-serif";
          ctx.fillText(`BEAST MODE ON • ${elapsed.toFixed(1)}s / ${durationSec}s`, width / 2, height / 2 + 85);
        }

        // Progress bar at bottom
        ctx.fillStyle = "rgba(255, 255, 255, 0.2)";
        ctx.fillRect(40, height - 30, width - 80, 6);
        ctx.fillStyle = "#f59e0b";
        ctx.fillRect(40, height - 30, (width - 80) * progress, 6);

        if (elapsed < durationSec) {
          requestAnimationFrame(renderFrame);
        } else {
          if (mediaRecorder.state === "recording") {
            mediaRecorder.stop();
          }
        }
      }

      requestAnimationFrame(renderFrame);
    } catch (err) {
      console.warn("Failed generating synthetic video:", err);
      resolve("");
    }
  });
}
