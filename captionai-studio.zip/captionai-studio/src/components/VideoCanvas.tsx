import React, { useRef, useState, useEffect } from "react";
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  RotateCcw,
  Sparkles,
  Layers,
  Upload,
  Film,
  Camera,
  RefreshCw,
  Download,
} from "lucide-react";
import { SubtitleItem, SubtitleStyle } from "../types";
import { generateSyntheticVideoBlob } from "../utils/sampleVideoGenerator";

interface VideoCanvasProps {
  videoUrl: string;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  onPlayPause: () => void;
  onSeek: (time: number) => void;
  onTimeUpdate?: (time: number) => void;
  onDurationChange?: (dur: number) => void;
  subtitles: SubtitleItem[];
  style: SubtitleStyle;
  onUpdateStyle: (newStyle: Partial<SubtitleStyle>) => void;
  aspectRatio: "16:9" | "9:16" | "1:1" | "4:5";
  onChangeAspectRatio?: (aspectRatio: "16:9" | "9:16" | "1:1" | "4:5") => void;
  bilingualMode: boolean;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  onSelectVideoUpload?: () => void;
  onRecordVideo?: () => void;
  onOpenUploadModal?: () => void;
  onOpenExport?: () => void;
  onOpenAITools?: () => void;
  playbackRate?: number;
  onChangePlaybackRate?: (rate: number) => void;
  volume?: number;
  onChangeVolume?: (vol: number) => void;
  isMuted?: boolean;
  onToggleMute?: () => void;
}

export const VideoCanvas: React.FC<VideoCanvasProps> = ({
  videoUrl,
  currentTime,
  duration,
  isPlaying,
  onPlayPause,
  onSeek,
  onTimeUpdate,
  onDurationChange,
  subtitles,
  style,
  onUpdateStyle,
  aspectRatio,
  onChangeAspectRatio,
  bilingualMode,
  videoRef,
  onSelectVideoUpload,
  onRecordVideo,
  onOpenUploadModal,
  onOpenExport,
  onOpenAITools,
  playbackRate = 1,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [activeVideoSrc, setActiveVideoSrc] = useState(videoUrl);
  const [useCanvasFallback, setUseCanvasFallback] = useState(false);

  const [showMobileControls, setShowMobileControls] = useState(true);
  const controlsTimeoutRef = useRef<any>(null);
  const [containerWidth, setContainerWidth] = useState(640);

  // Measure container width for responsive subtitle scaling
  useEffect(() => {
    if (!containerRef.current) return;
    const updateSize = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.clientWidth || 640);
      }
    };
    updateSize();
    const ro = new ResizeObserver(updateSize);
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  const responsiveScale = Math.min(1.2, Math.max(0.65, containerWidth / 640));

  // Sync active video src when external videoUrl changes
  useEffect(() => {
    setActiveVideoSrc(videoUrl);
    setUseCanvasFallback(false);
  }, [videoUrl]);

  // Touch and interaction handler for mobile & desktop to reveal controls and toggle playback smoothly
  const handleCanvasInteraction = (e: React.MouseEvent | React.TouchEvent) => {
    // If clicking on interactive buttons inside overlay, don't trigger play/pause
    const target = e.target as HTMLElement;
    if (target.closest("button") || target.closest("input")) {
      return;
    }

    onPlayPause();

    // Show controls temporarily on mobile tap
    setShowMobileControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowMobileControls(false);
      }
    }, 3500);
  };

  useEffect(() => {
    if (!isPlaying) {
      setShowMobileControls(true);
    }
  }, [isPlaying]);

  // Synchronize HTML5 video element with isPlaying state
  useEffect(() => {
    const video = videoRef.current;
    if (!video || useCanvasFallback) return;

    if (isPlaying) {
      if (video.paused) {
        const p = video.play();
        if (p !== undefined) {
          p.catch((err) => {
            if (err.name === "AbortError") return;
            console.warn("Video playback policy retry:", err?.message || String(err));
            // If mobile browser blocks unmuted audio on tap, mute and retry safely
            if (!video.muted) {
              video.muted = true;
              setIsMuted(true);
              video.play().catch(() => {});
            }
          });
        }
      }
    } else {
      if (!video.paused) {
        video.pause();
      }
    }
  }, [isPlaying, activeVideoSrc, useCanvasFallback]);

  // Handle Video element loading errors (e.g. 403 or network issue on remote samples only)
  const handleVideoError = () => {
    // Never fall back to procedural canvas for local user uploads / blobs
    if (activeVideoSrc && (activeVideoSrc.startsWith("blob:") || activeVideoSrc.startsWith("data:"))) {
      return;
    }
    console.warn("Remote sample media playback switching to animated preview canvas mode.");
    setUseCanvasFallback(true);
  };

  // Canvas-based real-time 60fps animated video renderer when media source is procedural/unavailable
  useEffect(() => {
    if (!useCanvasFallback || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const width = 854;
    const height = 480;
    canvas.width = width;
    canvas.height = height;

    const type = videoUrl.includes("nature") || videoUrl.includes("Ocean") || videoUrl.includes("Escapes")
      ? "nature"
      : videoUrl.includes("fit") || videoUrl.includes("Workout") || videoUrl.includes("Joy")
      ? "fitness"
      : "tech";

    // Background gradient
    if (type === "nature") {
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, "#082f49");
      grad.addColorStop(0.5, "#0369a1");
      grad.addColorStop(1, "#0c4a6e");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Underwater ambient bubbles
      for (let i = 0; i < 16; i++) {
        const bx = (Math.sin(currentTime * 0.8 + i * 2.3) * 0.45 + 0.5) * width;
        const by = height - ((currentTime * 45 + i * 55) % (height + 50));
        const br = (i % 4) * 4 + 6;
        ctx.fillStyle = "rgba(255, 255, 255, 0.22)";
        ctx.beginPath();
        ctx.arc(bx, by, br, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 24px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("CINEMATIC OCEAN EXPLORATION", width / 2, height / 2 - 30);
    } else if (type === "fitness") {
      const grad = ctx.createRadialGradient(width / 2, height / 2, 20, width / 2, height / 2, width / 1.5);
      grad.addColorStop(0, "#7c2d12");
      grad.addColorStop(0.6, "#451a03");
      grad.addColorStop(1, "#18181b");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Energy pulse
      const pulse = Math.abs(Math.sin(currentTime * 3.5)) * 25 + 40;
      ctx.strokeStyle = "rgba(249, 115, 22, 0.4)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(width / 2, height / 2 - 30, pulse + 30, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 24px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("HIGH ENERGY MOTIVATION", width / 2, height / 2 - 30);
    } else {
      // Tech Demo
      const grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, "#09090b");
      grad.addColorStop(0.5, "#18181b");
      grad.addColorStop(1, "#020617");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Grid
      ctx.strokeStyle = "rgba(245, 158, 11, 0.08)";
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Tech Glow
      const glow = Math.sin(currentTime * 3) * 15 + 45;
      ctx.fillStyle = "rgba(245, 158, 11, 0.2)";
      ctx.beginPath();
      ctx.arc(width / 2, height / 2 - 30, glow + 20, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 24px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("AI STARTUP PRODUCT DEMO", width / 2, height / 2 - 30);
    }

    // Audio Visualizer Equalizer Bars
    const numBars = 28;
    const barWidth = 7;
    const barGap = 6;
    const startX = width / 2 - ((numBars * (barWidth + barGap)) / 2);
    for (let i = 0; i < numBars; i++) {
      const h = Math.abs(Math.sin(currentTime * 5 + i * 0.45)) * 32 + 6;
      ctx.fillStyle = i % 2 === 0 ? "#f59e0b" : "#fbbf24";
      ctx.fillRect(startX + i * (barWidth + barGap), height - 70 - h, barWidth, h);
    }
  }, [useCanvasFallback, currentTime, videoUrl]);

  // Handle Playback Loop for Canvas Fallback mode
  useEffect(() => {
    if (!useCanvasFallback || !isPlaying) return;

    let animId: number;
    let lastTime = performance.now();

    const loop = (now: number) => {
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      const nextTime = currentTime + delta * (playbackRate || 1);
      const maxDur = duration || 18;

      if (nextTime >= maxDur) {
        onSeek(0);
      } else {
        onTimeUpdate?.(nextTime);
      }
      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [useCanvasFallback, isPlaying, currentTime, duration, playbackRate, onSeek, onTimeUpdate]);

  // Active subtitle
  const activeSub = subtitles.find(
    (s) => currentTime >= s.startTime && currentTime <= s.endTime
  );

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (videoRef.current) {
      videoRef.current.volume = newVol;
      videoRef.current.muted = newVol === 0;
    }
    setIsMuted(newVol === 0);
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleFullscreen = () => {
    if (containerRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        containerRef.current.requestFullscreen();
      }
    }
  };

  // Determine Aspect Ratio Container Classes
  const getAspectRatioClasses = () => {
    switch (aspectRatio) {
      case "9:16":
        return "aspect-[9/16] max-h-[46vh] sm:max-h-[560px] w-auto max-w-[90vw] sm:max-w-[340px]";
      case "1:1":
        return "aspect-square max-h-[40vh] sm:max-h-[500px] w-auto max-w-[90vw] sm:max-w-[500px]";
      case "4:5":
        return "aspect-[4/5] max-h-[44vh] sm:max-h-[540px] w-auto max-w-[90vw] sm:max-w-[430px]";
      case "16:9":
      default:
        return "aspect-video max-h-[40vh] sm:max-h-[540px] w-full max-w-[95vw] sm:max-w-[860px]";
    }
  };

  return (
    <div className="flex-1 bg-zinc-950 flex flex-col items-center justify-center p-2 sm:p-6 overflow-hidden relative select-none">
      {/* Aspect Ratio Bounding Canvas */}
      <div
        ref={containerRef}
        onClick={handleCanvasInteraction}
        onTouchEnd={handleCanvasInteraction}
        className={`relative bg-zinc-900 rounded-2xl overflow-hidden shadow-2xl border border-zinc-800 flex items-center justify-center ${getAspectRatioClasses()} transition-all duration-300 group cursor-pointer`}
      >
        {/* Dynamic Video / Canvas Display */}
        {useCanvasFallback ? (
          <div className="w-full h-full relative">
            <canvas
              ref={canvasRef}
              className="w-full h-full object-cover"
            />
          </div>
        ) : activeVideoSrc ? (
          <div className="w-full h-full relative bg-black flex items-center justify-center">
            <video
              ref={videoRef}
              src={activeVideoSrc}
              className="w-full h-full object-contain pointer-events-auto"
              onTimeUpdate={(e) => onTimeUpdate?.(e.currentTarget.currentTime)}
              onLoadedMetadata={(e) => {
                const v = e.currentTarget;
                if (v.duration && !isNaN(v.duration) && isFinite(v.duration)) {
                  onDurationChange?.(v.duration);
                }
                if (v.videoWidth && v.videoHeight && onChangeAspectRatio) {
                  const r = v.videoWidth / v.videoHeight;
                  if (r < 0.65) {
                    onChangeAspectRatio("9:16");
                  } else if (r >= 0.65 && r < 0.9) {
                    onChangeAspectRatio("4:5");
                  } else if (r >= 0.9 && r < 1.2) {
                    onChangeAspectRatio("1:1");
                  } else {
                    onChangeAspectRatio("16:9");
                  }
                }
              }}
              onEnded={() => onSeek(0)}
              onError={handleVideoError}
              playsInline
              webkit-playsinline="true"
              preload="auto"
            />
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center p-8 text-center text-zinc-400 gap-4 pointer-events-auto">
            <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex items-center justify-center text-zinc-300">
              <Film className="w-8 h-8 text-amber-400" />
            </div>
            <div>
              <p className="text-sm font-semibold text-zinc-200">No video selected</p>
              <p className="text-xs text-zinc-500 mt-1">Upload a video or choose a preset</p>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={onOpenUploadModal || onSelectVideoUpload}
                className="px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition-all flex items-center gap-1.5 shadow-md"
              >
                <Upload className="w-3.5 h-3.5" /> Upload Video
              </button>
            </div>
          </div>
        )}

        {/* Center Quick Play/Pause Badge (Visible when paused or briefly on tap) */}
        {!isPlaying && activeVideoSrc && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-zinc-950/70 border border-amber-400/50 backdrop-blur-md flex items-center justify-center text-amber-400 shadow-2xl animate-pulse">
              <Play className="w-7 h-7 fill-current ml-1" />
            </div>
          </div>
        )}

        {/* Subtitle Overlay Element */}
        {activeSub && (
          <div
            style={{
              position: "absolute",
              left: `${style.xPercent}%`,
              top: `${style.yPercent}%`,
              transform: "translate(-50%, -50%)",
              maxWidth: `${style.maxWidthPercent}%`,
              zIndex: 30,
              pointerEvents: "none",
            }}
            className="select-none"
          >
            {/* Subtitle Body Box */}
            <div
              style={{
                fontFamily: style.fontFamily,
                fontSize: `${Math.round(style.fontSize * responsiveScale)}px`,
                fontWeight: style.fontWeight,
                lineHeight: style.lineHeight,
                letterSpacing: `${style.letterSpacing * responsiveScale}px`,
                textAlign: style.textAlign,
                textTransform: style.textTransform,
                backgroundColor: style.bgBoxEnabled
                  ? hexToRgba(style.bgBoxColor, style.bgBoxOpacity)
                  : "transparent",
                padding: style.bgBoxEnabled
                  ? `${Math.round(style.bgBoxPaddingY * responsiveScale)}px ${Math.round(style.bgBoxPaddingX * responsiveScale)}px`
                  : "0px",
                borderRadius: style.bgBoxEnabled ? `${Math.round(style.bgBoxBorderRadius * responsiveScale)}px` : "0px",
                textShadow:
                  style.shadowBlur > 0
                    ? `${style.shadowOffsetX * responsiveScale}px ${style.shadowOffsetY * responsiveScale}px ${style.shadowBlur * responsiveScale}px ${style.shadowColor}`
                    : "none",
                WebkitTextStroke:
                  style.strokeWidth > 0
                    ? `${style.strokeWidth * responsiveScale}px ${style.strokeColor}`
                    : "none",
              }}
              className="flex flex-wrap items-center justify-center gap-x-1.5 gap-y-1"
            >
              {renderSubtitleWords(activeSub, currentTime, style)}

              {/* Secondary Bilingual subtitle if enabled */}
              {bilingualMode && activeSub.secondaryText && (
                <div
                  style={{
                    color: style.bilingualSecondaryColor || "#93C5FD",
                    fontSize: `${Math.round((style.bilingualSecondaryFontSize || Math.round(style.fontSize * 0.75)) * responsiveScale)}px`,
                    fontWeight: "600",
                    width: "100%",
                    marginTop: `${Math.round(4 * responsiveScale)}px`,
                    textTransform: "none",
                  }}
                  className="text-center opacity-90"
                >
                  {activeSub.secondaryText}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Video Overlay Controls Bar (Visible on mobile tap and desktop hover) */}
        <div
          className={`absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2.5 sm:p-3 flex items-center justify-between transition-opacity duration-200 z-40 ${
            showMobileControls ? "opacity-100 pointer-events-auto" : "opacity-0 sm:group-hover:opacity-100 pointer-events-none sm:group-hover:pointer-events-auto"
          }`}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={onPlayPause}
              className="w-8 h-8 rounded-lg bg-white/20 hover:bg-white/30 backdrop-blur-md text-white flex items-center justify-center transition-all active:scale-95"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>

            <button
              onClick={() => onSeek(0)}
              className="p-1.5 text-zinc-300 hover:text-white transition-colors"
              title="Restart from beginning"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5">
              <button onClick={toggleMute} className="text-zinc-300 hover:text-white">
                {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-16 h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            <span className="text-xs font-mono text-zinc-300">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {onOpenAITools && (
              <button
                onClick={onOpenAITools}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-semibold text-[11px] border border-amber-400/30 shadow transition-all active:scale-95"
                title="Auto Generate Subtitles from Audio (AI)"
              >
                <Sparkles className="w-3.5 h-3.5 fill-current" />
                <span className="hidden sm:inline">Auto Subtitles</span>
              </button>
            )}

            {onOpenExport && (
              <button
                onClick={onOpenExport}
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-[11px] shadow transition-all active:scale-95"
                title="Export & Download Video with Subtitles"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Export Video</span>
              </button>
            )}

            <button
              onClick={toggleFullscreen}
              className="p-1.5 text-zinc-300 hover:text-white rounded-md hover:bg-white/10 transition-colors"
              title="Full Screen"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

function renderSubtitleWords(sub: SubtitleItem, currentTime: number, style: SubtitleStyle) {
  const allWords = sub.words && sub.words.length > 0 ? sub.words : sub.text.split(/\s+/).map((w, idx, arr) => {
    const d = (sub.endTime - sub.startTime) / Math.max(1, arr.length);
    return { word: w, startTime: sub.startTime + idx * d, endTime: sub.startTime + (idx + 1) * d };
  });

  const limit = style.wordsPerScreenLimit || 0;
  let visibleWords = allWords;
  let offsetIdx = 0;

  // Windowing: limit visible words per line/screen
  if (limit > 0 && allWords.length > limit) {
    let activeIdx = allWords.findIndex((w) => currentTime >= w.startTime && currentTime <= w.endTime);
    if (activeIdx === -1) {
      if (currentTime < allWords[0].startTime) activeIdx = 0;
      else activeIdx = allWords.length - 1;
    }
    const chunkIdx = Math.floor(activeIdx / limit);
    const start = chunkIdx * limit;
    const end = Math.min(allWords.length, start + limit);
    visibleWords = allWords.slice(start, end);
    offsetIdx = start;
  }

  const color1 = style.highlightColor || "#FFE500";
  const color2 = style.highlightColor2 || style.highlightColor || "#00F0FF";

  return visibleWords.map((w, localIdx) => {
    const globalIdx = offsetIdx + localIdx;
    const isWordActive = currentTime >= w.startTime && currentTime <= w.endTime;
    const isWordPassed = currentTime > w.endTime;

    // Pick active color based on alternating index for vibrant 2-color highlights
    const activeColor = globalIdx % 2 === 0 ? color1 : color2;

    let wordColor = style.textColor;
    let scaleClass = "";
    let shadowStyle = undefined;

    if (style.animation === "karaoke-word") {
      if (isWordActive) {
        wordColor = activeColor;
        scaleClass = "scale-110 font-black inline-block transition-transform duration-100";
        if (style.shadowBlur > 0) {
          shadowStyle = `0 0 ${style.shadowBlur}px ${activeColor}`;
        }
      } else if (isWordPassed) {
        wordColor = style.textColor;
      }
    } else if (style.animation === "pop-in" && isWordActive) {
      wordColor = activeColor;
      scaleClass = "animate-bounce font-black inline-block";
    } else if (style.animation === "glow-pulse" && isWordActive) {
      wordColor = activeColor;
      scaleClass = "scale-105 font-bold inline-block";
      shadowStyle = `0 0 16px ${activeColor}`;
    } else if (isWordActive) {
      wordColor = activeColor;
      scaleClass = "scale-105 font-bold inline-block";
    }

    return (
      <span
        key={globalIdx}
        style={{
          color: wordColor,
          textShadow: shadowStyle || undefined,
        }}
        className={`transition-colors duration-150 ${scaleClass}`}
      >
        {w.word}
      </span>
    );
  });
}

function hexToRgba(hex: string, opacity: number): string {
  let c = hex.replace("#", "");
  if (c.length === 3) c = c.split("").map((x) => x + x).join("");
  const num = parseInt(c, 16) || 0;
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
}

function formatTime(seconds: number): string {
  const s = Math.max(0, seconds || 0);
  const mins = Math.floor(s / 60);
  const secs = Math.floor(s % 60);
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}
