import React, { useState } from "react";
import {
  Search,
  Plus,
  Trash2,
  Copy,
  Play,
  Scissors,
  Link,
  Clock,
  User,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowUpDown,
  FastForward,
} from "lucide-react";
import { SubtitleItem } from "../types";

interface CaptionListProps {
  subtitles: SubtitleItem[];
  currentTime: number;
  selectedSubtitleId: string | null;
  onSelectSubtitle: (id: string) => void;
  onUpdateSubtitle: (id: string, updates: Partial<SubtitleItem>) => void;
  onDeleteSubtitle: (id: string) => void;
  onDuplicateSubtitle: (id: string) => void;
  onAddSubtitle: (time: number) => void;
  onPlaySnippet: (startTime: number, endTime: number) => void;
  onSplitSubtitle: (id: string, splitTime: number) => void;
  onMergeSubtitle: (id: string) => void;
  onShiftAllTimestamps: (seconds: number) => void;
  onRechunkSubtitles?: (wordsPerLine: number) => void;
  onOpenAITools?: () => void;
}

export const CaptionList: React.FC<CaptionListProps> = ({
  subtitles,
  currentTime,
  selectedSubtitleId,
  onSelectSubtitle,
  onUpdateSubtitle,
  onDeleteSubtitle,
  onDuplicateSubtitle,
  onAddSubtitle,
  onPlaySnippet,
  onSplitSubtitle,
  onMergeSubtitle,
  onShiftAllTimestamps,
  onRechunkSubtitles,
  onOpenAITools,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedWordIds, setExpandedWordIds] = useState<Set<string>>(new Set());
  const [showShiftModal, setShowShiftModal] = useState(false);
  const [showRechunkModal, setShowRechunkModal] = useState(false);
  const [shiftAmount, setShiftAmount] = useState(0.5);

  const toggleWordsExpand = (id: string) => {
    setExpandedWordIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const filteredSubtitles = subtitles.filter(
    (s) =>
      s.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.speaker && s.speaker.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="w-full lg:w-80 xl:w-96 bg-zinc-900 border-r border-zinc-800 flex flex-col h-full select-none flex-shrink-0">
      {/* Top Search & Filter Bar */}
      <div className="p-3 border-b border-zinc-800 flex flex-col gap-2 bg-zinc-900/60">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold text-xs text-zinc-200">Captions</span>
            <span className="text-[10px] bg-zinc-800 text-amber-400 font-mono px-2 py-0.5 rounded-full border border-zinc-700">
              {subtitles.length} cues
            </span>
          </div>

          <div className="flex items-center gap-1">
            {onRechunkSubtitles && (
              <button
                onClick={() => {
                  setShowRechunkModal(!showRechunkModal);
                  setShowShiftModal(false);
                }}
                className={`px-2 py-1 rounded text-[11px] font-medium flex items-center gap-1 transition-colors ${
                  showRechunkModal
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                    : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
                }`}
                title="Re-chunk Subtitles by Words Per Line"
              >
                <Scissors className="w-3 h-3 text-amber-400" />
                <span>Words/Line</span>
              </button>
            )}

            <button
              onClick={() => {
                setShowShiftModal(!showShiftModal);
                setShowRechunkModal(false);
              }}
              className="px-2 py-1 rounded text-[11px] font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 flex items-center gap-1 transition-colors"
              title="Bulk Shift Timestamps (+/- seconds)"
            >
              <FastForward className="w-3 h-3" />
              <span>Shift</span>
            </button>

            <button
              onClick={() => onAddSubtitle(currentTime)}
              className="px-2 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[11px] flex items-center gap-1 transition-all"
              title="Add Manual Subtitle"
            >
              <Plus className="w-3 h-3" />
              <span>Manual</span>
            </button>

            {onOpenAITools && (
              <button
                onClick={onOpenAITools}
                className="px-2.5 py-1 rounded bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-[11px] flex items-center gap-1 transition-all shadow-sm active:scale-95"
                title="Auto Generate Subtitles from Audio (AI)"
              >
                <Sparkles className="w-3 h-3 fill-current" />
                <span>Auto AI</span>
              </button>
            )}
          </div>
        </div>

        {/* Rechunk Words Per Line Panel */}
        {showRechunkModal && onRechunkSubtitles && (
          <div className="p-2.5 bg-zinc-950 rounded-lg border border-amber-500/30 flex flex-col gap-2 text-xs animate-in fade-in shadow-lg">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-zinc-300 font-semibold flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5 text-amber-400" />
                Split Subtitles by Words:
              </span>
              <button
                onClick={() => setShowRechunkModal(false)}
                className="text-zinc-500 hover:text-zinc-300 text-[10px]"
              >
                ✕ Close
              </button>
            </div>
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { label: "1 Word", words: 1, desc: "Fast Pop" },
                { label: "2 Words", words: 2, desc: "Punchy" },
                { label: "3 Words", words: 3, desc: "TikTok Viral" },
                { label: "4 Words", words: 4, desc: "Standard" },
              ].map((opt) => (
                <button
                  key={opt.words}
                  onClick={() => {
                    onRechunkSubtitles(opt.words);
                    setShowRechunkModal(false);
                  }}
                  className="px-2 py-1.5 rounded-md bg-zinc-900 border border-zinc-800 hover:border-amber-400 hover:bg-zinc-800 text-zinc-200 text-center transition-all flex flex-col items-center justify-center"
                >
                  <span className="font-bold text-[11px] text-amber-300">{opt.label}</span>
                  <span className="text-[9px] text-zinc-400">{opt.desc}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Shift Timestamps Panel (if open) */}
        {showShiftModal && (
          <div className="p-2 bg-zinc-950 rounded-lg border border-zinc-800 flex items-center justify-between text-xs animate-in fade-in">
            <span className="text-zinc-400 text-[11px]">Shift all by:</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onShiftAllTimestamps(-shiftAmount)}
                className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-mono"
              >
                -{shiftAmount}s
              </button>
              <button
                onClick={() => onShiftAllTimestamps(shiftAmount)}
                className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-mono"
              >
                +{shiftAmount}s
              </button>
            </div>
          </div>
        )}

        {/* Search input */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search captions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-amber-500/60"
          />
        </div>
      </div>

      {/* Scrollable Subtitle Cards List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {filteredSubtitles.length === 0 ? (
          <div className="text-center py-10 px-4 flex flex-col items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400/10 border border-amber-400/20 text-amber-400 flex items-center justify-center shadow-inner">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-zinc-200">Video Audio se Subtitles Banayein</h4>
              <p className="text-[11px] text-zinc-400 mt-1 max-w-[240px] mx-auto leading-relaxed">
                Gemini AI video ki speech sunkar automatic word-synced subtitles generate karega.
              </p>
            </div>

            <div className="flex flex-col gap-2 w-full max-w-[200px] mt-1">
              {onOpenAITools && (
                <button
                  onClick={onOpenAITools}
                  className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 fill-current" />
                  <span>Generate Subtitles</span>
                </button>
              )}

              <button
                onClick={() => onAddSubtitle(currentTime)}
                className="w-full py-1.5 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium text-xs flex items-center justify-center gap-1 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Manual Cue</span>
              </button>
            </div>
          </div>
        ) : (
          filteredSubtitles.map((sub, index) => {
            const isCurrent = currentTime >= sub.startTime && currentTime <= sub.endTime;
            const isSelected = selectedSubtitleId === sub.id;
            const isWordsExpanded = expandedWordIds.has(sub.id);

            return (
              <div
                key={sub.id}
                onClick={() => onSelectSubtitle(sub.id)}
                className={`p-2.5 rounded-xl border transition-all duration-150 relative group ${
                  isCurrent
                    ? "bg-amber-500/10 border-amber-400/60 shadow-md ring-1 ring-amber-400/30"
                    : isSelected
                    ? "bg-zinc-800 border-zinc-600"
                    : "bg-zinc-900/80 hover:bg-zinc-850 border-zinc-800/80 hover:border-zinc-700"
                }`}
              >
                {/* Card Top Row: Index, Speaker, Time, Snippet Play */}
                <div className="flex items-center justify-between text-[11px] mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono text-zinc-500 text-[10px]">#{index + 1}</span>

                    {/* Speaker input */}
                    <input
                      type="text"
                      value={sub.speaker || "Speaker"}
                      onChange={(e) => onUpdateSubtitle(sub.id, { speaker: e.target.value })}
                      className="bg-transparent hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 px-1 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider w-16 truncate focus:bg-zinc-950 focus:outline-none focus:text-amber-400"
                    />
                  </div>

                  {/* Timestamps */}
                  <div className="flex items-center gap-1 font-mono text-[10px] text-zinc-400">
                    <input
                      type="number"
                      step="0.1"
                      value={sub.startTime}
                      onChange={(e) => onUpdateSubtitle(sub.id, { startTime: parseFloat(e.target.value) || 0 })}
                      className="w-12 bg-zinc-950 border border-zinc-800 rounded px-1 py-0.5 text-center text-zinc-300 focus:outline-none focus:border-amber-400"
                    />
                    <span>→</span>
                    <input
                      type="number"
                      step="0.1"
                      value={sub.endTime}
                      onChange={(e) => onUpdateSubtitle(sub.id, { endTime: parseFloat(e.target.value) || 0 })}
                      className="w-12 bg-zinc-950 border border-zinc-800 rounded px-1 py-0.5 text-center text-zinc-300 focus:outline-none focus:border-amber-400"
                    />

                    {/* Play Snippet */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPlaySnippet(sub.startTime, sub.endTime);
                      }}
                      className="p-1 rounded hover:bg-amber-400/20 text-zinc-400 hover:text-amber-300 transition-colors ml-0.5"
                      title="Play this snippet"
                    >
                      <Play className="w-3 h-3 fill-current" />
                    </button>
                  </div>
                </div>

                {/* Subtitle Editable Text */}
                <textarea
                  value={sub.text}
                  onChange={(e) => onUpdateSubtitle(sub.id, { text: e.target.value })}
                  rows={2}
                  className="w-full bg-transparent resize-none text-xs text-zinc-100 placeholder-zinc-600 focus:bg-zinc-950 focus:p-1.5 focus:rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-400 font-medium leading-relaxed"
                />

                {/* Secondary Bilingual text (if exists) */}
                {sub.secondaryText && (
                  <div className="text-[11px] text-sky-400/90 font-medium mt-1 bg-sky-950/30 px-2 py-0.5 rounded border border-sky-800/30">
                    {sub.secondaryText}
                  </div>
                )}

                {/* Word Timings breakdown toggle */}
                {sub.words && sub.words.length > 0 && (
                  <div className="mt-1.5 pt-1.5 border-t border-zinc-800/60">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWordsExpand(sub.id);
                      }}
                      className="text-[10px] text-zinc-400 hover:text-zinc-200 flex items-center gap-1 font-medium"
                    >
                      <span>{sub.words.length} words timed</span>
                      {isWordsExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>

                    {isWordsExpanded && (
                      <div className="mt-2 flex flex-wrap gap-1 max-h-24 overflow-y-auto p-1 bg-zinc-950 rounded-lg border border-zinc-850">
                        {sub.words.map((w, wIdx) => {
                          const isWordActive = currentTime >= w.startTime && currentTime <= w.endTime;
                          return (
                            <span
                              key={wIdx}
                              className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                                isWordActive
                                  ? "bg-amber-400 text-zinc-950 font-bold"
                                  : "bg-zinc-900 text-zinc-300 border border-zinc-800"
                              }`}
                              title={`${w.startTime.toFixed(2)}s - ${w.endTime.toFixed(2)}s`}
                            >
                              {w.word}
                            </span>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}

                {/* Hover Action Menu */}
                <div className="flex items-center justify-end gap-1 mt-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDuplicateSubtitle(sub.id);
                    }}
                    className="p-1 rounded hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200"
                    title="Duplicate subtitle"
                  >
                    <Copy className="w-3 h-3" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteSubtitle(sub.id);
                    }}
                    className="p-1 rounded hover:bg-rose-500/20 text-zinc-400 hover:text-rose-400"
                    title="Delete subtitle"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
