/**
 * Determines whether a value is a DOM node, React FiberNode, Window, or synthetic event.
 */
function isDomOrFiber(val: any): boolean {
  if (!val || typeof val !== "object") return false;

  try {
    // Check DOM Node properties
    if (typeof val.nodeType === "number" || typeof val.tagName === "string") {
      return true;
    }

    // Check React Fiber and Synthetic Event properties
    if (
      val._reactName ||
      val.nativeEvent ||
      val.stateNode ||
      val._reactInternals ||
      val.target ||
      val.currentTarget
    ) {
      return true;
    }

    // Check constructor names
    const constructorName = val.constructor?.name;
    if (
      constructorName &&
      (constructorName === "HTMLVideoElement" ||
        constructorName === "HTMLCanvasElement" ||
        constructorName === "HTMLElement" ||
        constructorName === "Element" ||
        constructorName === "Node" ||
        constructorName === "Document" ||
        constructorName === "Window" ||
        constructorName === "FiberNode" ||
        constructorName.startsWith("HTML") ||
        constructorName.includes("Event"))
    ) {
      return true;
    }

    // Check window / document self-references
    if (val.window === val || val.self === val) {
      return true;
    }
  } catch {
    return true;
  }

  return false;
}

/**
 * Recursively cleans and extracts plain JSON-serializable primitives, arrays, and plain objects.
 * Strips out DOM elements, circular references, React internal properties, functions, and symbols.
 */
export function sanitizeSerializable<T>(obj: T, seen = new WeakSet()): T {
  if (obj === null || obj === undefined) return obj;

  const type = typeof obj;
  if (type === "string" || type === "number" || type === "boolean") {
    return obj;
  }

  if (type !== "object") {
    return undefined as any;
  }

  if (isDomOrFiber(obj)) {
    return undefined as any;
  }

  if (seen.has(obj as object)) {
    return undefined as any; // Break circular reference safely
  }
  seen.add(obj as object);

  if (Array.isArray(obj)) {
    const result: any[] = [];
    for (let i = 0; i < obj.length; i++) {
      const item = obj[i];
      if (isDomOrFiber(item)) continue;
      const sanitized = sanitizeSerializable(item, seen);
      if (sanitized !== undefined) {
        result.push(sanitized);
      }
    }
    return result as any;
  }

  const result: Record<string, any> = {};
  const keys = Object.keys(obj);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    // Skip React internal and DOM keys
    if (
      key.startsWith("_react") ||
      key.startsWith("__react") ||
      key === "stateNode" ||
      key === "target" ||
      key === "currentTarget" ||
      key === "srcElement" ||
      key === "videoElement" ||
      key === "videoRef"
    ) {
      continue;
    }

    const val = (obj as any)[key];
    if (isDomOrFiber(val)) continue;

    const sanitized = sanitizeSerializable(val, seen);
    if (sanitized !== undefined) {
      result[key] = sanitized;
    }
  }

  return result as T;
}

/**
 * Circular-safe JSON stringifier that guarantees no unhandled circular structure errors.
 */
export function safeJsonStringify(obj: any, indent?: number): string {
  try {
    const cleaned = sanitizeSerializable(obj);
    return JSON.stringify(cleaned, null, indent);
  } catch (err) {
    console.warn("safeJsonStringify fallback triggered:", err);
    return "{}";
  }
}

/**
 * Deep clones an object while stripping any DOM nodes or non-serializable fields.
 */
export function cleanSerializableObject<T>(obj: T): T {
  if (!obj || typeof obj !== "object") return obj;
  try {
    return sanitizeSerializable(obj);
  } catch {
    return obj;
  }
}
