import React, { useState } from "react";
import {
  Palette,
  Type,
  Square,
  Sparkles,
  Move,
  Sliders,
  Check,
  Layout,
  Layers,
  Wand2,
} from "lucide-react";
import { SubtitleStyle, StylePreset } from "../types";
import { STYLE_PRESETS } from "../data/stylePresets";

interface StyleEditorProps {
  style: SubtitleStyle;
  onUpdateStyle: (updates: Partial<SubtitleStyle>) => void;
  onApplyPreset: (preset: StylePreset) => void;
  bilingualMode: boolean;
  onToggleBilingualMode: () => void;
  onRechunkSubtitles?: (wordsPerLine: number) => void;
}

export const StyleEditor: React.FC<StyleEditorProps> = ({
  style,
  onUpdateStyle,
  onApplyPreset,
  bilingualMode,
  onToggleBilingualMode,
  onRechunkSubtitles,
}) => {
  const [activeTab, setActiveTab] = useState<"presets" | "words" | "typography" | "colors" | "background" | "effects" | "position">("presets");

  const fontOptions = [
    { label: "Inter (Modern Sans)", value: "'Inter', sans-serif" },
    { label: "Montserrat (Punchy Bold)", value: "'Montserrat', sans-serif" },
    { label: "Anton / Impact (Heavy Bold)", value: "'Impact', 'Anton', sans-serif" },
    { label: "Outfit (Geometric)", value: "'Outfit', sans-serif" },
    { label: "Playfair Display (Editorial Serif)", value: "'Playfair Display', serif" },
    { label: "Bangers (Comic Pop)", value: "'Bangers', 'Comic Sans MS', sans-serif" },
    { label: "Roboto Mono (Code/Typewriter)", value: "'Roboto Mono', monospace" },
  ];

  return (
    <div className="w-full lg:w-80 xl:w-88 bg-zinc-900 border-l border-zinc-800 flex flex-col h-full select-none flex-shrink-0">
      {/* Header */}
      <div className="p-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-amber-400" />
          <span className="font-bold text-xs text-zinc-200">Style Studio</span>
        </div>

        {/* Bilingual Mode Toggle */}
        <button
          onClick={onToggleBilingualMode}
          className={`px-2 py-1 rounded-md text-[11px] font-semibold border transition-all flex items-center gap-1.5 ${
            bilingualMode
              ? "bg-sky-500/20 text-sky-300 border-sky-400/40"
              : "bg-zinc-800 text-zinc-400 border-zinc-700 hover:text-zinc-200"
          }`}
          title="Enable Dual/Bilingual Subtitles"
        >
          <span>Dual Subs</span>
          <span className={`w-1.5 h-1.5 rounded-full ${bilingualMode ? "bg-sky-400 animate-pulse" : "bg-zinc-600"}`} />
        </button>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center justify-between border-b border-zinc-800 px-2 bg-zinc-950/40 text-[11px] overflow-x-auto">
        <button
          onClick={() => setActiveTab("presets")}
          className={`py-2 px-2 font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "presets" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Presets
        </button>
        <button
          onClick={() => setActiveTab("words")}
          className={`py-2 px-2 font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-1 ${
            activeTab === "words" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
          }`}
        >
          <span>Words/Line</span>
          {style.wordsPerScreenLimit > 0 && (
            <span className="text-[9px] bg-amber-400/20 text-amber-300 px-1 rounded font-mono font-bold">
              {style.wordsPerScreenLimit}w
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab("typography")}
          className={`py-2 px-2 font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "typography" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Font
        </button>
        <button
          onClick={() => setActiveTab("colors")}
          className={`py-2 px-2 font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "colors" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Colors
        </button>
        <button
          onClick={() => setActiveTab("background")}
          className={`py-2 px-2 font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "background" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Box
        </button>
        <button
          onClick={() => setActiveTab("effects")}
          className={`py-2 px-2 font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "effects" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Effects
        </button>
        <button
          onClick={() => setActiveTab("position")}
          className={`py-2 px-2 font-medium border-b-2 transition-colors whitespace-nowrap ${
            activeTab === "position" ? "border-amber-400 text-amber-300" : "border-transparent text-zinc-400 hover:text-zinc-200"
          }`}
        >
          Position
        </button>
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* 1. Presets Tab */}
        {activeTab === "presets" && (
          <div className="space-y-3.5">
            {/* Quick 2-Color Word Highlight Bar */}
            <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-zinc-200 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  Dual Word Highlight Colors
                </span>
                <span className="text-[9px] uppercase tracking-wider font-semibold text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20">
                  2 Alag Alag Colors
                </span>
              </div>

              {/* Color 1 & Color 2 Inputs Side-by-Side */}
              <div className="grid grid-cols-2 gap-2">
                <div className="p-2 rounded-lg bg-zinc-950/80 border border-zinc-800 space-y-1">
                  <label className="text-[10px] font-semibold text-zinc-400 flex items-center justify-between">
                    <span>Word Color 1</span>
                    <span className="font-mono text-[9px] text-zinc-500">{style.highlightColor}</span>
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={style.highlightColor}
                      onChange={(e) => onUpdateStyle({ highlightColor: e.target.value })}
                      className="w-7 h-7 rounded border border-zinc-700 cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={style.highlightColor}
                      onChange={(e) => onUpdateStyle({ highlightColor: e.target.value })}
                      className="flex-1 min-w-0 bg-zinc-900 border border-zinc-700/80 rounded px-1.5 py-0.5 text-[11px] font-mono text-zinc-200"
                    />
                  </div>
                </div>

                <div className="p-2 rounded-lg bg-zinc-950/80 border border-zinc-800 space-y-1">
                  <label className="text-[10px] font-semibold text-zinc-400 flex items-center justify-between">
                    <span>Word Color 2</span>
                    <span className="font-mono text-[9px] text-zinc-500">{style.highlightColor2 || "#00F0FF"}</span>
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="color"
                      value={style.highlightColor2 || "#00F0FF"}
                      onChange={(e) => onUpdateStyle({ highlightColor2: e.target.value })}
                      className="w-7 h-7 rounded border border-zinc-700 cursor-pointer bg-transparent"
                    />
                    <input
                      type="text"
                      value={style.highlightColor2 || "#00F0FF"}
                      onChange={(e) => onUpdateStyle({ highlightColor2: e.target.value })}
                      className="flex-1 min-w-0 bg-zinc-900 border border-zinc-700/80 rounded px-1.5 py-0.5 text-[11px] font-mono text-zinc-200"
                    />
                  </div>
                </div>
              </div>

              {/* 1-Click Viral Dual Color Duos */}
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1 font-medium">Popular 2-Color Combinations:</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { name: "Yellow + Cyan", c1: "#FFE600", c2: "#00F0FF" },
                    { name: "Lime + Gold", c1: "#00FF66", c2: "#FFE600" },
                    { name: "Pink + Cyan", c1: "#FF007F", c2: "#00F0FF" },
                    { name: "Orange + Amber", c1: "#FF3D00", c2: "#FFD000" },
                    { name: "Purple + Sky", c1: "#A855F7", c2: "#38BDF8" },
                    { name: "Red + Gold", c1: "#EF4444", c2: "#F59E0B" },
                  ].map((duo) => (
                    <button
                      key={duo.name}
                      onClick={() =>
                        onUpdateStyle({
                          highlightColor: duo.c1,
                          highlightColor2: duo.c2,
                          dualWordHighlight: true,
                        })
                      }
                      className="p-1.5 rounded-lg bg-zinc-950/60 border border-zinc-800 hover:border-amber-400/60 hover:bg-zinc-800 flex items-center justify-between text-[10px] font-medium text-zinc-300 transition-all group"
                    >
                      <span className="truncate">{duo.name}</span>
                      <div className="flex items-center -space-x-1 ml-1 flex-shrink-0">
                        <span className="w-2.5 h-2.5 rounded-full border border-black/40" style={{ backgroundColor: duo.c1 }} />
                        <span className="w-2.5 h-2.5 rounded-full border border-black/40" style={{ backgroundColor: duo.c2 }} />
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Quick Font Size Control */}
              <div className="pt-2 border-t border-zinc-800/80 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-semibold text-zinc-400">Font Size:</span>
                  <span className="text-[11px] font-mono font-bold text-amber-300 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20">
                    {style.fontSize}px
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  {[
                    { label: "16px", size: 16 },
                    { label: "22px", size: 22 },
                    { label: "28px", size: 28 },
                    { label: "34px", size: 34 },
                  ].map((s) => (
                    <button
                      key={s.size}
                      onClick={() => onUpdateStyle({ fontSize: s.size })}
                      className={`px-1.5 py-0.5 rounded text-[10px] font-mono transition-colors ${
                        style.fontSize === s.size
                          ? "bg-amber-400 text-zinc-950 font-bold"
                          : "bg-zinc-950 text-zinc-400 border border-zinc-800 hover:text-zinc-200"
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.max(12, style.fontSize - 2) })}
                    className="w-5 h-5 rounded bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200 flex items-center justify-center font-mono text-[11px]"
                    title="Decrease font size"
                  >
                    -
                  </button>
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.min(72, style.fontSize + 2) })}
                    className="w-5 h-5 rounded bg-zinc-950 border border-zinc-800 text-zinc-400 hover:text-zinc-200 flex items-center justify-center font-mono text-[11px]"
                    title="Increase font size"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            <p className="text-[11px] text-zinc-400">Click any preset to apply typography, 2-color word styling, and animation:</p>
            
            <div className="grid grid-cols-1 gap-2.5">
              {STYLE_PRESETS.map((preset) => {
                const isSelected =
                  style.fontFamily === preset.style.fontFamily &&
                  style.highlightColor === preset.style.highlightColor;

                const c1 = preset.style.highlightColor;
                const c2 = preset.style.highlightColor2 || preset.style.highlightColor;

                return (
                  <button
                    key={preset.id}
                    onClick={() => onApplyPreset(preset)}
                    className={`w-full text-left p-3 rounded-xl border transition-all group relative overflow-hidden shadow-sm ${
                      isSelected
                        ? "bg-zinc-800 border-amber-400/80 ring-1 ring-amber-400/40"
                        : "bg-zinc-800/80 hover:bg-zinc-800 border-zinc-700/80 hover:border-amber-400/60"
                    }`}
                  >
                    <div className={`absolute top-0 right-0 w-16 h-16 bg-gradient-to-br ${preset.previewBg} opacity-20 group-hover:opacity-40 rounded-bl-full transition-opacity`} />
                    
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-bold text-xs text-zinc-100 group-hover:text-amber-300 transition-colors">
                        {preset.name}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <div className="flex items-center -space-x-1" title={`Word Colors: ${c1} & ${c2}`}>
                          <div
                            className="w-3 h-3 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: c1 }}
                          />
                          <div
                            className="w-3 h-3 rounded-full border border-black/40 shadow-sm"
                            style={{ backgroundColor: c2 }}
                          />
                        </div>
                        <span className="text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-zinc-900/80 text-zinc-400 font-mono">
                          {preset.category}
                        </span>
                      </div>
                    </div>

                    <p className="text-[11px] text-zinc-400 leading-snug line-clamp-2 mb-2">
                      {preset.description}
                    </p>

                    {/* Word Sample Preview Box showing 2 Distinct Colors */}
                    <div
                      className="text-center py-2 px-3 rounded-lg border text-xs font-black tracking-wide flex items-center justify-center gap-1.5"
                      style={{
                        backgroundColor: preset.style.bgBoxEnabled
                          ? preset.style.bgBoxColor
                          : "#09090B",
                        borderColor: preset.style.strokeColor !== "#000000" ? preset.style.strokeColor : "#27272A",
                        fontFamily: preset.style.fontFamily,
                      }}
                    >
                      <span style={{ color: preset.style.textColor }} className="opacity-80">
                        MAKE
                      </span>
                      <span
                        style={{
                          color: c1,
                          textShadow:
                            preset.style.shadowBlur > 0
                              ? `0 0 ${preset.style.shadowBlur}px ${c1}`
                              : undefined,
                        }}
                        className="scale-105 underline decoration-2 underline-offset-4"
                      >
                        [VIRAL]
                      </span>
                      <span
                        style={{
                          color: c2,
                          textShadow:
                            preset.style.shadowBlur > 0
                              ? `0 0 ${preset.style.shadowBlur}px ${c2}`
                              : undefined,
                        }}
                        className="scale-105 underline decoration-2 underline-offset-4"
                      >
                        [CAPTIONS]
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. Words & Lines Tab */}
        {activeTab === "words" && (
          <div className="space-y-4 text-xs">
            {/* Words Per Screen / Line Limit */}
            <div className="p-3 rounded-xl bg-zinc-950/80 border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-bold text-zinc-200 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                  Words Per Line / Screen
                </label>
                <div className="flex items-center gap-1">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    {style.wordsPerScreenLimit === 0 ? "All / Auto" : `${style.wordsPerScreenLimit} Words / Line`}
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-zinc-400 leading-snug">
                Ek line me kitne words hone chahiye (1, 2, 3... words per line choose karein):
              </p>

              {/* Extended 1, 2, 3, 4, 5, 6, 7, 8... Word Grid */}
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { label: "1 Word", val: 1, tag: "1 Line/Word" },
                  { label: "2 Words", val: 2, tag: "2 Words/Line" },
                  { label: "3 Words", val: 3, tag: "3 Words/Line" },
                  { label: "4 Words", val: 4, tag: "4 Words/Line" },
                  { label: "5 Words", val: 5, tag: "5 Words/Line" },
                  { label: "6 Words", val: 6, tag: "6 Words/Line" },
                  { label: "8 Words", val: 8, tag: "8 Words/Line" },
                  { label: "Auto / All", val: 0, tag: "Full Line" },
                ].map((item) => {
                  const isActive = (style.wordsPerScreenLimit || 0) === item.val;
                  return (
                    <button
                      key={item.label}
                      onClick={() => onUpdateStyle({ wordsPerScreenLimit: item.val })}
                      className={`p-2 rounded-lg border text-left transition-all flex flex-col justify-between ${
                        isActive
                          ? "bg-amber-400 text-zinc-950 font-bold border-amber-400 shadow-md scale-[1.02]"
                          : "bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-amber-400/50 hover:bg-zinc-850"
                      }`}
                    >
                      <span className="text-[11px] font-bold">{item.label}</span>
                      <span
                        className={`text-[8px] mt-0.5 truncate ${
                          isActive ? "text-zinc-950 font-semibold" : "text-zinc-500"
                        }`}
                      >
                        {item.tag}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Direct Stepper & Numeric Input */}
              <div className="p-2.5 rounded-lg bg-zinc-900/90 border border-zinc-800/80 space-y-2">
                <div className="flex items-center justify-between text-zinc-300">
                  <span className="text-[11px] font-semibold">Exact Words Per Line:</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() =>
                        onUpdateStyle({
                          wordsPerScreenLimit: Math.max(0, (style.wordsPerScreenLimit || 0) - 1),
                        })
                      }
                      className="px-2 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[11px]"
                      title="-1 word"
                    >
                      -1 Word
                    </button>
                    <input
                      type="number"
                      min="0"
                      max="12"
                      value={style.wordsPerScreenLimit || 0}
                      onChange={(e) =>
                        onUpdateStyle({
                          wordsPerScreenLimit: Math.max(0, Math.min(12, parseInt(e.target.value) || 0)),
                        })
                      }
                      className="w-12 h-6 bg-zinc-950 border border-zinc-700 rounded text-center text-xs font-mono font-bold text-amber-300 focus:outline-none focus:border-amber-400"
                    />
                    <button
                      onClick={() =>
                        onUpdateStyle({
                          wordsPerScreenLimit: Math.min(12, (style.wordsPerScreenLimit || 0) + 1),
                        })
                      }
                      className="px-2 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[11px]"
                      title="+1 word"
                    >
                      +1 Word
                    </button>
                  </div>
                </div>

                <input
                  type="range"
                  min="0"
                  max="10"
                  step="1"
                  value={style.wordsPerScreenLimit || 0}
                  onChange={(e) => onUpdateStyle({ wordsPerScreenLimit: parseInt(e.target.value) })}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                />
                <div className="flex justify-between text-[9px] text-zinc-500 font-mono">
                  <span>0 (All)</span>
                  <span>1w</span>
                  <span>2w</span>
                  <span>3w</span>
                  <span>4w</span>
                  <span>5w</span>
                  <span>6w</span>
                  <span>8w</span>
                  <span>10w</span>
                </div>
              </div>

              {/* 1-Click Split Subtitle Cues permanently into N words */}
              {onRechunkSubtitles && style.wordsPerScreenLimit > 0 && (
                <button
                  onClick={() => onRechunkSubtitles(style.wordsPerScreenLimit)}
                  className="w-full py-2 px-3 rounded-lg bg-amber-500/15 border border-amber-500/30 hover:bg-amber-500/25 text-amber-300 font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-all shadow-sm group"
                >
                  <Wand2 className="w-3.5 h-3.5 text-amber-400 group-hover:rotate-12 transition-transform" />
                  <span>
                    Subtitles ko {style.wordsPerScreenLimit} Words/Line me split karein
                  </span>
                </button>
              )}
            </div>

            {/* Live Interactive Word Simulation Preview */}
            <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-zinc-300 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  Live Line Preview ("Beneath the surface"):
                </span>
                <span className="text-[10px] font-mono text-amber-300 font-bold bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20">
                  {style.wordsPerScreenLimit === 0 ? "Full Sentence" : `${style.wordsPerScreenLimit} Words/Line`}
                </span>
              </div>

              {/* Main Line Rendering Box */}
              <div
                className="py-3 px-3 rounded-lg bg-zinc-900/95 border border-zinc-800 text-center flex flex-wrap items-center justify-center gap-1.5 transition-all shadow-inner"
                style={{
                  fontFamily: style.fontFamily,
                  fontSize: `${Math.min(22, Math.max(14, style.fontSize))}px`,
                  fontWeight: style.fontWeight,
                  textTransform: style.textTransform,
                }}
              >
                {(() => {
                  const demoSentence = "Beneath the surface lies an uncharted world of vibrant biodiversity";
                  const demoWords = demoSentence.split(" ");
                  const limit = style.wordsPerScreenLimit || 0;
                  const displayWords = limit > 0 ? demoWords.slice(0, limit) : demoWords;
                  const c1 = style.highlightColor || "#FFE600";
                  const c2 = style.highlightColor2 || style.highlightColor || "#00F0FF";

                  return displayWords.map((word, idx) => (
                    <span
                      key={idx}
                      style={{
                        color: idx === 0 ? c1 : idx === 1 ? c2 : style.textColor,
                        textShadow:
                          style.shadowBlur > 0
                            ? `0 0 ${style.shadowBlur}px ${idx === 0 ? c1 : c2}`
                            : undefined,
                      }}
                      className={idx < 2 ? "font-black scale-105" : "opacity-90"}
                    >
                      {word}
                    </span>
                  ));
                })()}
              </div>

              {/* Multi-Chunk Visualizer for 1, 2, 3... words per line */}
              {style.wordsPerScreenLimit > 0 && (
                <div className="p-2 rounded-lg bg-zinc-900/60 border border-zinc-850 space-y-1.5">
                  <span className="text-[10px] text-zinc-400 font-semibold block">
                    Lines Sequence Timeline ({style.wordsPerScreenLimit} words each):
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(() => {
                      const words = ["Beneath", "the", "surface", "lies", "an", "uncharted", "world"];
                      const chunks: string[][] = [];
                      const lim = style.wordsPerScreenLimit;
                      for (let i = 0; i < words.length; i += lim) {
                        chunks.push(words.slice(i, i + lim));
                      }
                      return chunks.slice(0, 4).map((chunk, cIdx) => (
                        <div
                          key={cIdx}
                          className={`px-2 py-1 rounded text-[10px] font-mono flex items-center gap-1 border transition-all ${
                            cIdx === 0
                              ? "bg-amber-400/15 border-amber-400/40 text-amber-200 font-bold"
                              : "bg-zinc-950/80 border-zinc-800 text-zinc-400"
                          }`}
                        >
                          <span className="text-[8px] text-zinc-500 font-bold">L{cIdx + 1}:</span>
                          <span>"{chunk.join(" ")}"</span>
                        </div>
                      ));
                    })()}
                  </div>
                </div>
              )}

              <p className="text-[10px] text-zinc-400 text-center italic leading-snug">
                {style.wordsPerScreenLimit === 1 && '1 Word Line: Pehle "Beneath" aayega, fir "the", fir "surface"...'}
                {style.wordsPerScreenLimit === 2 && '2 Words Line: Pehle "Beneath the" aayega, fir "surface lies"...'}
                {style.wordsPerScreenLimit === 3 && '3 Words Line: Pehle "Beneath the surface" aayega, fir "lies an uncharted"...'}
                {style.wordsPerScreenLimit === 4 && '4 Words Line: Pehle "Beneath the surface lies" aayega, fir "an uncharted world of"...'}
                {style.wordsPerScreenLimit >= 5 && `${style.wordsPerScreenLimit} Words Line: Har line me ${style.wordsPerScreenLimit} words ka chunk render hoga.`}
                {style.wordsPerScreenLimit === 0 && 'Auto/All: "Beneath the surface lies an uncharted world" pura sentence ek sath display hoga.'}
              </p>
            </div>

            {/* Text Alignment */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Text Alignment</label>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { label: "Left", value: "left" },
                  { label: "Center", value: "center" },
                  { label: "Right", value: "right" },
                ].map((a) => (
                  <button
                    key={a.value}
                    onClick={() => onUpdateStyle({ textAlign: a.value as any })}
                    className={`py-1.5 rounded-lg border text-center ${
                      style.textAlign === a.value
                        ? "bg-amber-400 text-zinc-950 font-bold border-amber-400"
                        : "bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200"
                    }`}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Max Bounding Width */}
            <div>
              <div className="flex justify-between text-zinc-400 mb-1">
                <span>Max Line Width (Wrapping)</span>
                <span className="font-mono text-zinc-200">{style.maxWidthPercent}%</span>
              </div>
              <input
                type="range"
                min="35"
                max="95"
                step="5"
                value={style.maxWidthPercent}
                onChange={(e) => onUpdateStyle({ maxWidthPercent: parseInt(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <p className="text-[10px] text-zinc-500 mt-1">
                Chhoti width rakhne se lines auto-wrap hoti hain, badi width se single line rehti hai.
              </p>
            </div>

            {/* Font Size & Subtitle Sizing */}
            <div className="p-3 rounded-xl bg-zinc-950/80 border border-zinc-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="font-bold text-zinc-200 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  Font Size (Subtitle Scale)
                </label>
                <div className="flex items-center gap-1">
                  <span className="text-[11px] font-mono font-bold text-amber-300 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20">
                    {style.fontSize}px
                  </span>
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.max(12, style.fontSize - 2) })}
                    className="px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[11px]"
                    title="Decrease font size (-2px)"
                  >
                    -2px
                  </button>
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.min(72, style.fontSize + 2) })}
                    className="px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[11px]"
                    title="Increase font size (+2px)"
                  >
                    +2px
                  </button>
                </div>
              </div>

              {/* Quick Size Select Pills */}
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { label: "16px (Kam / Compact)", size: 16 },
                  { label: "20px (Small)", size: 20 },
                  { label: "26px (Medium)", size: 26 },
                  { label: "32px (Viral Bold)", size: 32 },
                ].map((s) => (
                  <button
                    key={s.size}
                    onClick={() => onUpdateStyle({ fontSize: s.size })}
                    className={`py-1.5 px-1 rounded-lg border text-center transition-all ${
                      style.fontSize === s.size
                        ? "bg-amber-400 text-zinc-950 font-bold border-amber-400 shadow"
                        : "bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-amber-400/60 hover:text-zinc-100"
                    }`}
                  >
                    <span className="text-[10px] font-bold block">{s.label.split(" ")[0]}</span>
                    <span className={`text-[8px] block ${style.fontSize === s.size ? "text-zinc-950 font-semibold" : "text-zinc-500"}`}>
                      {s.label.split(" ").slice(1).join(" ")}
                    </span>
                  </button>
                ))}
              </div>

              {/* Slider for Font Size */}
              <div>
                <input
                  type="range"
                  min="12"
                  max="72"
                  step="1"
                  value={style.fontSize}
                  onChange={(e) => onUpdateStyle({ fontSize: parseInt(e.target.value) })}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                />
                <div className="flex justify-between text-[9px] text-zinc-500 font-mono mt-1">
                  <span>12px</span>
                  <span className={style.fontSize === 16 ? "text-amber-400 font-bold" : ""}>16px</span>
                  <span>24px</span>
                  <span>32px</span>
                  <span>48px</span>
                  <span>72px</span>
                </div>
              </div>
            </div>

            {/* Line Height & Spacing */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div>
                <div className="flex justify-between text-zinc-400 mb-1">
                  <span>Line Height</span>
                  <span className="font-mono text-zinc-200">{style.lineHeight}x</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="2"
                  step="0.1"
                  value={style.lineHeight}
                  onChange={(e) => onUpdateStyle({ lineHeight: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                />
              </div>

              <div>
                <div className="flex justify-between text-zinc-400 mb-1">
                  <span>Letter Spacing</span>
                  <span className="font-mono text-zinc-200">{style.letterSpacing}px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="6"
                  step="0.5"
                  value={style.letterSpacing}
                  onChange={(e) => onUpdateStyle({ letterSpacing: parseFloat(e.target.value) })}
                  className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                />
              </div>
            </div>
          </div>
        )}

        {/* 3. Typography Tab */}
        {activeTab === "typography" && (
          <div className="space-y-4 text-xs">
            {/* Font Family */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Font Family</label>
              <select
                value={style.fontFamily}
                onChange={(e) => onUpdateStyle({ fontFamily: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2 text-zinc-200 focus:outline-none focus:border-amber-400"
              >
                {fontOptions.map((f) => (
                  <option key={f.value} value={f.value}>
                    {f.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Font Size */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="font-medium text-zinc-300">Font Size (px)</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.max(12, style.fontSize - 1) })}
                    className="w-5 h-5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[10px]"
                    title="-1px"
                  >
                    -1
                  </button>
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.max(12, style.fontSize - 2) })}
                    className="px-1.5 h-5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[10px]"
                    title="-2px"
                  >
                    -2
                  </button>
                  <input
                    type="number"
                    min="12"
                    max="72"
                    value={style.fontSize}
                    onChange={(e) => onUpdateStyle({ fontSize: Math.min(72, Math.max(12, parseInt(e.target.value) || 16)) })}
                    className="w-12 h-5 bg-zinc-950 border border-zinc-700 rounded text-center text-[11px] font-mono text-amber-300 font-bold focus:outline-none focus:border-amber-400"
                  />
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.min(72, style.fontSize + 2) })}
                    className="px-1.5 h-5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[10px]"
                    title="+2px"
                  >
                    +2
                  </button>
                  <button
                    onClick={() => onUpdateStyle({ fontSize: Math.min(72, style.fontSize + 1) })}
                    className="w-5 h-5 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-amber-300 font-mono text-[10px]"
                    title="+1px"
                  >
                    +1
                  </button>
                </div>
              </div>

              {/* Quick Font Size Buttons */}
              <div className="grid grid-cols-6 gap-1">
                {[
                  { label: "14px", size: 14 },
                  { label: "16px", size: 16 },
                  { label: "20px", size: 20 },
                  { label: "26px", size: 26 },
                  { label: "32px", size: 32 },
                  { label: "40px", size: 40 },
                ].map((s) => (
                  <button
                    key={s.size}
                    onClick={() => onUpdateStyle({ fontSize: s.size })}
                    className={`py-1 rounded border text-center font-mono text-[10px] transition-all ${
                      style.fontSize === s.size
                        ? "bg-amber-400 text-zinc-950 font-bold border-amber-400 shadow"
                        : "bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200 hover:border-zinc-700"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              <input
                type="range"
                min="12"
                max="72"
                step="1"
                value={style.fontSize}
                onChange={(e) => onUpdateStyle({ fontSize: parseInt(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[9px] text-zinc-500 font-mono">
                <span>12px (Min)</span>
                <span className={style.fontSize === 16 ? "text-amber-400 font-bold" : ""}>16px</span>
                <span>28px (Std)</span>
                <span>48px</span>
                <span>72px (Max)</span>
              </div>
            </div>

            {/* Font Weight */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Font Weight</label>
              <div className="grid grid-cols-4 gap-1">
                {["400", "600", "700", "900"].map((w) => (
                  <button
                    key={w}
                    onClick={() => onUpdateStyle({ fontWeight: w })}
                    className={`py-1.5 rounded-lg border text-center font-mono ${
                      style.fontWeight === w
                        ? "bg-amber-400 text-zinc-950 font-bold border-amber-400"
                        : "bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200"
                    }`}
                  >
                    {w === "400" ? "Normal" : w === "600" ? "Semi" : w === "700" ? "Bold" : "Black"}
                  </button>
                ))}
              </div>
            </div>

            {/* Text Transform */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Text Case</label>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { label: "UPPER", value: "uppercase" },
                  { label: "Title", value: "capitalize" },
                  { label: "Normal", value: "none" },
                ].map((t) => (
                  <button
                    key={t.value}
                    onClick={() => onUpdateStyle({ textTransform: t.value as any })}
                    className={`py-1.5 rounded-lg border text-center ${
                      style.textTransform === t.value
                        ? "bg-amber-400 text-zinc-950 font-bold border-amber-400"
                        : "bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-zinc-200"
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Letter Spacing */}
            <div>
              <div className="flex justify-between text-zinc-400 mb-1">
                <span>Letter Spacing</span>
                <span className="font-mono text-zinc-200">{style.letterSpacing}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="6"
                step="0.5"
                value={style.letterSpacing}
                onChange={(e) => onUpdateStyle({ letterSpacing: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>
          </div>
        )}

        {/* 3. Colors Tab */}
        {activeTab === "colors" && (
          <div className="space-y-4 text-xs">
            {/* Primary Base Text Color */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Primary Base Text Color</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={style.textColor}
                  onChange={(e) => onUpdateStyle({ textColor: e.target.value })}
                  className="w-10 h-8 rounded bg-zinc-950 border border-zinc-700 cursor-pointer"
                />
                <input
                  type="text"
                  value={style.textColor}
                  onChange={(e) => onUpdateStyle({ textColor: e.target.value })}
                  className="flex-1 bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-zinc-200 font-mono"
                />
              </div>
            </div>

            {/* Word Highlight Color 1 (Primary) */}
            <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2">
              <label className="text-zinc-300 block font-semibold flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full border border-black/40" style={{ backgroundColor: style.highlightColor }} />
                  Word Highlight Color 1 (Primary)
                </span>
                <span className="text-amber-400 text-[10px] font-mono">{style.highlightColor}</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={style.highlightColor}
                  onChange={(e) => onUpdateStyle({ highlightColor: e.target.value })}
                  className="w-10 h-8 rounded bg-zinc-950 border border-zinc-700 cursor-pointer"
                />
                <input
                  type="text"
                  value={style.highlightColor}
                  onChange={(e) => onUpdateStyle({ highlightColor: e.target.value })}
                  className="flex-1 bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-zinc-200 font-mono"
                />
              </div>

              {/* Color 1 Swatches */}
              <div className="grid grid-cols-6 gap-1.5 pt-1">
                {[
                  { name: "Electric Yellow", color: "#FFE600" },
                  { name: "Neon Green", color: "#00FF66" },
                  { name: "Cyan Ice", color: "#00F0FF" },
                  { name: "Hot Pink", color: "#FF007F" },
                  { name: "Laser Red", color: "#EF4444" },
                  { name: "Blaze Orange", color: "#FF3D00" },
                ].map((item) => (
                  <button
                    key={item.color}
                    onClick={() => onUpdateStyle({ highlightColor: item.color })}
                    title={item.name}
                    style={{ backgroundColor: item.color }}
                    className={`h-7 rounded-md border flex items-center justify-center transition-all ${
                      style.highlightColor.toUpperCase() === item.color.toUpperCase()
                        ? "ring-2 ring-amber-400 scale-105 border-white shadow-md"
                        : "border-white/20 hover:scale-105"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Word Highlight Color 2 (Secondary) */}
            <div className="p-2.5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-2">
              <label className="text-zinc-300 block font-semibold flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full border border-black/40" style={{ backgroundColor: style.highlightColor2 || "#00F0FF" }} />
                  Word Highlight Color 2 (Secondary)
                </span>
                <span className="text-sky-400 text-[10px] font-mono">{style.highlightColor2 || "#00F0FF"}</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={style.highlightColor2 || "#00F0FF"}
                  onChange={(e) => onUpdateStyle({ highlightColor2: e.target.value })}
                  className="w-10 h-8 rounded bg-zinc-950 border border-zinc-700 cursor-pointer"
                />
                <input
                  type="text"
                  value={style.highlightColor2 || "#00F0FF"}
                  onChange={(e) => onUpdateStyle({ highlightColor2: e.target.value })}
                  className="flex-1 bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-zinc-200 font-mono"
                />
              </div>

              {/* Color 2 Swatches */}
              <div className="grid grid-cols-6 gap-1.5 pt-1">
                {[
                  { name: "Cyan Ice", color: "#00F0FF" },
                  { name: "Electric Yellow", color: "#FFE600" },
                  { name: "Neon Green", color: "#00FF66" },
                  { name: "Hot Pink", color: "#FF007F" },
                  { name: "Ultra Violet", color: "#A855F7" },
                  { name: "Golden Amber", color: "#FFD000" },
                ].map((item) => (
                  <button
                    key={item.color}
                    onClick={() => onUpdateStyle({ highlightColor2: item.color })}
                    title={item.name}
                    style={{ backgroundColor: item.color }}
                    className={`h-7 rounded-md border flex items-center justify-center transition-all ${
                      (style.highlightColor2 || "#00F0FF").toUpperCase() === item.color.toUpperCase()
                        ? "ring-2 ring-sky-400 scale-105 border-white shadow-md"
                        : "border-white/20 hover:scale-105"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Popular 2-Color Duo Combos */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Popular 2-Color Creator Duos</label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { name: "Yellow + Cyan", c1: "#FFE600", c2: "#00F0FF" },
                  { name: "Lime + Gold", c1: "#00FF66", c2: "#FFE600" },
                  { name: "Pink + Cyan", c1: "#FF007F", c2: "#00F0FF" },
                  { name: "Orange + Amber", c1: "#FF3D00", c2: "#FFD000" },
                  { name: "Purple + Sky", c1: "#A855F7", c2: "#38BDF8" },
                  { name: "Red + Gold", c1: "#EF4444", c2: "#F59E0B" },
                ].map((duo) => (
                  <button
                    key={duo.name}
                    onClick={() =>
                      onUpdateStyle({
                        highlightColor: duo.c1,
                        highlightColor2: duo.c2,
                        dualWordHighlight: true,
                      })
                    }
                    className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-amber-400/60 hover:bg-zinc-850 flex items-center justify-between text-[10px] font-medium text-zinc-300 transition-all"
                  >
                    <span className="truncate">{duo.name}</span>
                    <div className="flex items-center -space-x-1 ml-1 flex-shrink-0">
                      <span className="w-2.5 h-2.5 rounded-full border border-black/40" style={{ backgroundColor: duo.c1 }} />
                      <span className="w-2.5 h-2.5 rounded-full border border-black/40" style={{ backgroundColor: duo.c2 }} />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Base Text Color Swatches */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Base Text Swatches</label>
              <div className="grid grid-cols-6 gap-2">
                {[
                  { name: "Pure White", color: "#FFFFFF" },
                  { name: "Off White", color: "#F8FAFC" },
                  { name: "Light Cream", color: "#FEF08A" },
                  { name: "Ice Blue", color: "#E0F2FE" },
                  { name: "Pale Mint", color: "#DCFCE7" },
                  { name: "Soft Lavender", color: "#F5F3FF" },
                ].map((item) => (
                  <button
                    key={item.color}
                    onClick={() => onUpdateStyle({ textColor: item.color })}
                    title={item.name}
                    style={{ backgroundColor: item.color }}
                    className={`h-7 rounded-lg border flex items-center justify-center transition-all ${
                      style.textColor.toUpperCase() === item.color.toUpperCase()
                        ? "ring-2 ring-amber-400 scale-105 border-white"
                        : "border-white/20 hover:scale-105"
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Secondary Subtitle Color (if bilingual) */}
            {bilingualMode && (
              <div className="pt-2 border-t border-zinc-800">
                <label className="text-sky-300 block mb-1.5 font-medium">Secondary Language Color</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={style.bilingualSecondaryColor}
                    onChange={(e) => onUpdateStyle({ bilingualSecondaryColor: e.target.value })}
                    className="w-10 h-8 rounded bg-zinc-950 border border-zinc-700 cursor-pointer"
                  />
                  <input
                    type="text"
                    value={style.bilingualSecondaryColor}
                    onChange={(e) => onUpdateStyle({ bilingualSecondaryColor: e.target.value })}
                    className="flex-1 bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-zinc-200 font-mono"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* 4. Background Box Tab */}
        {activeTab === "background" && (
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <label className="text-zinc-300 font-medium">Enable Background Box</label>
              <input
                type="checkbox"
                checked={style.bgBoxEnabled}
                onChange={(e) => onUpdateStyle({ bgBoxEnabled: e.target.checked })}
                className="w-4 h-4 accent-amber-400 rounded cursor-pointer"
              />
            </div>

            {style.bgBoxEnabled && (
              <>
                <div>
                  <label className="text-zinc-400 block mb-1.5 font-medium">Box Color</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={style.bgBoxColor}
                      onChange={(e) => onUpdateStyle({ bgBoxColor: e.target.value })}
                      className="w-10 h-8 rounded bg-zinc-950 border border-zinc-700 cursor-pointer"
                    />
                    <input
                      type="text"
                      value={style.bgBoxColor}
                      onChange={(e) => onUpdateStyle({ bgBoxColor: e.target.value })}
                      className="flex-1 bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-zinc-200 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-zinc-400 mb-1">
                    <span>Box Opacity</span>
                    <span className="font-mono text-zinc-200">{Math.round(style.bgBoxOpacity * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={style.bgBoxOpacity}
                    onChange={(e) => onUpdateStyle({ bgBoxOpacity: parseFloat(e.target.value) })}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-zinc-400 mb-1">
                    <span>Padding (Horizontal)</span>
                    <span className="font-mono text-zinc-200">{style.bgBoxPaddingX}px</span>
                  </div>
                  <input
                    type="range"
                    min="4"
                    max="40"
                    step="2"
                    value={style.bgBoxPaddingX}
                    onChange={(e) => onUpdateStyle({ bgBoxPaddingX: parseInt(e.target.value) })}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-zinc-400 mb-1">
                    <span>Corner Radius</span>
                    <span className="font-mono text-zinc-200">{style.bgBoxBorderRadius}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="24"
                    step="2"
                    value={style.bgBoxBorderRadius}
                    onChange={(e) => onUpdateStyle({ bgBoxBorderRadius: parseInt(e.target.value) })}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                </div>
              </>
            )}
          </div>
        )}

        {/* 5. Effects & Animation Tab */}
        {activeTab === "effects" && (
          <div className="space-y-4 text-xs">
            {/* Animation Presets */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Motion & Animation</label>
              <select
                value={style.animation}
                onChange={(e) => onUpdateStyle({ animation: e.target.value as any })}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg p-2 text-zinc-200 focus:outline-none focus:border-amber-400"
              >
                <option value="karaoke-word">Karaoke (Word-by-Word Highlight)</option>
                <option value="pop-in">Pop-In Scale Bounce</option>
                <option value="typewriter">Typewriter Flow</option>
                <option value="glow-pulse">Neon Glow Pulse</option>
                <option value="static">Classic Static</option>
              </select>
            </div>

            {/* Stroke / Outline */}
            <div>
              <div className="flex justify-between text-zinc-400 mb-1">
                <span>Text Outline / Stroke</span>
                <span className="font-mono text-zinc-200">{style.strokeWidth}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="6"
                step="0.5"
                value={style.strokeWidth}
                onChange={(e) => onUpdateStyle({ strokeWidth: parseFloat(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Shadow */}
            <div>
              <div className="flex justify-between text-zinc-400 mb-1">
                <span>Drop Shadow Blur</span>
                <span className="font-mono text-zinc-200">{style.shadowBlur}px</span>
              </div>
              <input
                type="range"
                min="0"
                max="24"
                step="2"
                value={style.shadowBlur}
                onChange={(e) => onUpdateStyle({ shadowBlur: parseInt(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>
          </div>
        )}

        {/* 6. Position & Layout Tab */}
        {activeTab === "position" && (
          <div className="space-y-4 text-xs">
            {/* Quick Position Presets */}
            <div>
              <label className="text-zinc-400 block mb-1.5 font-medium">Quick Snap Preset</label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { label: "Top", y: 15, x: 50 },
                  { label: "Middle", y: 50, x: 50 },
                  { label: "Bottom", y: 82, x: 50 },
                ].map((pos) => (
                  <button
                    key={pos.label}
                    onClick={() => onUpdateStyle({ xPercent: pos.x, yPercent: pos.y, positionPreset: "custom" })}
                    className="py-1.5 rounded-lg border bg-zinc-950 text-zinc-300 border-zinc-800 hover:border-amber-400 hover:text-amber-300 text-center font-medium"
                  >
                    {pos.label}
                  </button>
                ))}
              </div>
            </div>

            {/* X Position */}
            <div>
              <div className="flex justify-between text-zinc-400 mb-1">
                <span>Horizontal X</span>
                <span className="font-mono text-zinc-200">{style.xPercent}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="90"
                step="1"
                value={style.xPercent}
                onChange={(e) => onUpdateStyle({ xPercent: parseInt(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Y Position */}
            <div>
              <div className="flex justify-between text-zinc-400 mb-1">
                <span>Vertical Y</span>
                <span className="font-mono text-zinc-200">{style.yPercent}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="95"
                step="1"
                value={style.yPercent}
                onChange={(e) => onUpdateStyle({ yPercent: parseInt(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Max Width */}
            <div>
              <div className="flex justify-between text-zinc-400 mb-1">
                <span>Max Bounding Width</span>
                <span className="font-mono text-zinc-200">{style.maxWidthPercent}%</span>
              </div>
              <input
                type="range"
                min="40"
                max="95"
                step="5"
                value={style.maxWidthPercent}
                onChange={(e) => onUpdateStyle({ maxWidthPercent: parseInt(e.target.value) })}
                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
