export interface WordTiming {
  word: string;
  startTime: number;
  endTime: number;
}

export interface SubtitleItem {
  id: string;
  startTime: number; // in seconds
  endTime: number; // in seconds
  text: string;
  speaker?: string;
  words?: WordTiming[];
  originalText?: string; // used in translation/bilingual mode
  secondaryText?: string; // secondary language text
}

export type SubtitleAnimation =
  | "karaoke-word"
  | "pop-in"
  | "typewriter"
  | "bounce"
  | "slide-up"
  | "glow-pulse"
  | "static";

export type SubtitlePositionPreset =
  | "bottom-center"
  | "top-center"
  | "middle-center"
  | "bottom-left"
  | "bottom-right"
  | "custom";

export interface SubtitleStyle {
  fontFamily: string;
  fontSize: number; // in px
  fontWeight: string; // "400" | "600" | "700" | "800" | "900"
  textColor: string;
  highlightColor: string; // active word karaoke color 1 (Primary)
  highlightColor2?: string; // active word karaoke color 2 (Secondary for 2-color dual highlighting)
  dualWordHighlight?: boolean; // enable 2 distinct alternating colors for words
  textTransform: "none" | "uppercase" | "lowercase" | "capitalize";
  letterSpacing: number; // in px
  lineHeight: number; // e.g. 1.2
  
  // Background Box
  bgBoxEnabled: boolean;
  bgBoxColor: string;
  bgBoxOpacity: number; // 0 to 1
  bgBoxPaddingX: number; // in px
  bgBoxPaddingY: number; // in px
  bgBoxBorderRadius: number; // in px
  
  // Stroke / Outline
  strokeWidth: number; // in px (0 for none)
  strokeColor: string;
  
  // Shadow
  shadowBlur: number; // in px
  shadowColor: string;
  shadowOffsetX: number;
  shadowOffsetY: number;
  
  // Position & Layout
  positionPreset: SubtitlePositionPreset;
  xPercent: number; // 0 to 100
  yPercent: number; // 0 to 100
  maxWidthPercent: number; // 20 to 100
  textAlign: "center" | "left" | "right";
  
  // Animation & Display
  animation: SubtitleAnimation;
  wordsPerScreenLimit: number; // 0 = all words in cue, or limit to e.g. 3-4 words for dynamic shorts
  
  // Bilingual / Dual subtitle
  bilingualSecondaryColor: string;
  bilingualSecondaryFontSize: number;
}

export interface StylePreset {
  id: string;
  name: string;
  category: "trending" | "broadcast" | "creative" | "minimal";
  description: string;
  style: SubtitleStyle;
  previewBg: string;
}

export interface ProjectVersion {
  id: string;
  name: string;
  description: string;
  timestamp: number;
  subtitleCount?: number;
  snapshot: {
    subtitles: SubtitleItem[];
    style: SubtitleStyle;
    currentLanguage: string;
    targetLanguage?: string;
  };
}

export interface Project {
  id: string;
  title: string;
  videoUrl: string;
  videoName?: string;
  videoDuration: number;
  videoAspectRatio: "16:9" | "9:16" | "1:1" | "4:5";
  subtitles: SubtitleItem[];
  style: SubtitleStyle;
  currentLanguage?: string;
  targetLanguage?: string;
  bilingualMode: boolean;
  versions: ProjectVersion[];
  createdAt: number;
  updatedAt: number;
  isCloudSynced: boolean;
}

export interface SampleVideo {
  id: string;
  title: string;
  category: string;
  duration: number;
  aspectRatio?: "16:9" | "9:16" | "1:1" | "4:5";
  videoUrl: string;
  thumbnail: string;
  description: string;
  defaultCaptions: SubtitleItem[];
}

export interface LanguageOption {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}
